package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.anilbeesetti.nextplayer.core.model.ThemeConfig
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.ListSectionTitle
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitch
import dev.anilbeesetti.nextplayer.core.ui.components.rememberTvListFocusRequester
import dev.anilbeesetti.nextplayer.core.ui.components.tvFocusDown
import dev.anilbeesetti.nextplayer.core.ui.components.tvListFocus
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.theme.screenContainerColor
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook
import dev.anilbeesetti.nextplayer.core.ui.theme.supportsDynamicTheming

/** Theme & Colors: light / dark, classic colors, AMOLED black, background colors and photo. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemePreferencesScreen(viewModel: AppearancePreferencesViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val onAction = viewModel::onAction
    val listFocusRequester = rememberTvListFocusRequester()
    val look = rememberAppLook()
    val setThemeConfig: (ThemeConfig) -> Unit = {
        onAction(AppearancePreferencesEvent.UpdateThemeConfig(themeConfig = it))
    }

    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(id = R.string.theme_prefs_name),
                navigationIcon = {
                    FilledTonalIconButton(
                        onClick = { onAction(AppearancePreferencesEvent.NavigateUp) },
                        modifier = Modifier.tvFocusDown(target = listFocusRequester),
                    ) {
                        Icon(
                            imageVector = NextIcons.ArrowBack,
                            contentDescription = stringResource(id = R.string.navigate_up),
                        )
                    }
                },
            )
        },
        containerColor = screenContainerColor(),
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(state = rememberScrollState())
                .tvListFocus(focusRequester = listFocusRequester)
                .padding(paddingValues = innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            ListSectionTitle(text = stringResource(id = R.string.app_theme))
            AppThemePicker(
                themeConfig = state.preferences.themeConfig,
                onThemeConfigChange = setThemeConfig,
            )

            ListSectionTitle(text = stringResource(id = R.string.theme_section))
            PreferenceSwitch(
                title = stringResource(id = R.string.amoled_title),
                description = stringResource(id = R.string.amoled_desc),
                icon = NextIcons.Contrast,
                isChecked = state.preferences.useHighContrastDarkTheme,
                onClick = { onAction(AppearancePreferencesEvent.ToggleUseHighContrastDarkTheme) },
                isFirstItem = true,
            )
            if (supportsDynamicTheming()) {
                PreferenceSwitch(
                    title = stringResource(id = R.string.dynamic_theme),
                    description = stringResource(id = R.string.dynamic_theme_description),
                    icon = NextIcons.Appearance,
                    isChecked = state.preferences.useDynamicColors,
                    onClick = { onAction(AppearancePreferencesEvent.ToggleUseDynamicColors) },
                )
            }
            PreferenceSwitch(
                title = stringResource(id = R.string.auto_text_color_title),
                description = stringResource(id = R.string.auto_text_color_desc),
                icon = NextIcons.Contrast,
                isChecked = look.autoTextColor,
                onClick = { look.updateAutoTextColor(!look.autoTextColor) },
                isLastItem = true,
            )

            ListSectionTitle(text = stringResource(id = R.string.background_color_title))
            BackgroundColorSettings(onThemeConfigChange = setThemeConfig)

            ListSectionTitle(text = stringResource(id = R.string.app_background))
            BackgroundPhotoSettings()
            Spacer(Modifier.height(24.dp))
        }
    }
}
