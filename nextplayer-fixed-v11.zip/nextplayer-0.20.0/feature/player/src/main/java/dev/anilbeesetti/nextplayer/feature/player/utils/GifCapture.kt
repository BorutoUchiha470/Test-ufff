package dev.anilbeesetti.nextplayer.feature.player.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import androidx.media3.common.C
import androidx.media3.common.Player
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

// A short, small GIF: 3 seconds, 10 pictures a second, 240 pixels high. Raise these for a bigger file.
private const val GIF_SECONDS = 3
private const val GIF_FPS = 10
private const val GIF_HEIGHT = 240
private const val GIF_DIR = "Videocaptures"

/**
 * Makes a looping GIF of the next few seconds of the video and saves it in DCIM/Videocaptures
 * (next to the screen captures).
 *
 * 1. Live: pictures are taken from the screen while the video keeps playing, the same quick way as a
 *    screen capture (no extra video decoder, so it works where reading the file does not).
 * 2. Backup: if that is not possible, the pictures are read from the video file instead.
 */
suspend fun saveGif(context: Context, view: View?, player: Player?): CapturedFrame? {
    val frames = recordLive(view, player) ?: recordFromFile(context, player) ?: return null
    return withContext(Dispatchers.IO) {
        runCatching {
            val bytes = GifEncoder(frames.width, frames.height).encode(frames.pixels, frames.delayCentis)
            val savedUri = saveGifBytes(context, bytes) ?: return@runCatching null
            CapturedFrame(thumbnail = frames.thumbnail, uri = savedUri, mimeType = "image/gif")
        }.getOrNull()
    }
}

private class GifFrames(
    val width: Int,
    val height: Int,
    val pixels: List<IntArray>,
    val thumbnail: Bitmap,
    val delayCentis: Int,
)

/** Takes pictures from the screen for a few seconds. Runs on the main thread (screen copies need it). */
private suspend fun recordLive(view: View?, player: Player?): GifFrames? {
    val wanted = GIF_SECONDS * GIF_FPS
    val stepMs = 1_000L / GIF_FPS
    val bitmaps = ArrayList<Bitmap>(wanted)
    val startedAt = SystemClock.elapsedRealtime()
    var nextAt = startedAt
    var failures = 0
    while (bitmaps.size < wanted && SystemClock.elapsedRealtime() - startedAt < (GIF_SECONDS + 2) * 1_000L) {
        val bitmap = grabScaledFrame(view, player, GIF_HEIGHT)
        if (bitmap != null) {
            bitmaps.add(bitmap)
        } else if (++failures >= 5 && bitmaps.isEmpty()) {
            return null
        }
        nextAt += stepMs
        val wait = nextAt - SystemClock.elapsedRealtime()
        if (wait > 0) delay(wait) else nextAt = SystemClock.elapsedRealtime() // behind: do not rush
    }
    if (bitmaps.size < 2) return null
    // The GIF plays back at the speed it was recorded at, even if some pictures came late.
    val elapsedMs = SystemClock.elapsedRealtime() - startedAt
    val delayCentis = (elapsedMs / bitmaps.size / 10).toInt().coerceIn(4, 50)

    return withContext(Dispatchers.Default) {
        val width = bitmaps[0].width
        val height = bitmaps[0].height
        val pixels = bitmaps.filter { it.width == width && it.height == height }.map { bitmap ->
            IntArray(width * height).also { bitmap.getPixels(it, 0, width, 0, 0, width, height) }
        }
        if (pixels.size < 2) null else GifFrames(width, height, pixels, bitmaps[0], delayCentis)
    }
}

/** Backup: reads the next few seconds from the video file. Needs an extra decoder, so can fail. */
private suspend fun recordFromFile(context: Context, player: Player?): GifFrames? {
    // Media3 players must be read on the main thread, so do it before switching to IO.
    val uri = player?.currentMediaItem?.localConfiguration?.uri ?: return null
    val startMs = player.currentPosition
    val videoDurationMs = player.duration

    return withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> retriever.setDataSource(uri.toString(), HashMap<String, String>())
                else -> retriever.setDataSource(context, uri)
            }
            val videoWidth = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: return@withContext null
            val videoHeight = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: return@withContext null
            val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            val shownWidth = if (rotation == 90 || rotation == 270) videoHeight else videoWidth
            val shownHeight = if (rotation == 90 || rotation == 270) videoWidth else videoHeight
            if (shownWidth <= 0 || shownHeight <= 0) return@withContext null

            val height = minOf(GIF_HEIGHT, shownHeight)
            val width = (height * shownWidth.toFloat() / shownHeight).roundToInt().coerceAtLeast(1)

            val stepMs = 1_000L / GIF_FPS
            val lastPossible = if (videoDurationMs != C.TIME_UNSET && videoDurationMs > 0L) {
                ((videoDurationMs - startMs) / stepMs).toInt() + 1
            } else {
                Int.MAX_VALUE
            }
            val frameCount = minOf(GIF_SECONDS * GIF_FPS, lastPossible)
            if (frameCount < 2) return@withContext null

            val frames = ArrayList<IntArray>(frameCount)
            var firstBitmap: Bitmap? = null
            for (index in 0 until frameCount) {
                val timeUs = (startMs + index * stepMs) * 1_000L
                val bitmap = readFrame(retriever, timeUs, width, height) ?: continue
                val pixels = IntArray(width * height)
                bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
                frames.add(pixels)
                if (firstBitmap == null) firstBitmap = bitmap else bitmap.recycle()
            }
            val thumbnail = firstBitmap ?: return@withContext null
            if (frames.size < 2) return@withContext null
            GifFrames(width, height, frames, thumbnail, delayCentis = 100 / GIF_FPS)
        } catch (e: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}

private fun readFrame(retriever: MediaMetadataRetriever, timeUs: Long, width: Int, height: Int): Bitmap? {
    val frame = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST, width, height)
        } else {
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST)
        }
    }.getOrNull() ?: return null
    return if (frame.width == width && frame.height == height) {
        frame
    } else {
        Bitmap.createScaledBitmap(frame, width, height, true).also { if (it !== frame) frame.recycle() }
    }
}

private fun saveGifBytes(context: Context, bytes: ByteArray): Uri? {
    val fileName = "NextPlayer_${System.currentTimeMillis()}.gif"
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/gif")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/$GIF_DIR")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        val written = runCatching {
            resolver.openOutputStream(target)?.use { it.write(bytes) } != null
        }.getOrDefault(false)
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(target, values, null, null)
        if (written) {
            target
        } else {
            runCatching { resolver.delete(target, null, null) }
            null
        }
    } else {
        // Android 8 and 9: save in the app's own picture folder (no storage permission needed).
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
        val file = File(folder, fileName)
        runCatching { FileOutputStream(file).use { it.write(bytes) } }.getOrNull() ?: return null
        Uri.fromFile(file)
    }
}

/** Small GIF writer: one shared 256-colour palette, standard LZW. No libraries needed. */
private class GifEncoder(private val width: Int, private val height: Int) {

    fun encode(frames: List<IntArray>, delayCentis: Int): ByteArray {
        val quantizer = Quantizer(frames)
        val out = ByteArrayOutputStream(frames.size * 24_000)
        out.write("GIF89a".toByteArray())
        writeShort(out, width)
        writeShort(out, height)
        out.write(0xF7) // global colour table, 256 colours
        out.write(0)
        out.write(0)
        for (colour in quantizer.palette) {
            out.write((colour shr 16) and 0xFF)
            out.write((colour shr 8) and 0xFF)
            out.write(colour and 0xFF)
        }
        // Loop forever.
        out.write(byteArrayOf(0x21, 0xFF.toByte(), 0x0B))
        out.write("NETSCAPE2.0".toByteArray())
        out.write(byteArrayOf(0x03, 0x01, 0x00, 0x00, 0x00))

        val lzw = LzwWriter(out)
        val indices = ByteArray(width * height)
        for (pixels in frames) {
            for (i in pixels.indices) indices[i] = quantizer.indexOf(pixels[i] and 0xFFFFFF).toByte()
            out.write(byteArrayOf(0x21, 0xF9.toByte(), 0x04, 0x04))
            writeShort(out, delayCentis)
            out.write(0)
            out.write(0)
            out.write(0x2C)
            writeShort(out, 0)
            writeShort(out, 0)
            writeShort(out, width)
            writeShort(out, height)
            out.write(0)
            lzw.encode(indices)
        }
        out.write(0x3B)
        return out.toByteArray()
    }

    private fun writeShort(out: ByteArrayOutputStream, value: Int) {
        out.write(value and 0xFF)
        out.write((value shr 8) and 0xFF)
    }
}

/** Picks the 256 best colours for all frames (median cut on a 5-bit colour histogram). */
private class Quantizer(frames: List<IntArray>) {
    val palette = IntArray(256)
    private var paletteSize = 1
    private val lookup = IntArray(32768) { -1 }

    init {
        val histogram = IntArray(32768)
        for (pixels in frames) {
            var i = 0
            while (i < pixels.size) {
                histogram[keyOf(pixels[i])]++
                i += 4
            }
        }
        val used = ArrayList<Int>()
        for (key in histogram.indices) if (histogram[key] > 0) used.add(key)
        val boxes = ArrayList<IntArray>()
        boxes.add(used.toIntArray())
        while (boxes.size < 256) {
            var best = -1
            var bestCount = -1L
            for (index in boxes.indices) {
                val box = boxes[index]
                if (box.size < 2) continue
                var count = 0L
                for (key in box) count += histogram[key]
                if (count > bestCount) {
                    bestCount = count
                    best = index
                }
            }
            if (best < 0) break
            val box = boxes[best]
            val channel = widestChannel(box)
            val sorted = box.sortedBy { channelOf(it, channel) }
            var running = 0L
            var split = 1
            for (position in sorted.indices) {
                running += histogram[sorted[position]]
                if (running * 2 >= bestCount) {
                    split = (position + 1).coerceIn(1, sorted.size - 1)
                    break
                }
            }
            boxes[best] = sorted.subList(0, split).toIntArray()
            boxes.add(sorted.subList(split, sorted.size).toIntArray())
        }
        paletteSize = boxes.size.coerceAtLeast(1)
        for (index in boxes.indices) {
            var total = 0L
            var r = 0L
            var g = 0L
            var b = 0L
            for (key in boxes[index]) {
                val weight = histogram[key].toLong()
                total += weight
                r += weight * channelOf(key, 0)
                g += weight * channelOf(key, 1)
                b += weight * channelOf(key, 2)
            }
            if (total == 0L) continue
            palette[index] = (expand((r / total).toInt()) shl 16) or
                (expand((g / total).toInt()) shl 8) or
                expand((b / total).toInt())
        }
    }

    fun indexOf(rgb: Int): Int {
        val key = keyOf(rgb)
        val cached = lookup[key]
        if (cached >= 0) return cached
        val r = expand(channelOf(key, 0))
        val g = expand(channelOf(key, 1))
        val b = expand(channelOf(key, 2))
        var best = 0
        var bestDistance = Int.MAX_VALUE
        for (index in 0 until paletteSize) {
            val colour = palette[index]
            val dr = r - ((colour shr 16) and 0xFF)
            val dg = g - ((colour shr 8) and 0xFF)
            val db = b - (colour and 0xFF)
            val distance = dr * dr + dg * dg + db * db
            if (distance < bestDistance) {
                bestDistance = distance
                best = index
            }
        }
        lookup[key] = best
        return best
    }

    private fun keyOf(rgb: Int): Int =
        (((rgb shr 19) and 31) shl 10) or (((rgb shr 11) and 31) shl 5) or ((rgb shr 3) and 31)

    /** channel 0 = red, 1 = green, 2 = blue, each 0..31. */
    private fun channelOf(key: Int, channel: Int): Int = when (channel) {
        0 -> (key shr 10) and 31
        1 -> (key shr 5) and 31
        else -> key and 31
    }

    private fun expand(value5: Int): Int = (value5 shl 3) or 4

    private fun widestChannel(box: IntArray): Int {
        val min = intArrayOf(31, 31, 31)
        val max = intArrayOf(0, 0, 0)
        for (key in box) {
            for (channel in 0..2) {
                val value = channelOf(key, channel)
                if (value < min[channel]) min[channel] = value
                if (value > max[channel]) max[channel] = value
            }
        }
        var widest = 0
        for (channel in 1..2) {
            if (max[channel] - min[channel] > max[widest] - min[widest]) widest = channel
        }
        return widest
    }
}

private const val HASH_BITS = 14
private const val HASH_SIZE = 1 shl HASH_BITS

/** GIF-flavoured LZW with 8-bit pixels. */
private class LzwWriter(private val out: ByteArrayOutputStream) {
    private val hashKeys = IntArray(HASH_SIZE)
    private val hashCodes = IntArray(HASH_SIZE)
    private val packet = ByteArray(256)
    private var packetLength = 0
    private var accumulator = 0
    private var accumulatedBits = 0
    private var codeBits = 0
    private var maxCode = 0
    private var freeEntry = 0
    private var clearPending = false

    fun encode(pixels: ByteArray) {
        out.write(8) // smallest code size
        hashKeys.fill(-1)
        freeEntry = CLEAR_CODE + 2
        codeBits = INITIAL_BITS
        maxCode = (1 shl codeBits) - 1
        clearPending = false
        accumulator = 0
        accumulatedBits = 0
        packetLength = 0

        emit(CLEAR_CODE)
        var current = pixels[0].toInt() and 0xFF
        for (i in 1 until pixels.size) {
            val next = pixels[i].toInt() and 0xFF
            val key = (next shl 12) or current
            var slot = (key * -1640531535) ushr (32 - HASH_BITS)
            var found = false
            while (hashKeys[slot] != -1) {
                if (hashKeys[slot] == key) {
                    found = true
                    break
                }
                slot = (slot + 1) and (HASH_SIZE - 1)
            }
            if (found) {
                current = hashCodes[slot]
                continue
            }
            emit(current)
            current = next
            if (freeEntry < 4096) {
                hashKeys[slot] = key
                hashCodes[slot] = freeEntry++
            } else {
                hashKeys.fill(-1)
                freeEntry = CLEAR_CODE + 2
                clearPending = true
                emit(CLEAR_CODE)
            }
        }
        emit(current)
        emit(EOF_CODE)
        out.write(0)
    }

    private fun emit(code: Int) {
        accumulator = accumulator or (code shl accumulatedBits)
        accumulatedBits += codeBits
        while (accumulatedBits >= 8) {
            addByte(accumulator and 0xFF)
            accumulator = accumulator ushr 8
            accumulatedBits -= 8
        }
        if (freeEntry > maxCode || clearPending) {
            if (clearPending) {
                codeBits = INITIAL_BITS
                maxCode = (1 shl codeBits) - 1
                clearPending = false
            } else {
                codeBits++
                maxCode = if (codeBits == 12) 4096 else (1 shl codeBits) - 1
            }
        }
        if (code == EOF_CODE) {
            while (accumulatedBits > 0) {
                addByte(accumulator and 0xFF)
                accumulator = accumulator ushr 8
                accumulatedBits -= 8
            }
            flushPacket()
        }
    }

    private fun addByte(value: Int) {
        packet[packetLength++] = value.toByte()
        if (packetLength >= 254) flushPacket()
    }

    private fun flushPacket() {
        if (packetLength > 0) {
            out.write(packetLength)
            out.write(packet, 0, packetLength)
            packetLength = 0
        }
    }

    private companion object {
        const val CLEAR_CODE = 256
        const val EOF_CODE = 257
        const val INITIAL_BITS = 9
    }
}
