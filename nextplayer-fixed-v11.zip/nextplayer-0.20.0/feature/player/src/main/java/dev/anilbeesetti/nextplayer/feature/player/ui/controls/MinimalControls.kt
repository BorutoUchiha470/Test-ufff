package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import androidx.annotation.OptIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.LineBreak
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util.getStringForTime
import androidx.media3.ui.compose.state.ProgressStateWithTickInterval
import androidx.media3.ui.compose.state.rememberRepeatButtonState
import androidx.media3.ui.compose.state.rememberShuffleButtonState
import dev.anilbeesetti.nextplayer.core.model.VideoContentScale
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.extensions.copy
import dev.anilbeesetti.nextplayer.core.ui.extras.LocalExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.extras.playerIconPainter
import dev.anilbeesetti.nextplayer.feature.player.LocalControlsVisibilityState
import dev.anilbeesetti.nextplayer.feature.player.buttons.NextButton
import dev.anilbeesetti.nextplayer.feature.player.buttons.PlayPauseButton
import dev.anilbeesetti.nextplayer.feature.player.buttons.PlayerButton
import dev.anilbeesetti.nextplayer.feature.player.buttons.PreviousButton
import dev.anilbeesetti.nextplayer.feature.player.buttons.RotateButton
import dev.anilbeesetti.nextplayer.feature.player.extensions.drawableRes
import dev.anilbeesetti.nextplayer.feature.player.state.ChaptersState
import dev.anilbeesetti.nextplayer.feature.player.model.labelRes
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.DecoderMode
import kotlin.time.Duration

private const val MILLISECONDS_PER_SECOND = 1_000L

/**
 * "Minimal" layout (Samsung Video style): title + CC + menu on top,
 * and a calm bottom area with the seek bar and one row of main controls.
 * Everything that is not on screen is inside the three-dot menu.
 */
@OptIn(UnstableApi::class)
@Composable
fun MinimalControlsTopView(
    player: Player?,
    title: String,
    videoDecoderMode: DecoderMode?,
    hasChapters: Boolean,
    onSubtitleClick: () -> Unit,
    onAudioClick: () -> Unit,
    onPlaylistClick: () -> Unit,
    onDecoderClick: () -> Unit,
    onPlaybackSpeedClick: () -> Unit,
    onChaptersClick: () -> Unit,
    onPlayInBackgroundClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val systemBarsPadding = WindowInsets.systemBars.union(WindowInsets.displayCutout).asPaddingValues()
    val extraTopPadding = if (systemBarsPadding.calculateTopPadding() == 0.dp) 16.dp else 0.dp
    val controls = LocalControlsVisibilityState.current
    val extras = LocalExtraFeatures.current
    var menuOpen by remember { mutableStateOf(false) }
    var showSleepDialog by remember { mutableStateOf(false) }
    val repeatState = rememberRepeatButtonState(player = player)
    val shuffleState = rememberShuffleButtonState(player = player)

    // While the menu or a dialog is open, the controls must not fade away under it.
    fun hold() = controls?.showControls(duration = Duration.INFINITE)
    fun release() = controls?.showControls()

    Row(
        modifier = modifier
            .padding(systemBarsPadding.copy(bottom = 0.dp))
            .padding(horizontal = 16.dp)
            .padding(bottom = 8.dp)
            .padding(top = extraTopPadding)
            .focusGroup(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(lineBreak = LineBreak.Heading),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(weight = 1f)
                .padding(start = 8.dp),
        )
        PlayerButton(onClick = onAudioClick) {
            Icon(
                painter = playerIconPainter(R.drawable.ic_audio_track),
                contentDescription = stringResource(R.string.audio_track),
            )
        }
        PlayerButton(onClick = onSubtitleClick) {
            Text(
                text = "CC",
                style = MaterialTheme.typography.titleMedium,
                color = Color.White,
            )
        }
        Box {
            PlayerButton(
                onClick = {
                    menuOpen = true
                    hold()
                },
            ) {
                Icon(
                    painter = playerIconPainter(R.drawable.ic_more_vert),
                    contentDescription = stringResource(R.string.more),
                )
            }
            DropdownMenu(
                expanded = menuOpen,
                onDismissRequest = {
                    menuOpen = false
                    release()
                },
            ) {
                MenuRow(stringResource(R.string.playlists)) {
                    menuOpen = false; release(); onPlaylistClick()
                }
                MenuRow(
                    stringResource(R.string.select_decoders) + " (" +
                        stringResource((videoDecoderMode ?: DecoderMode.HARDWARE).labelRes) + ")",
                ) {
                    menuOpen = false; release(); onDecoderClick()
                }
                MenuRow(stringResource(R.string.select_playback_speed)) {
                    menuOpen = false; release(); onPlaybackSpeedClick()
                }
                if (hasChapters) {
                    MenuRow(stringResource(R.string.chapters)) {
                        menuOpen = false; release(); onChaptersClick()
                    }
                }
                MenuRow(stringResource(R.string.background_play)) {
                    menuOpen = false; release(); onPlayInBackgroundClick()
                }
                MenuRow(
                    when (repeatState.repeatModeState) {
                        Player.REPEAT_MODE_OFF -> stringResource(R.string.loop_mode_off)
                        Player.REPEAT_MODE_ONE -> stringResource(R.string.loop_mode_one)
                        else -> stringResource(R.string.loop_mode_all)
                    },
                ) { repeatState.onClick() }
                MenuRow(
                    if (shuffleState.shuffleOn) {
                        stringResource(R.string.shuffle_on)
                    } else {
                        stringResource(R.string.shuffle_off)
                    },
                ) { shuffleState.onClick() }
                if (extras?.sleepTimerButton != false) {
                    MenuRow(stringResource(R.string.sleep_timer)) {
                        menuOpen = false
                        showSleepDialog = true
                    }
                }
                if (extras != null) {
                    MenuRow(
                        stringResource(R.string.extra_enhancer) +
                            if (extras.enhancerEnabled) " ✓" else "",
                    ) { extras.updateEnhancerEnabled(!extras.enhancerEnabled) }
                }
            }
        }
    }

    if (showSleepDialog) {
        SleepTimerDialog(
            onDismiss = {
                showSleepDialog = false
                release()
            },
        )
    }
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text = text) }, onClick = onClick)
}

@OptIn(UnstableApi::class)
@Composable
fun MinimalControlsBottomView(
    player: Player?,
    progressState: ProgressStateWithTickInterval,
    chaptersState: ChaptersState,
    videoContentScale: VideoContentScale,
    isPipSupported: Boolean,
    showRemainingTime: Boolean,
    onToggleTimeDisplay: () -> Unit,
    onVideoContentScaleClick: () -> Unit,
    onVideoContentScaleLongClick: () -> Unit,
    onLockControlsClick: () -> Unit,
    onPictureInPictureClick: () -> Unit,
    onSeek: (Long) -> Unit,
    onSeekEnd: () -> Unit,
    modifier: Modifier = Modifier,
    playPauseModifier: Modifier = Modifier,
) {
    val systemBarsPadding = WindowInsets.systemBars.union(WindowInsets.displayCutout).asPaddingValues()
    val extraFeatures = LocalExtraFeatures.current
    val positionMs by remember(progressState) {
        derivedStateOf {
            (progressState.currentPositionMs / MILLISECONDS_PER_SECOND) * MILLISECONDS_PER_SECOND
        }
    }

    Column(
        modifier = modifier
            .padding(systemBarsPadding.copy(top = 0.dp))
            .padding(horizontal = 16.dp)
            .padding(
                bottom = 12.dp.takeIf { systemBarsPadding.calculateBottomPadding() == 0.dp } ?: 0.dp,
            ),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        // Row above the seek bar: pop-up (PiP) on the left, screen ratio on the right.
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (isPipSupported) {
                PlayerButton(onClick = onPictureInPictureClick) {
                    Icon(
                        painter = playerIconPainter(R.drawable.ic_pip),
                        contentDescription = stringResource(R.string.pip_settings),
                    )
                }
            }
            Box(modifier = Modifier.weight(weight = 1f))
            PlayerButton(
                onClick = onVideoContentScaleClick,
                onLongClick = onVideoContentScaleLongClick,
            ) {
                Icon(
                    painter = playerIconPainter(videoContentScale.drawableRes()),
                    contentDescription = stringResource(R.string.video_zoom),
                )
            }
        }
        PlayerSeekbar(
            position = progressState.currentPositionMs.toFloat(),
            duration = progressState.durationMs.toFloat(),
            chapters = chaptersState.chapters,
            onSeek = { onSeek(it.toLong()) },
            onSeekFinished = { onSeekEnd() },
            previewUri = player?.currentMediaItem?.localConfiguration?.uri
                ?.takeIf { extraFeatures?.seekPreview != false },
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = getStringForTime(positionMs),
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
            )
            Text(
                text = if (showRemainingTime && progressState.durationMs != C.TIME_UNSET) {
                    getStringForTime(positionMs - progressState.durationMs)
                } else {
                    getStringForTime(progressState.durationMs)
                },
                style = MaterialTheme.typography.labelLarge,
                color = Color.White,
                modifier = Modifier.clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onToggleTimeDisplay,
                ),
            )
        }
        // Main row: lock | previous, play/pause, next | rotate.
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(modifier = Modifier.weight(weight = 1f), contentAlignment = Alignment.CenterStart) {
                PlayerButton(onClick = onLockControlsClick) {
                    Icon(
                        painter = playerIconPainter(R.drawable.ic_lock_open),
                        contentDescription = null,
                    )
                }
            }
            Row(
                horizontalArrangement = Arrangement.spacedBy(40.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.focusGroup(),
            ) {
                PreviousButton(player = player)
                PlayPauseButton(player = player, modifier = playPauseModifier)
                NextButton(player = player)
            }
            Box(modifier = Modifier.weight(weight = 1f), contentAlignment = Alignment.CenterEnd) {
                RotateButton()
            }
        }
    }
}
