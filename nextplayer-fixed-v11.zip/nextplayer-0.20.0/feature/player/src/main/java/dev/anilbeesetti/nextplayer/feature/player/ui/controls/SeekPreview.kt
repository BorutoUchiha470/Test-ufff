package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.feature.player.extensions.formatted
import kotlin.math.roundToInt
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** True while the seek-bar preview picture is on screen (the centre seek pop-up hides then). */
val LocalSeekPreviewVisible = staticCompositionLocalOf<MutableState<Boolean>?> { null }

private const val THUMBNAIL_HEIGHT = 144
private const val FAST_BUCKET_MS = 1_000L
private const val EXACT_BUCKET_MS = 500L
private const val MAX_CACHED_FRAMES = 30

/** Reads small preview pictures from the video file. Only open while the user drags the seek bar. */
private class ThumbnailSource(
    private val context: Context,
    private val uri: Uri,
    private val thumbnailHeight: Int,
) {
    private val mutex = Mutex()
    private var retriever: MediaMetadataRetriever? = null
    private var released = false
    private var width = 320
    private var height = thumbnailHeight

    /** [exact] = the real frame at that time (slower); otherwise the nearest key frame (fast). */
    suspend fun frameAt(positionMs: Long, exact: Boolean): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (released) return@withLock null
            runCatching {
                val source = retriever ?: open().also { retriever = it }
                val timeUs = positionMs * 1_000L
                val option = if (exact) {
                    MediaMetadataRetriever.OPTION_CLOSEST
                } else {
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    source.getScaledFrameAtTime(timeUs, option, width, height)
                } else {
                    source.getFrameAtTime(timeUs, option)
                }
            }.getOrNull()
        }
    }

    private fun open(): MediaMetadataRetriever {
        val source = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> source.setDataSource(uri.toString(), HashMap<String, String>())
                else -> source.setDataSource(context, uri)
            }
            val videoWidth = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH,
            )?.toIntOrNull()
            val videoHeight = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT,
            )?.toIntOrNull()
            val rotation = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION,
            )?.toIntOrNull() ?: 0
            if (videoWidth != null && videoHeight != null && videoWidth > 0 && videoHeight > 0) {
                val shownWidth = if (rotation == 90 || rotation == 270) videoHeight else videoWidth
                val shownHeight = if (rotation == 90 || rotation == 270) videoWidth else videoHeight
                height = thumbnailHeight
                width = (thumbnailHeight * shownWidth.toFloat() / shownHeight).roundToInt()
                    .coerceAtLeast(1)
            }
        } catch (e: Throwable) {
            runCatching { source.release() }
            throw e
        }
        return source
    }

    /** Frees the decoder now but allows reading again next time. */
    fun closeReader() {
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                runCatching { retriever?.release() }
                retriever = null
            }
        }
    }

    fun release() {
        // Wait for a running read to finish before closing, then free the decoder.
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                released = true
                runCatching { retriever?.release() }
                retriever = null
            }
        }
    }
}

/**
 * Reads preview pictures only while the finger is on the seek bar (no background work).
 * Pictures already read are remembered, so dragging over the same place again is instant.
 */
@Stable
internal class SeekPreviewController(
    context: Context,
    uri: Uri,
    val scale: Float,
    thumbnailHeight: Int,
) {
    private val source = ThumbnailSource(context.applicationContext, uri, thumbnailHeight)
    private val cache = HashMap<Long, ImageBitmap>()
    private val exactCache = HashMap<Long, ImageBitmap>()
    private val failed = HashSet<Long>()
    private val failedExact = HashSet<Long>()

    var thumbnail by mutableStateOf<ImageBitmap?>(null)
        private set
    var aspect by mutableFloatStateOf(16f / 9f)
        private set

    fun release() = source.release()

    /** Called when the finger lifts, so the preview never keeps a decoder busy during playback. */
    fun closeReader() = source.closeReader()

    /**
     * Runs only while dragging. Moving: quick nearby key-frame pictures.
     * Finger resting for a moment: the exact frame of that very time, so the picture matches the time.
     *
     * A picture that finishes loading is always shown, even if the finger has moved on meanwhile:
     * a slightly late picture is better than a frozen one. The next round then loads the newer place.
     */
    suspend fun run(latestPositionMs: () -> Long, durationMs: () -> Long) {
        // Never start with the picture of the previous drag.
        thumbnail = null
        var lastPosition = -1L
        var restingRounds = 0
        while (true) {
            val position = latestPositionMs()
            val exactKey = position / EXACT_BUCKET_MS
            val fastKey = position / FAST_BUCKET_MS
            restingRounds = if (position == lastPosition) restingRounds + 1 else 0
            lastPosition = position
            // Exact frames can be slow to decode, so only ask for one when the finger has really paused.
            val resting = restingRounds >= 2

            val exactCached = exactCache[exactKey]
            if (exactCached != null) {
                thumbnail = exactCached
                delay(60)
                continue
            }

            if (resting && exactKey !in failedExact) {
                val frame = source.frameAt(exactKey * EXACT_BUCKET_MS, exact = true)
                if (frame != null) {
                    if (exactCache.size >= MAX_CACHED_FRAMES) exactCache.clear()
                    aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                    val image = frame.asImageBitmap()
                    exactCache[exactKey] = image
                    thumbnail = image
                } else {
                    failedExact.add(exactKey)
                }
                continue
            }

            val fastCached = cache[fastKey]
            if (fastCached != null) {
                thumbnail = fastCached
            } else if (fastKey !in failed) {
                var frame = source.frameAt(fastKey * FAST_BUCKET_MS, exact = false)
                if (frame == null) {
                    // Some files give no key-frame picture here; try the exact one instead.
                    frame = source.frameAt(fastKey * FAST_BUCKET_MS, exact = true)
                }
                if (frame != null) {
                    if (cache.size >= MAX_CACHED_FRAMES) cache.clear()
                    aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                    val image = frame.asImageBitmap()
                    cache[fastKey] = image
                    thumbnail = image
                } else {
                    failed.add(fastKey)
                }
            }
            delay(40)
        }
    }
}

@Composable
internal fun rememberSeekPreview(uri: Uri?): SeekPreviewController? {
    if (uri == null) return null
    val context = LocalContext.current
    val scale = rememberExtraFeatures().seekPreviewScale.coerceIn(0.5f, 2.2f)
    val thumbnailHeight = (THUMBNAIL_HEIGHT * scale).roundToInt().coerceIn(96, 320)
    val controller = remember(uri, thumbnailHeight) {
        SeekPreviewController(context, uri, scale, thumbnailHeight)
    }
    DisposableEffect(controller) { onDispose { controller.release() } }
    return controller
}

/** A small picture of the scene (and its time) floating above the seek bar while dragging. */
@Composable
internal fun SeekPreviewPopup(
    controller: SeekPreviewController,
    positionMs: Long,
    durationMs: Long,
    barWidthPx: Int,
) {
    val density = LocalDensity.current
    val scale = controller.scale
    val aspect = controller.aspect
    val thumbnail = controller.thumbnail
    val latestPositionMs by rememberUpdatedState(positionMs)
    val latestDurationMs by rememberUpdatedState(durationMs)
    LaunchedEffect(controller) { controller.run({ latestPositionMs }, { latestDurationMs }) }
    DisposableEffect(controller) { onDispose { controller.closeReader() } }

    // The picture box follows the video's own shape (wide, square or tall) inside a size limit.
    val maxWidth = (160 * scale).dp
    val maxHeight = (100 * scale).dp
    val limitAspect = maxWidth / maxHeight
    val popupWidth = if (aspect >= limitAspect) maxWidth else maxHeight * aspect
    val pictureHeight = if (aspect >= limitAspect) maxWidth / aspect else maxHeight
    val popupWidthPx = with(density) { popupWidth.roundToPx() }
    val popupHeightPx = with(density) { (pictureHeight + 28.dp).roundToPx() }
    val gapPx = with(density) { 12.dp.roundToPx() }
    val fraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
    } else {
        0f
    }
    val centerX = (fraction * barWidthPx).roundToInt()
    val x = (centerX - popupWidthPx / 2).coerceIn(0, (barWidthPx - popupWidthPx).coerceAtLeast(0))

    Popup(
        alignment = Alignment.TopStart,
        offset = IntOffset(x, -(popupHeightPx + gapPx)),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(width = popupWidth, height = pictureHeight)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                thumbnail?.let { picture ->
                    Image(
                        bitmap = picture,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Text(
                text = positionMs.milliseconds.formatted(),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
