package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable
import org.koin.compose.viewmodel.koinViewModel

@Serializable
object ShortsRoute : NavKey

/** List of the shorts the person has liked (opened from the You tab), styled like History. */
@Serializable
object LikedShortsRoute : NavKey

fun EntryProviderScope<NavKey>.shortsEntry(onPlayVideo: (String) -> Unit, onBack: () -> Unit) {
    entry<ShortsRoute> {
        ShortsScreen(
            viewModel = koinViewModel<ShortsViewModel>(),
            onOpenInPlayer = onPlayVideo,
            onBack = onBack,
        )
    }
}

fun EntryProviderScope<NavKey>.likedShortsEntry(onPlayVideo: (String) -> Unit, onBack: () -> Unit) {
    entry<LikedShortsRoute> {
        LikedShortsScreen(
            viewModel = koinViewModel<LikedShortsViewModel>(),
            onPlayVideo = onPlayVideo,
            onNavigateUp = onBack,
        )
    }
}

fun NavBackStack<NavKey>.navigateToLikedShorts() {
    add(element = LikedShortsRoute)
}
