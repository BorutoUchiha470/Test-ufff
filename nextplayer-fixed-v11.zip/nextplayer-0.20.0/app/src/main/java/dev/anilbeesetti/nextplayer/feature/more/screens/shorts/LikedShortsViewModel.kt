package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.anilbeesetti.nextplayer.core.data.repository.MediaRepository
import dev.anilbeesetti.nextplayer.core.data.repository.PreferencesRepository
import dev.anilbeesetti.nextplayer.core.model.ApplicationPreferences
import dev.anilbeesetti.nextplayer.core.model.Video
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import org.koin.core.annotation.KoinViewModel

/** Every video on the phone (the screen keeps only the liked ones) plus the list display preferences. */
@KoinViewModel
class LikedShortsViewModel(
    mediaRepository: MediaRepository,
    preferencesRepository: PreferencesRepository,
) : ViewModel() {

    private val videosInternal = MutableStateFlow<List<Video>?>(null)
    val videos: StateFlow<List<Video>?> = videosInternal.asStateFlow()

    private val preferencesInternal = MutableStateFlow(ApplicationPreferences())
    val preferences: StateFlow<ApplicationPreferences> = preferencesInternal.asStateFlow()

    init {
        viewModelScope.launch {
            mediaRepository.observeVideos()
                .catch { videosInternal.value = emptyList() }
                .collect { videosInternal.value = it }
        }
        viewModelScope.launch {
            preferencesRepository.applicationPreferences.collect { preferencesInternal.value = it }
        }
    }
}
