package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.NextDialog
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.tvFocusRing
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.extensions.copy
import dev.anilbeesetti.nextplayer.core.ui.shorts.ShortsPrefs
import dev.anilbeesetti.nextplayer.core.ui.theme.screenContainerColor
import dev.anilbeesetti.nextplayer.feature.videopicker.composables.CenterCircularProgressBar
import dev.anilbeesetti.nextplayer.feature.videopicker.composables.VideoListItem

/**
 * Everything the person has liked in Shorts, as a plain list (same look as History).
 * Tap a video to play it, long-press to take it out of the liked list.
 */
@Composable
fun LikedShortsScreen(
    viewModel: LikedShortsViewModel,
    onPlayVideo: (String) -> Unit,
    onNavigateUp: () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ShortsPrefs.get(context) }
    val allVideos by viewModel.videos.collectAsStateWithLifecycle()
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()

    // `prefs.liked` is snapshot state, so un-liking updates this list straight away.
    val likedUris = prefs.liked.toSet()
    val liked = remember(allVideos, likedUris) {
        allVideos?.filter { it.uriString in likedUris }?.sortedByDescending { it.dateAdded }
    }

    var showClearConfirmation by rememberSaveable { mutableStateOf(false) }
    var removeUri by rememberSaveable { mutableStateOf<String?>(null) }
    var menuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(R.string.you_liked),
                navigationIcon = {
                    FilledTonalIconButton(
                        onClick = onNavigateUp,
                        modifier = Modifier.tvFocusRing(),
                    ) {
                        Icon(
                            imageVector = NextIcons.ArrowBack,
                            contentDescription = stringResource(R.string.navigate_up),
                        )
                    }
                },
                actions = {
                    Box {
                        IconButton(
                            onClick = { menuExpanded = true },
                            modifier = Modifier.tvFocusRing(),
                        ) {
                            Icon(
                                imageVector = NextIcons.MoreVert,
                                contentDescription = stringResource(R.string.menu),
                            )
                        }
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                        ) {
                            DropdownMenuItem(
                                text = { Text(text = stringResource(R.string.liked_shorts_clear)) },
                                enabled = liked.orEmpty().isNotEmpty(),
                                onClick = {
                                    menuExpanded = false
                                    showClearConfirmation = true
                                },
                            )
                        }
                    }
                },
            )
        },
        containerColor = screenContainerColor(),
    ) { scaffoldPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(scaffoldPadding.copy(bottom = 0.dp))
                .clip(shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(MaterialTheme.colorScheme.background),
        ) {
            val videos = liked
            when {
                videos == null -> CenterCircularProgressBar()

                videos.isEmpty() -> LikedShortsEmptyState(
                    modifier = Modifier.fillMaxSize().verticalScroll(state = rememberScrollState()),
                )

                else -> LazyColumn(
                    contentPadding = PaddingValues(8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    itemsIndexed(videos, key = { _, video -> video.uriString }) { index, video ->
                        VideoListItem(
                            video = video,
                            isRecentlyPlayedVideo = false,
                            preferences = preferences,
                            isFirstItem = index == 0,
                            isLastItem = index == videos.lastIndex,
                            onClick = { onPlayVideo(video.uriString) },
                            onLongClick = { removeUri = video.uriString },
                        )
                    }
                }
            }
        }
    }

    if (showClearConfirmation) {
        NextDialog(
            onDismissRequest = { showClearConfirmation = false },
            title = { Text(text = stringResource(R.string.liked_shorts_clear)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        prefs.clearLiked()
                        showClearConfirmation = false
                    },
                ) { Text(text = stringResource(R.string.clear_all)) }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmation = false }) {
                    Text(text = stringResource(R.string.cancel))
                }
            },
            content = { Text(text = stringResource(R.string.liked_shorts_clear_confirmation)) },
        )
    }

    removeUri?.let { uri ->
        NextDialog(
            onDismissRequest = { removeUri = null },
            title = { Text(text = stringResource(R.string.liked_shorts_remove)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (uri in prefs.liked) prefs.toggleLike(uri)
                        removeUri = null
                    },
                ) { Text(text = stringResource(R.string.liked_shorts_remove_action)) }
            },
            dismissButton = {
                TextButton(onClick = { removeUri = null }) {
                    Text(text = stringResource(R.string.cancel))
                }
            },
            content = { Text(text = stringResource(R.string.liked_shorts_remove_confirmation)) },
        )
    }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun LikedShortsEmptyState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(horizontal = 24.dp, vertical = 40.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .clip(MaterialTheme.shapes.large)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = NextIcons.FavoriteBorder,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(40.dp),
            )
        }
        Spacer(modifier = Modifier.size(16.dp))
        Text(
            text = stringResource(R.string.liked_shorts_empty),
            style = MaterialTheme.typography.titleLargeEmphasized,
            textAlign = TextAlign.Center,
        )
    }
}
