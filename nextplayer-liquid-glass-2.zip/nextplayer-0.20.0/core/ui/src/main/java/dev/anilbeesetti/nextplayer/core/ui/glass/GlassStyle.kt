package dev.anilbeesetti.nextplayer.core.ui.glass

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private const val PREFS_NAME = "glass_style"
private const val KEY_ENABLED = "enabled"
private const val KEY_OPACITY = "opacity"
private const val KEY_EDGE = "edge"
private const val KEY_TINT = "tint"
private const val KEY_TYPE = "type"
private const val KEY_CORNER = "corner"
private const val KEY_GLOW = "glow"
private const val KEY_SHADOW = "shadow"
private const val KEY_DEPTH = "depth"
private const val KEY_CHROMATIC = "chromatic"
private const val KEY_VIBRANCY = "vibrancy"
private const val KEY_REAL = "real_glass"

private const val DEFAULT_OPACITY = 0.28f
private const val DEFAULT_EDGE = 0.55f
private const val DEFAULT_CORNER = 50
private val DEFAULT_TINT = 0xFF9DB7E0.toInt()

/** The four looks the user can pick. */
enum class GlassType { LIQUID, FROSTED, CLEAR, SOLID }

/** Colors the user can pick for the glass. */
val GlassTintPresets: List<Int> = listOf(
    0xFFFFFFFF.toInt(),
    0xFF9DB7E0.toInt(),
    0xFFFFB3D1.toInt(),
    0xFFC3A6FF.toInt(),
    0xFFA8F0D8.toInt(),
    0xFF2B2B2B.toInt(),
)

/** User-adjustable "liquid glass" look. Values are saved and shared by the player and the settings. */
@Stable
class GlassSettings(private val prefs: SharedPreferences) {
    var enabled by mutableStateOf(prefs.getBoolean(KEY_ENABLED, true))
        private set
    var opacity by mutableFloatStateOf(prefs.getFloat(KEY_OPACITY, DEFAULT_OPACITY))
        private set
    var edgeShine by mutableFloatStateOf(prefs.getFloat(KEY_EDGE, DEFAULT_EDGE))
        private set
    var tint by mutableIntStateOf(prefs.getInt(KEY_TINT, DEFAULT_TINT))
        private set
    var typeIndex by mutableIntStateOf(prefs.getInt(KEY_TYPE, 0))
        private set
    var cornerPercent by mutableIntStateOf(prefs.getInt(KEY_CORNER, DEFAULT_CORNER))
        private set
    var glow by mutableStateOf(prefs.getBoolean(KEY_GLOW, false))
        private set
    var shadow by mutableStateOf(prefs.getBoolean(KEY_SHADOW, false))
        private set
    var depth by mutableStateOf(prefs.getBoolean(KEY_DEPTH, true))
        private set
    var chromatic by mutableStateOf(prefs.getBoolean(KEY_CHROMATIC, false))
        private set
    var vibrancy by mutableStateOf(prefs.getBoolean(KEY_VIBRANCY, false))
        private set

    /** Real glass: blurs and bends the video / screen behind each control. Needs Android 12+. */
    var realGlass by mutableStateOf(prefs.getBoolean(KEY_REAL, true))
        private set

    val glassType: GlassType
        get() = GlassType.entries[typeIndex.coerceIn(0, GlassType.entries.size - 1)]

    val shape: Shape
        get() = RoundedCornerShape(percent = cornerPercent.coerceIn(0, 50))

    fun updateEnabled(value: Boolean) {
        enabled = value
        prefs.edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun updateOpacity(value: Float) {
        opacity = value
        prefs.edit().putFloat(KEY_OPACITY, value).apply()
    }

    fun updateEdgeShine(value: Float) {
        edgeShine = value
        prefs.edit().putFloat(KEY_EDGE, value).apply()
    }

    fun updateTint(value: Int) {
        tint = value
        prefs.edit().putInt(KEY_TINT, value).apply()
    }

    fun updateType(value: GlassType) {
        typeIndex = value.ordinal
        prefs.edit().putInt(KEY_TYPE, value.ordinal).apply()
    }

    fun updateCornerPercent(value: Int) {
        cornerPercent = value
        prefs.edit().putInt(KEY_CORNER, value).apply()
    }

    fun updateGlow(value: Boolean) {
        glow = value
        prefs.edit().putBoolean(KEY_GLOW, value).apply()
    }

    fun updateShadow(value: Boolean) {
        shadow = value
        prefs.edit().putBoolean(KEY_SHADOW, value).apply()
    }

    fun updateDepth(value: Boolean) {
        depth = value
        prefs.edit().putBoolean(KEY_DEPTH, value).apply()
    }

    fun updateChromatic(value: Boolean) {
        chromatic = value
        prefs.edit().putBoolean(KEY_CHROMATIC, value).apply()
    }

    fun updateVibrancy(value: Boolean) {
        vibrancy = value
        prefs.edit().putBoolean(KEY_VIBRANCY, value).apply()
    }

    fun updateRealGlass(value: Boolean) {
        realGlass = value
        prefs.edit().putBoolean(KEY_REAL, value).apply()
    }

    fun reset() {
        updateRealGlass(true)
        updateEnabled(true)
        updateOpacity(DEFAULT_OPACITY)
        updateEdgeShine(DEFAULT_EDGE)
        updateTint(DEFAULT_TINT)
        updateType(GlassType.LIQUID)
        updateCornerPercent(DEFAULT_CORNER)
        updateGlow(false)
        updateShadow(false)
        updateDepth(true)
        updateChromatic(false)
        updateVibrancy(false)
    }
}

/** One shared copy, so the player, the settings and the presets always agree. */
object GlassStore {
    @Volatile
    private var instance: GlassSettings? = null

    fun get(context: Context): GlassSettings {
        return instance ?: synchronized(this) {
            instance ?: GlassSettings(
                context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}

@Composable
fun rememberGlassSettings(): GlassSettings {
    val context = LocalContext.current
    return remember { GlassStore.get(context) }
}

/** Provided by the player screen so every control can use the same glass look. */
val LocalGlassSettings = staticCompositionLocalOf<GlassSettings?> { null }

private fun Color.boostSaturation(factor: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(this.toArgb(), hsv)
    hsv[1] = (hsv[1] * factor).coerceIn(0f, 1f)
    return Color(android.graphics.Color.HSVToColor(hsv)).copy(alpha = this.alpha)
}

/**
 * Painted glass look (tinted gradient, bright rim, optional glow / shadow / depth).
 * Used when real glass is off or not possible (old Android, no backdrop to look through).
 */
internal fun Modifier.paintedGlassSurface(settings: GlassSettings, shape: Shape): Modifier {
    val type = settings.glassType
    var tint = Color(settings.tint)
    if (settings.vibrancy) tint = tint.boostSaturation(1.4f)
    val base = settings.opacity

    val topAlpha: Float
    val bottomAlpha: Float
    val rimScale: Float
    val underlayAlpha: Float
    when (type) {
        GlassType.LIQUID -> {
            topAlpha = base * 1.35f
            bottomAlpha = base * 0.65f
            rimScale = 1f
            underlayAlpha = 0.18f
        }
        GlassType.FROSTED -> {
            topAlpha = base * 1.1f + 0.12f
            bottomAlpha = base * 1.1f + 0.12f
            rimScale = 0.5f
            underlayAlpha = 0.10f
        }
        GlassType.CLEAR -> {
            topAlpha = base * 0.4f
            bottomAlpha = base * 0.15f
            rimScale = 1.2f
            underlayAlpha = 0.08f
        }
        else -> {
            topAlpha = 0.92f
            bottomAlpha = 0.92f
            rimScale = 0f
            underlayAlpha = 0f
        }
    }

    val fillTint = if (type == GlassType.FROSTED) lerp(tint, Color.White, 0.35f) else tint
    val fill = Brush.verticalGradient(
        colors = listOf(
            fillTint.copy(alpha = topAlpha.coerceIn(0f, 1f)),
            fillTint.copy(alpha = bottomAlpha.coerceIn(0f, 1f)),
        ),
    )
    val rimAlpha = (settings.edgeShine * rimScale).coerceIn(0f, 1f)
    val rim = if (settings.chromatic) {
        Brush.sweepGradient(
            colors = listOf(
                Color(0xFF00E5FF).copy(alpha = rimAlpha),
                Color.White.copy(alpha = rimAlpha * 0.25f),
                Color(0xFFFF4081).copy(alpha = rimAlpha),
                Color.White.copy(alpha = rimAlpha * 0.25f),
                Color(0xFF00E5FF).copy(alpha = rimAlpha),
            ),
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = rimAlpha),
                Color.White.copy(alpha = rimAlpha * 0.12f),
                Color.White.copy(alpha = rimAlpha * 0.7f),
            ),
        )
    }

    var result: Modifier = this
    if (settings.shadow) {
        result = result.shadow(elevation = 6.dp, shape = shape, clip = false)
    }
    if (settings.glow) {
        result = result.shadow(
            elevation = 12.dp,
            shape = shape,
            clip = false,
            ambientColor = tint.copy(alpha = 0.9f),
            spotColor = tint.copy(alpha = 0.9f),
        )
    }
    result = result.clip(shape)
    if (underlayAlpha > 0f) {
        result = result.background(color = Color.Black.copy(alpha = underlayAlpha), shape = shape)
    }
    result = result.background(brush = fill, shape = shape)
    if (settings.depth) {
        result = result.background(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.18f),
                    Color.Transparent,
                    Color.Black.copy(alpha = 0.22f),
                ),
            ),
            shape = shape,
        )
    }
    if (rimAlpha > 0f) {
        result = result.border(width = 1.dp, brush = rim, shape = shape)
    }
    return result
}
