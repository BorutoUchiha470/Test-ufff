package dev.anilbeesetti.nextplayer.core.model

import kotlin.comparisons.reversed as kotlinReversed

data class Sort(val by: By, val order: Order) {
    enum class By {
        TITLE,
        LENGTH,
        PATH,
        SIZE,
        DATE,
    }

    enum class Order {
        ASCENDING,
        DESCENDING,
    }

    private val stringComparator = Comparator<String> { str1, str2 ->
        var str1Marker = 0
        var str2Marker = 0
        val str1Length = str1.length
        val str2Length = str2.length

        while (str1Marker < str1Length && str2Marker < str2Length) {
            val thisChunk = getChunk(
                string = str1,
                length = str1Length,
                marker = str1Marker,
            )
            str1Marker += thisChunk.length

            val thatChunk = getChunk(
                string = str2,
                length = str2Length,
                marker = str2Marker,
            )
            str2Marker += thatChunk.length

            // If both chunks contain numeric characters, sort them numerically.
            val result: Int
            if (thisChunk[0].isAsciiDigit() && thatChunk[0].isAsciiDigit()) {
                // Simple chunk comparison by length.
                val thisChunkLength = thisChunk.length
                val lengthDiff = thisChunkLength - thatChunk.length
                // If equal, the first different number counts.
                if (lengthDiff == 0) {
                    for (i in 0 until thisChunkLength) {
                        val charDiff = thisChunk[i] - thatChunk[i]
                        if (charDiff != 0) {
                            return@Comparator charDiff
                        }
                    }
                    result = 0
                } else {
                    result = lengthDiff
                }
            } else {
                result = thisChunk.compareTo(other = thatChunk)
            }

            if (result != 0) {
                return@Comparator result
            }
        }

        return@Comparator str1Length - str2Length
    }

    fun videoComparator(): Comparator<Video> {
        val videoTitleComparator: Comparator<Video> = Comparator { video1, video2 ->
            return@Comparator stringComparator.compare(
                video1.displayName.lowercase(),
                video2.displayName.lowercase(),
            )
        }

        val videoPathComparator: Comparator<Video> = Comparator { video1, video2 ->
            return@Comparator stringComparator.compare(
                video1.path.lowercase(),
                video2.path.lowercase(),
            )
        }

        val comparator = when (by) {
            By.TITLE -> videoTitleComparator
            By.LENGTH -> compareBy<Video> { it.duration }.then(comparator = videoTitleComparator)
            By.PATH -> videoPathComparator
            By.SIZE -> compareBy<Video> { it.size }.then(comparator = videoTitleComparator)
            By.DATE -> compareBy<Video> { it.dateModified }.then(comparator = videoTitleComparator)
        }

        return when (order) {
            Order.ASCENDING -> comparator
            Order.DESCENDING -> comparator.reversedCompat()
        }
    }

    fun folderComparator(): Comparator<Folder> {
        val folderNameComparator: Comparator<Folder> = Comparator { folder1, folder2 ->
            return@Comparator stringComparator.compare(
                folder1.name.lowercase(),
                folder2.name.lowercase(),
            )
        }

        val folderPathComparator: Comparator<Folder> = Comparator { folder1, folder2 ->
            return@Comparator stringComparator.compare(
                folder1.path.lowercase(),
                folder2.path.lowercase(),
            )
        }

        val comparator = when (by) {
            By.TITLE -> folderNameComparator

            By.LENGTH -> compareBy<Folder> {
                it.totalDuration
            }.then(comparator = folderNameComparator)

            By.PATH -> folderPathComparator

            By.SIZE -> compareBy<Folder> { it.totalSize }.then(comparator = folderNameComparator)

            By.DATE -> compareBy<Folder> { it.dateModified }.then(comparator = folderNameComparator)
        }

        return when (order) {
            Order.ASCENDING -> comparator
            Order.DESCENDING -> comparator.reversedCompat()
        }
    }

    fun networkFileComparator(): Comparator<NetworkFile> {
        val nameComparator = Comparator<NetworkFile> { first, second ->
            stringComparator.compare(
                first.name.lowercase(),
                second.name.lowercase(),
            )
        }
        val comparator = when (by) {
            By.TITLE, By.LENGTH -> nameComparator

            By.PATH -> Comparator<NetworkFile> { first, second ->
                stringComparator.compare(
                    first.path.lowercase(),
                    second.path.lowercase(),
                )
            }

            By.SIZE -> compareBy<NetworkFile> { it.size }.then(comparator = nameComparator)

            By.DATE -> compareBy<NetworkFile> {
                it.modified ?: 0L
            }.then(comparator = nameComparator)
        }.thenBy { it.path }
        val orderedComparator = when (order) {
            Order.ASCENDING -> comparator
            Order.DESCENDING -> comparator.reversedCompat()
        }
        // Keep folders first regardless of the selected sort direction.
        return compareByDescending<NetworkFile> {
            it.isDirectory
        }.then(comparator = orderedComparator)
    }

    private fun getChunk(string: String, length: Int, marker: Int): String {
        var current = marker
        val chunk = StringBuilder()
        var c = string[current]
        chunk.append(c)
        current++
        if (c.isAsciiDigit()) {
            while (current < length) {
                c = string[current]
                if (!c.isAsciiDigit()) {
                    break
                }
                chunk.append(c)
                current++
            }
        } else {
            while (current < length) {
                c = string[current]
                if (c.isAsciiDigit()) {
                    break
                }
                chunk.append(c)
                current++
            }
        }
        return chunk.toString()
    }
}

// The length-based numeric ordering is contract-safe only for the contiguous ASCII digit range.
private fun Char.isAsciiDigit(): Boolean = this in '0'..'9'

fun <T> Comparator<T>.reversedCompat(): Comparator<T> = kotlinReversed()
