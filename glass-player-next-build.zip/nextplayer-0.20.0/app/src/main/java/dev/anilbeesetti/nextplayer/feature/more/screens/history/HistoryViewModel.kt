package dev.anilbeesetti.nextplayer.feature.more.screens.history

import androidx.lifecycle.viewModelScope
import dev.anilbeesetti.nextplayer.core.data.repository.MediaRepository
import dev.anilbeesetti.nextplayer.core.data.repository.PreferencesRepository
import dev.anilbeesetti.nextplayer.core.model.ApplicationPreferences
import dev.anilbeesetti.nextplayer.core.model.Video
import dev.anilbeesetti.nextplayer.core.ui.base.DataState
import dev.anilbeesetti.nextplayer.core.ui.base.MviViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.InjectedParam
import org.koin.core.annotation.KoinViewModel

@KoinViewModel
class HistoryViewModel(
    private val mediaRepository: MediaRepository,
    private val preferencesRepository: PreferencesRepository,
    @InjectedParam internal var output: Output,
) : MviViewModel<HistoryUiState, HistoryAction>() {

    data class Output(val navigateUp: () -> Unit, val playVideo: (String) -> Unit)

    private val stateInternal = MutableStateFlow(value = HistoryUiState())
    override val state: StateFlow<HistoryUiState> = stateInternal.asStateFlow()

    init {
        viewModelScope.launch {
            mediaRepository.observePlaybackHistory()
                .catch { error ->
                    stateInternal.update { it.copy(history = DataState.Error(value = error)) }
                }
                .collect { history ->
                    stateInternal.update { it.copy(history = DataState.Success(value = history)) }
                }
        }
        viewModelScope.launch {
            preferencesRepository.applicationPreferences.collect { preferences ->
                stateInternal.update { it.copy(preferences = preferences) }
            }
        }
    }

    override fun onAction(action: HistoryAction) {
        when (action) {
            is HistoryAction.NavigateUp -> output.navigateUp()

            is HistoryAction.PlayVideo -> output.playVideo(action.uri)

            is HistoryAction.ClearHistory -> clearHistory()

            is HistoryAction.SetHistoryEnabled -> viewModelScope.launch {
                preferencesRepository.updateApplicationPreferences {
                    it.copy(isHistoryPaused = !action.enabled)
                }
                if (!action.enabled) mediaRepository.clearPlaybackHistory()
            }
        }
    }

    private fun clearHistory() {
        viewModelScope.launch { mediaRepository.clearPlaybackHistory() }
    }
}

data class HistoryUiState(
    val history: DataState<List<Video>> = DataState.Loading,
    val preferences: ApplicationPreferences = ApplicationPreferences(),
)

sealed interface HistoryAction {
    data object NavigateUp : HistoryAction
    data class PlayVideo(val uri: String) : HistoryAction

    data object ClearHistory : HistoryAction
    data class SetHistoryEnabled(val enabled: Boolean) : HistoryAction
}
