package dev.anilbeesetti.nextplayer.feature.player.model

/**
 * What the player service reports about the sleep timer.
 * [endsAtRealtimeMs] is an [android.os.SystemClock.elapsedRealtime] value, or 0 when no timed timer runs.
 */
data class SleepTimerStatus(
    val endsAtRealtimeMs: Long = 0L,
    val atEndOfVideo: Boolean = false,
) {
    val isActive: Boolean get() = endsAtRealtimeMs > 0L || atEndOfVideo
}
