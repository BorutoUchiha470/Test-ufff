package dev.anilbeesetti.nextplayer.feature.player.state

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.state.PlayerStateObserver
import androidx.media3.ui.compose.state.observeState
import dev.anilbeesetti.nextplayer.feature.player.extensions.switchTrack

@UnstableApi
@Composable
fun rememberTracksState(player: Player?, trackType: @C.TrackType Int): TracksState {
    val tracksState = remember(player) {
        TracksState(
            player = player,
            trackType = trackType,
        )
    }
    LaunchedEffect(key1 = player) { tracksState.observe() }
    return tracksState
}

@UnstableApi
class TracksState(private val player: Player?, private val trackType: @C.TrackType Int) {
    var tracks: List<Tracks.Group> by mutableStateOf(value = emptyList())
        private set

    private val playerStateObserver: PlayerStateObserver? =
        player?.observeState(Player.EVENT_TRACKS_CHANGED) { updateTracks() }

    fun switchTrack(index: Int) {
        player?.switchTrack(
            trackType = trackType,
            trackIndex = index,
        )
    }

    suspend fun observe() {
        updateTracks()
        playerStateObserver?.observe()
    }

    private fun updateTracks() {
        tracks = player?.currentTracks?.groups
            ?.filter { it.type == trackType && it.isSupported } ?: emptyList()
    }
}
