package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import androidx.annotation.OptIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.util.Util.getStringForTime
import dev.anilbeesetti.nextplayer.core.ui.glass.LocalGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.feature.player.state.rememberMetadataState
import kotlin.math.max
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

private const val CACHE_BYTES = 8 * 1024 * 1024
private const val THUMBNAIL_WIDTH_PX = 256
private const val MICROS_PER_MILLI = 1_000L
private const val FRAMES_ACROSS_SEEKBAR = 150L
private const val MIN_BUCKET_MS = 500L
private const val DEBOUNCE_MS = 40L

/**
 * Reads small preview frames for the seek bar from the video file. The file is only opened the
 * first time a frame is asked for, so nothing happens unless the user actually scrubs.
 * Only local files (`content://` and `file://`) are supported; network streams show the time only.
 */
internal class SeekThumbnailProvider(
    private val context: Context,
    private val uri: Uri,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val retriever = MediaMetadataRetriever()
    private val cache = object : LruCache<Long, Bitmap>(CACHE_BYTES) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.byteCount
    }
    private var prepared = false
    private var released = false
    private var usable = true

    var aspectRatio: Float = DEFAULT_ASPECT_RATIO
        private set

    suspend fun frameAt(positionMs: Long, bucketKey: Long): Bitmap? {
        cache.get(bucketKey)?.let { return it }
        return withContext(Dispatchers.IO) {
            mutex.withLock {
                if (released || !usable) return@withLock null
                if (!prepared) prepare()
                if (!usable) return@withLock null
                cache.get(bucketKey)
                    ?: runCatching { readFrame(positionMs) }.getOrNull()
                        ?.also { cache.put(bucketKey, it) }
            }
        }
    }

    private fun prepare() {
        prepared = true
        usable = runCatching {
            retriever.setDataSource(context, uri)
            val width = retriever.metadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
            val height = retriever.metadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
            val rotation = retriever.metadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            if (width != null && height != null && width > 0 && height > 0) {
                val rotated = rotation == 90 || rotation == 270
                aspectRatio = if (rotated) height.toFloat() / width else width.toFloat() / height
            }
            true
        }.getOrDefault(false)
    }

    private fun readFrame(positionMs: Long): Bitmap? {
        val timeUs = positionMs * MICROS_PER_MILLI
        val height = (THUMBNAIL_WIDTH_PX / aspectRatio).roundToInt().coerceAtLeast(1)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            retriever.getScaledFrameAtTime(
                timeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                THUMBNAIL_WIDTH_PX,
                height,
            )
        } else {
            retriever.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?.let { Bitmap.createScaledBitmap(it, THUMBNAIL_WIDTH_PX, height, true) }
        }
    }

    fun release() {
        scope.launch {
            mutex.withLock {
                released = true
                runCatching { retriever.release() }
                cache.evictAll()
            }
        }
    }

    private fun MediaMetadataRetriever.metadata(key: Int): Int? =
        extractMetadata(key)?.toIntOrNull()

    private companion object {
        const val DEFAULT_ASPECT_RATIO = 16f / 9f
    }
}

@OptIn(UnstableApi::class)
@Composable
internal fun rememberSeekThumbnailProvider(player: Player?): SeekThumbnailProvider? {
    val context = LocalContext.current.applicationContext
    val mediaId = rememberMetadataState(player = player).mediaId
    val uri = remember(player, mediaId) {
        player?.currentMediaItem?.let { it.localConfiguration?.uri ?: it.requestMetadata.mediaUri }
    }
    var provider by remember { mutableStateOf<SeekThumbnailProvider?>(value = null) }
    DisposableEffect(uri) {
        val scheme = uri?.scheme
        val created = if (uri != null && (scheme == "content" || scheme == "file")) {
            SeekThumbnailProvider(context = context, uri = uri)
        } else {
            null
        }
        provider = created
        onDispose {
            created?.release()
            provider = null
        }
    }
    return provider
}

/** Small card shown above the seek bar while scrubbing: a preview frame (when available) and the time. */
@Composable
internal fun SeekPreview(
    provider: SeekThumbnailProvider?,
    positionMs: Long,
    durationMs: Long,
    trackWidthPx: Int,
    modifier: Modifier = Modifier,
) {
    val bucketMs = max(MIN_BUCKET_MS, durationMs / FRAMES_ACROSS_SEEKBAR)
    val bucketKey = positionMs / bucketMs
    var frame by remember(provider) { mutableStateOf<ImageBitmap?>(value = null) }
    LaunchedEffect(provider, bucketKey) {
        val current = provider ?: return@LaunchedEffect
        // Wait a moment so fast drags only decode the frame they stop on.
        delay(DEBOUNCE_MS)
        val target = (bucketKey * bucketMs + bucketMs / 2).coerceIn(0L, max(0L, durationMs))
        current.frameAt(positionMs = target, bucketKey = bucketKey)?.let {
            frame = it.asImageBitmap()
        }
    }

    val density = LocalDensity.current
    val gapPx = with(density) { 14.dp.roundToPx() }
    var cardWidthPx by remember { mutableIntStateOf(0) }
    var cardHeightPx by remember { mutableIntStateOf(0) }
    val fraction = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shape = RoundedCornerShape(16.dp)
    val glass = LocalGlassSettings.current

    Column(
        modifier = modifier
            .offset {
                val x = (fraction * trackWidthPx - cardWidthPx / 2f).roundToInt()
                    .coerceIn(0, max(0, trackWidthPx - cardWidthPx))
                IntOffset(x = x, y = -(cardHeightPx + gapPx))
            }
            .onSizeChanged {
                cardWidthPx = it.width
                cardHeightPx = it.height
            }
            .alpha(if (cardWidthPx == 0) 0f else 1f)
            .then(
                if (glass != null && glass.enabled) {
                    Modifier.glassSurface(settings = glass, shape = shape)
                } else {
                    Modifier.clip(shape).background(Color.Black.copy(alpha = 0.65f))
                },
            )
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val bitmap = frame
        if (provider != null) {
            val width = 144.dp
            val height = width / (provider.aspectRatio)
            Box(
                modifier = Modifier
                    .size(width = width, height = height)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.Black.copy(alpha = 0.4f)),
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(width = width, height = height),
                    )
                }
            }
        }
        Text(
            text = getStringForTime(positionMs),
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
            modifier = Modifier.padding(top = if (provider != null) 4.dp else 0.dp),
        )
    }
}
