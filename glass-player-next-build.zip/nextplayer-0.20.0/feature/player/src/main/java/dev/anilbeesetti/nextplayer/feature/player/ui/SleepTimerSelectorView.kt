package dev.anilbeesetti.nextplayer.feature.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.feature.player.service.CustomCommands
import dev.anilbeesetti.nextplayer.feature.player.state.SleepTimerState
import kotlinx.coroutines.delay

private val SLEEP_TIMER_MINUTES = listOf(5, 10, 15, 30, 45, 60, 90)
private const val ONE_SECOND_MS = 1_000L

@Composable
fun BoxScope.SleepTimerSelectorView(
    show: Boolean,
    sleepTimerState: SleepTimerState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var remainingMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(show) {
        if (!show) return@LaunchedEffect
        sleepTimerState.refresh()
        while (true) {
            remainingMs = sleepTimerState.remainingMs()
            delay(ONE_SECOND_MS)
        }
    }
    val status = sleepTimerState.status

    OverlayView(
        modifier = modifier,
        show = show,
        title = stringResource(R.string.sleep_timer),
    ) {
        Column(
            modifier = Modifier
                .verticalScroll(state = rememberScrollState())
                .padding(bottom = 24.dp)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (status.isActive) {
                Text(
                    text = if (status.atEndOfVideo) {
                        stringResource(R.string.sleep_timer_active_end_of_video)
                    } else {
                        stringResource(
                            R.string.sleep_timer_active_minutes,
                            remainingMs.formatCountdown(),
                        )
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }
            RadioButtonRow(
                selected = !status.isActive,
                text = stringResource(R.string.sleep_timer_off),
                onClick = {
                    sleepTimerState.set(minutes = 0)
                    onDismiss()
                },
            )
            SLEEP_TIMER_MINUTES.forEach { minutes ->
                RadioButtonRow(
                    selected = false,
                    text = stringResource(R.string.sleep_timer_minutes, minutes),
                    onClick = {
                        sleepTimerState.set(minutes = minutes)
                        onDismiss()
                    },
                )
            }
            RadioButtonRow(
                selected = status.atEndOfVideo,
                text = stringResource(R.string.sleep_timer_end_of_video),
                onClick = {
                    sleepTimerState.set(minutes = CustomCommands.SLEEP_TIMER_END_OF_VIDEO)
                    onDismiss()
                },
            )
        }
    }
}

private fun Long.formatCountdown(): String {
    val totalSeconds = this / ONE_SECOND_MS
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
