package dev.anilbeesetti.nextplayer.feature.player.state

import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import dev.anilbeesetti.nextplayer.feature.player.model.SleepTimerStatus
import dev.anilbeesetti.nextplayer.feature.player.service.getSleepTimer
import dev.anilbeesetti.nextplayer.feature.player.service.setSleepTimer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun rememberSleepTimerState(player: Player?): SleepTimerState {
    val scope = rememberCoroutineScope()
    val state = remember(player, scope) {
        SleepTimerState(controller = player as? MediaController, scope = scope)
    }
    // The timer lives in the player service, so ask it what is running when the controls open.
    LaunchedEffect(state) { state.refresh() }
    return state
}

@OptIn(UnstableApi::class)
@Stable
class SleepTimerState(
    private val controller: MediaController?,
    private val scope: CoroutineScope,
) {
    var status: SleepTimerStatus by mutableStateOf(value = SleepTimerStatus())
        private set

    val isSupported: Boolean get() = controller != null

    suspend fun refresh() {
        val controller = controller ?: return
        status = runCatching { controller.getSleepTimer() }.getOrDefault(SleepTimerStatus())
    }

    /** [minutes] > 0 for a timed sleep, -1 for end of video, 0 to turn it off. */
    fun set(minutes: Int) {
        val controller = controller ?: return
        scope.launch {
            runCatching { controller.setSleepTimer(minutes = minutes) }
            refresh()
        }
    }

    fun remainingMs(): Long =
        (status.endsAtRealtimeMs - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
}
