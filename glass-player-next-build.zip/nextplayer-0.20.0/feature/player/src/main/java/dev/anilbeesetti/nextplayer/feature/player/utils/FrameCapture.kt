package dev.anilbeesetti.nextplayer.feature.player.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.Player
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.resume
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

private const val MICROS_PER_MILLI = 1_000L
private const val JPEG_QUALITY = 95
private const val ALBUM_NAME = "NextPlayer"

/**
 * Saves the frame that is on screen right now as a JPEG in Pictures/NextPlayer.
 * First it copies the picture straight from the video surface (fast, works for any video and
 * needs no extra decoder). If that is not possible it reads the frame from the file instead.
 * Returns true when the picture was saved.
 */
suspend fun saveCurrentFrame(context: Context, view: View?, player: Player?): Boolean {
    val bitmap = runCatching { copyFromSurface(view, player) }.getOrNull()
        ?: runCatching { retrieveFrame(context, player) }.getOrNull()
        ?: return false

    return withContext(Dispatchers.IO) {
        runCatching { saveBitmap(context, bitmap) }.getOrDefault(false)
    }
}

private fun View.findSurfaceView(): SurfaceView? {
    if (this is SurfaceView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findSurfaceView()?.let { return it }
        }
    }
    return null
}

private suspend fun copyFromSurface(view: View?, player: Player?): Bitmap? {
    val surfaceView = view?.rootView?.findSurfaceView() ?: return null
    if (!surfaceView.holder.surface.isValid) return null

    var width = surfaceView.width
    var height = surfaceView.height
    val videoSize = player?.videoSize
    if (videoSize != null && videoSize.width > 0 && videoSize.height > 0) {
        val ratio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
        width = (videoSize.width * ratio).roundToInt()
        height = videoSize.height
    }
    if (width <= 0 || height <= 0) return null

    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    return suspendCancellableCoroutine { continuation ->
        PixelCopy.request(
            surfaceView,
            bitmap,
            { result ->
                if (continuation.isActive) {
                    continuation.resume(if (result == PixelCopy.SUCCESS) bitmap else null)
                }
            },
            Handler(Looper.getMainLooper()),
        )
    }
}

private suspend fun retrieveFrame(context: Context, player: Player?): Bitmap? {
    // Media3 players must be read on the main thread, so do it before switching to IO.
    val uri = player?.currentMediaItem?.localConfiguration?.uri ?: return null
    val positionUs = player.currentPosition * MICROS_PER_MILLI

    return withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> retriever.setDataSource(uri.toString(), HashMap<String, String>())
                else -> retriever.setDataSource(context, uri)
            }
            listOf(
                MediaMetadataRetriever.OPTION_CLOSEST,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                MediaMetadataRetriever.OPTION_PREVIOUS_SYNC,
            ).firstNotNullOfOrNull { option ->
                runCatching { retriever.getFrameAtTime(positionUs, option) }.getOrNull()
            }
        } catch (e: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}

private fun saveBitmap(context: Context, bitmap: Bitmap): Boolean {
    val fileName = "NextPlayer_${System.currentTimeMillis()}.jpg"
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$ALBUM_NAME")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        val written = resolver.openOutputStream(target)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        } ?: false
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(target, values, null, null)
        written
    } else {
        // Android 8 and 9: save in the app's own picture folder (no storage permission needed).
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return false
        FileOutputStream(File(folder, fileName)).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        }
    }
}
