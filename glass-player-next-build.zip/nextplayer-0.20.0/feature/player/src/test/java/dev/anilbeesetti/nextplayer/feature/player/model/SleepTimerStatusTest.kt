package dev.anilbeesetti.nextplayer.feature.player.model

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SleepTimerStatusTest {

    @Test
    fun `default status is not active`() {
        assertFalse(SleepTimerStatus().isActive)
    }

    @Test
    fun `timed timer is active`() {
        assertTrue(SleepTimerStatus(endsAtRealtimeMs = 1_000L).isActive)
    }

    @Test
    fun `end of video timer is active`() {
        assertTrue(SleepTimerStatus(atEndOfVideo = true).isActive)
    }
}
