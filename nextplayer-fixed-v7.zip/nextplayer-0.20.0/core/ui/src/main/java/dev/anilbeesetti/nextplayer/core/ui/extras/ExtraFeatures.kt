package dev.anilbeesetti.nextplayer.core.ui.extras

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext

const val EXTRA_FEATURES_PREFS = "extra_features"
const val KEY_FAST_SKIP = "fast_skip"
/** Width of the little picture shown after a screen capture, as a share of the screen width (Samsung Video: about 17%). */
const val DEFAULT_CAPTURE_PREVIEW_WIDTH = 0.17f
private const val KEY_SEEK_PREVIEW = "seek_preview"
private const val KEY_MODERN_ICONS = "modern_player_icons"
private const val KEY_MINIMAL_LAYOUT = "minimal_player_layout"
private const val KEY_SEEK_PREVIEW_SCALE = "seek_preview_scale"
private const val KEY_CAPTURE_PREVIEW_WIDTH = "capture_preview_width"
private const val KEY_CAPTURE_BUTTONS = "capture_buttons"
private const val KEY_SLEEP_TIMER = "sleep_timer_button"
private const val KEY_SKIP_INTRO = "skip_intro"
private const val KEY_SKIP_INTRO_SECONDS = "skip_intro_seconds"
private const val KEY_NEXT_PILL = "next_episode_pill"
private const val KEY_ENHANCER = "enhancer"
private const val KEY_BRIGHTNESS = "enh_brightness"
private const val KEY_CONTRAST = "enh_contrast"
private const val KEY_SATURATION = "enh_saturation"
private const val KEY_PRESET = "performance_preset"
private const val KEY_WATCHED = "watched_marks"
private const val KEY_CAPTURE_DATE = "capture_video_date"
private const val KEY_CONTINUE = "continue_watching"
private const val KEY_AMBIENT = "ambient_glow_v2"
const val KEY_DEFAULT_DECODER = "default_decoder"
private const val KEY_SHOW_STATS = "show_stats"
private const val KEY_AMBIENT_STRENGTH = "ambient_strength"

/** On/off switches and values for the extra features added to the player. */
@Stable
class ExtraFeatures(private val prefs: SharedPreferences) {
    var seekPreview by mutableStateOf(prefs.getBoolean(KEY_SEEK_PREVIEW, true))
        private set
    /** "Modern" player icons: thin, flat and outlined. Off = the original "Legacy" icons. */
    var modernPlayerIcons by mutableStateOf(prefs.getBoolean(KEY_MODERN_ICONS, false))
        private set
    /** Player layout: false = "Modern" (the usual controls), true = "Minimal" (Samsung Video style). */
    var minimalLayout by mutableStateOf(prefs.getBoolean(KEY_MINIMAL_LAYOUT, false))
        private set
    /** Size of the picture shown above the seek bar while dragging: 1.0 = normal, smaller or bigger as chosen. */
    var seekPreviewScale by mutableFloatStateOf(prefs.getFloat(KEY_SEEK_PREVIEW_SCALE, 1f))
        private set
    /** Width of the picture that pops up after a screen capture, as a share of the screen width. */
    var capturePreviewWidth by mutableFloatStateOf(prefs.getFloat(KEY_CAPTURE_PREVIEW_WIDTH, DEFAULT_CAPTURE_PREVIEW_WIDTH))
        private set
    var captureButtons by mutableStateOf(prefs.getBoolean(KEY_CAPTURE_BUTTONS, true))
        private set
    var sleepTimerButton by mutableStateOf(prefs.getBoolean(KEY_SLEEP_TIMER, true))
        private set
    var fastSkip by mutableStateOf(prefs.getBoolean(KEY_FAST_SKIP, true))
        private set
    var skipIntro by mutableStateOf(prefs.getBoolean(KEY_SKIP_INTRO, false))
        private set
    var skipIntroSeconds by mutableIntStateOf(prefs.getInt(KEY_SKIP_INTRO_SECONDS, 85))
        private set
    var nextEpisodePill by mutableStateOf(prefs.getBoolean(KEY_NEXT_PILL, true))
        private set
    var enhancerEnabled by mutableStateOf(prefs.getBoolean(KEY_ENHANCER, false))
        private set
    var brightness by mutableFloatStateOf(prefs.getFloat(KEY_BRIGHTNESS, 0f))
        private set
    var contrast by mutableFloatStateOf(prefs.getFloat(KEY_CONTRAST, 1f))
        private set
    var saturation by mutableFloatStateOf(prefs.getFloat(KEY_SATURATION, 1f))
        private set
    var performancePreset by mutableIntStateOf(prefs.getInt(KEY_PRESET, -1))
        private set
    /** Give screen captures the date of the video, so the Gallery shows them next to it. */
    var captureWithVideoDate by mutableStateOf(prefs.getBoolean(KEY_CAPTURE_DATE, true))
        private set
    var watchedMarks by mutableStateOf(prefs.getBoolean(KEY_WATCHED, true))
        private set
    var continueWatching by mutableStateOf(prefs.getBoolean(KEY_CONTINUE, true))
        private set
    var ambientGlow by mutableStateOf(prefs.getBoolean(KEY_AMBIENT, false))
        private set
    /** 0 = HW (ask before software), 1 = HW+ (hardware first, automatic fallback to software). */
    var defaultDecoder by mutableIntStateOf(prefs.getInt(KEY_DEFAULT_DECODER, 0))
        private set
    var showStats by mutableStateOf(prefs.getBoolean(KEY_SHOW_STATS, false))
        private set
    var ambientStrength by mutableFloatStateOf(prefs.getFloat(KEY_AMBIENT_STRENGTH, 0.6f))
        private set

    fun updateSeekPreview(value: Boolean) {
        seekPreview = value
        prefs.edit().putBoolean(KEY_SEEK_PREVIEW, value).apply()
    }

    fun updateModernPlayerIcons(value: Boolean) {
        modernPlayerIcons = value
        prefs.edit().putBoolean(KEY_MODERN_ICONS, value).apply()
    }

    fun updateMinimalLayout(value: Boolean) {
        minimalLayout = value
        prefs.edit().putBoolean(KEY_MINIMAL_LAYOUT, value).apply()
    }

    fun updateSeekPreviewScale(value: Float) {
        seekPreviewScale = value
        prefs.edit().putFloat(KEY_SEEK_PREVIEW_SCALE, value).apply()
    }

    fun updateCapturePreviewWidth(value: Float) {
        capturePreviewWidth = value
        prefs.edit().putFloat(KEY_CAPTURE_PREVIEW_WIDTH, value).apply()
    }

    fun updateCaptureButtons(value: Boolean) {
        captureButtons = value
        prefs.edit().putBoolean(KEY_CAPTURE_BUTTONS, value).apply()
    }

    fun updateSleepTimerButton(value: Boolean) {
        sleepTimerButton = value
        prefs.edit().putBoolean(KEY_SLEEP_TIMER, value).apply()
    }

    fun updateFastSkip(value: Boolean) {
        fastSkip = value
        prefs.edit().putBoolean(KEY_FAST_SKIP, value).apply()
    }

    fun updateSkipIntro(value: Boolean) {
        skipIntro = value
        prefs.edit().putBoolean(KEY_SKIP_INTRO, value).apply()
    }

    fun updateSkipIntroSeconds(value: Int) {
        skipIntroSeconds = value
        prefs.edit().putInt(KEY_SKIP_INTRO_SECONDS, value).apply()
    }

    fun updateNextEpisodePill(value: Boolean) {
        nextEpisodePill = value
        prefs.edit().putBoolean(KEY_NEXT_PILL, value).apply()
    }

    fun updateEnhancerEnabled(value: Boolean) {
        enhancerEnabled = value
        prefs.edit().putBoolean(KEY_ENHANCER, value).apply()
    }

    fun updateEnhancer(brightness: Float, contrast: Float, saturation: Float) {
        this.brightness = brightness
        this.contrast = contrast
        this.saturation = saturation
        prefs.edit()
            .putFloat(KEY_BRIGHTNESS, brightness)
            .putFloat(KEY_CONTRAST, contrast)
            .putFloat(KEY_SATURATION, saturation)
            .apply()
    }

    fun updateCaptureWithVideoDate(value: Boolean) {
        captureWithVideoDate = value
        prefs.edit().putBoolean(KEY_CAPTURE_DATE, value).apply()
    }

    fun updateWatchedMarks(value: Boolean) {
        watchedMarks = value
        prefs.edit().putBoolean(KEY_WATCHED, value).apply()
    }

    fun updateContinueWatching(value: Boolean) {
        continueWatching = value
        prefs.edit().putBoolean(KEY_CONTINUE, value).apply()
    }

    fun updateDefaultDecoder(value: Int) {
        defaultDecoder = value
        prefs.edit().putInt(KEY_DEFAULT_DECODER, value).apply()
    }

    fun updateShowStats(value: Boolean) {
        showStats = value
        prefs.edit().putBoolean(KEY_SHOW_STATS, value).apply()
    }

    fun updateAmbientGlow(value: Boolean) {
        ambientGlow = value
        prefs.edit().putBoolean(KEY_AMBIENT, value).apply()
    }

    fun updateAmbientStrength(value: Float) {
        ambientStrength = value
        prefs.edit().putFloat(KEY_AMBIENT_STRENGTH, value).apply()
    }

    fun updatePerformancePreset(value: Int) {
        performancePreset = value
        prefs.edit().putInt(KEY_PRESET, value).apply()
    }
}

/** One shared copy, so the player, its buttons and the settings always agree. */
object ExtraFeaturesStore {
    @Volatile
    private var instance: ExtraFeatures? = null

    fun get(context: Context): ExtraFeatures {
        return instance ?: synchronized(this) {
            instance ?: ExtraFeatures(
                context.applicationContext.getSharedPreferences(EXTRA_FEATURES_PREFS, Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}

@Composable
fun rememberExtraFeatures(): ExtraFeatures {
    val context = LocalContext.current
    return remember { ExtraFeaturesStore.get(context) }
}

/** Provided by the player screen so the controls can check which extras are switched on. */
val LocalExtraFeatures = staticCompositionLocalOf<ExtraFeatures?> { null }
