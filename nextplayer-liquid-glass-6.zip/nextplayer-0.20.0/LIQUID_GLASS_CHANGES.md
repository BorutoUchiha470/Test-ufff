# Liquid glass added (AndroidLiquidGlass / Backdrop 2.0.1)

Real glass = the video (or app background) behind a control is blurred, bent at the edges like a lens, and lit with a bright rim. Needs Android 12+; older phones keep the painted glass look.

Player
- Every glass control (buttons, seekbar track + thumb, capture buttons, seek/zoom/info pills, D-pad indicator) now looks through the video. Press a button and it swells like a drop of liquid. The seekbar thumb grows into a glass bubble while held.
- Menus (audio, subtitles, speed, playlist, chapters, decoder, scale) are big glass sheets over the video.
- Video is shown on a TextureView while real glass is on (a SurfaceView cannot be bent). Frame capture was updated to read from it.

App
- Bottom bar and the round + button are glass over the colorful background and the screen scrolling under them.
- All switches are iOS style liquid switches; preference sliders are liquid sliders.
- Settings > Appearance > Glass style: new "Real liquid glass" switch and a live preview with shapes behind the bubbles.

Files: core/ui/glass/LiquidGlass.kt (engine), core/ui/components/LiquidSwitch.kt, LiquidSlider.kt, plus edits in the player, theme, MainActivity and navigation.

## Round 6 (HW+ fix, more optimisation)
- HW+ rebuilt: it now starts on the hardware decoder exactly like HW, and only changes the failure policy (silent fallback to software instead of asking). The old version used the "auto" mode, which did not start playback when chosen.
- Skip pills now check once a second and only redraw when a pill appears/disappears.
- Player asks for sustained performance mode where the phone supports it (less throttling in long movies).
- App: glass-card brushes are cached, list items have content types (better recycling), the press squish can be switched off (Smooth preset turns it off).
