package dev.anilbeesetti.nextplayer.core.ui.extras

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalContext

const val EXTRA_FEATURES_PREFS = "extra_features"
const val KEY_FAST_SKIP = "fast_skip"
private const val KEY_SEEK_PREVIEW = "seek_preview"
private const val KEY_CAPTURE_BUTTONS = "capture_buttons"
private const val KEY_SLEEP_TIMER = "sleep_timer_button"
private const val KEY_SKIP_INTRO = "skip_intro"
private const val KEY_SKIP_INTRO_SECONDS = "skip_intro_seconds"
private const val KEY_NEXT_PILL = "next_episode_pill"
private const val KEY_ENHANCER = "enhancer"
private const val KEY_BRIGHTNESS = "enh_brightness"
private const val KEY_CONTRAST = "enh_contrast"
private const val KEY_SATURATION = "enh_saturation"
private const val KEY_PRESET = "performance_preset"
private const val KEY_WATCHED = "watched_marks"
private const val KEY_CONTINUE = "continue_watching"
private const val KEY_AMBIENT = "ambient_glow_v2"
const val KEY_PREFER_HW = "prefer_hw"
private const val KEY_AMBIENT_STRENGTH = "ambient_strength"

/** On/off switches and values for the extra features added to the player. */
@Stable
class ExtraFeatures(private val prefs: SharedPreferences) {
    var seekPreview by mutableStateOf(prefs.getBoolean(KEY_SEEK_PREVIEW, true))
        private set
    var captureButtons by mutableStateOf(prefs.getBoolean(KEY_CAPTURE_BUTTONS, true))
        private set
    var sleepTimerButton by mutableStateOf(prefs.getBoolean(KEY_SLEEP_TIMER, true))
        private set
    var fastSkip by mutableStateOf(prefs.getBoolean(KEY_FAST_SKIP, true))
        private set
    var skipIntro by mutableStateOf(prefs.getBoolean(KEY_SKIP_INTRO, true))
        private set
    var skipIntroSeconds by mutableIntStateOf(prefs.getInt(KEY_SKIP_INTRO_SECONDS, 85))
        private set
    var nextEpisodePill by mutableStateOf(prefs.getBoolean(KEY_NEXT_PILL, true))
        private set
    var enhancerEnabled by mutableStateOf(prefs.getBoolean(KEY_ENHANCER, false))
        private set
    var brightness by mutableFloatStateOf(prefs.getFloat(KEY_BRIGHTNESS, 0f))
        private set
    var contrast by mutableFloatStateOf(prefs.getFloat(KEY_CONTRAST, 1f))
        private set
    var saturation by mutableFloatStateOf(prefs.getFloat(KEY_SATURATION, 1f))
        private set
    var performancePreset by mutableIntStateOf(prefs.getInt(KEY_PRESET, -1))
        private set
    var watchedMarks by mutableStateOf(prefs.getBoolean(KEY_WATCHED, true))
        private set
    var continueWatching by mutableStateOf(prefs.getBoolean(KEY_CONTINUE, true))
        private set
    var ambientGlow by mutableStateOf(prefs.getBoolean(KEY_AMBIENT, false))
        private set
    var preferHardware by mutableStateOf(prefs.getBoolean(KEY_PREFER_HW, true))
        private set
    var ambientStrength by mutableFloatStateOf(prefs.getFloat(KEY_AMBIENT_STRENGTH, 0.6f))
        private set

    fun updateSeekPreview(value: Boolean) {
        seekPreview = value
        prefs.edit().putBoolean(KEY_SEEK_PREVIEW, value).apply()
    }

    fun updateCaptureButtons(value: Boolean) {
        captureButtons = value
        prefs.edit().putBoolean(KEY_CAPTURE_BUTTONS, value).apply()
    }

    fun updateSleepTimerButton(value: Boolean) {
        sleepTimerButton = value
        prefs.edit().putBoolean(KEY_SLEEP_TIMER, value).apply()
    }

    fun updateFastSkip(value: Boolean) {
        fastSkip = value
        prefs.edit().putBoolean(KEY_FAST_SKIP, value).apply()
    }

    fun updateSkipIntro(value: Boolean) {
        skipIntro = value
        prefs.edit().putBoolean(KEY_SKIP_INTRO, value).apply()
    }

    fun updateSkipIntroSeconds(value: Int) {
        skipIntroSeconds = value
        prefs.edit().putInt(KEY_SKIP_INTRO_SECONDS, value).apply()
    }

    fun updateNextEpisodePill(value: Boolean) {
        nextEpisodePill = value
        prefs.edit().putBoolean(KEY_NEXT_PILL, value).apply()
    }

    fun updateEnhancerEnabled(value: Boolean) {
        enhancerEnabled = value
        prefs.edit().putBoolean(KEY_ENHANCER, value).apply()
    }

    fun updateEnhancer(brightness: Float, contrast: Float, saturation: Float) {
        this.brightness = brightness
        this.contrast = contrast
        this.saturation = saturation
        prefs.edit()
            .putFloat(KEY_BRIGHTNESS, brightness)
            .putFloat(KEY_CONTRAST, contrast)
            .putFloat(KEY_SATURATION, saturation)
            .apply()
    }

    fun updateWatchedMarks(value: Boolean) {
        watchedMarks = value
        prefs.edit().putBoolean(KEY_WATCHED, value).apply()
    }

    fun updateContinueWatching(value: Boolean) {
        continueWatching = value
        prefs.edit().putBoolean(KEY_CONTINUE, value).apply()
    }

    fun updatePreferHardware(value: Boolean) {
        preferHardware = value
        prefs.edit().putBoolean(KEY_PREFER_HW, value).apply()
    }

    fun updateAmbientGlow(value: Boolean) {
        ambientGlow = value
        prefs.edit().putBoolean(KEY_AMBIENT, value).apply()
    }

    fun updateAmbientStrength(value: Float) {
        ambientStrength = value
        prefs.edit().putFloat(KEY_AMBIENT_STRENGTH, value).apply()
    }

    fun updatePerformancePreset(value: Int) {
        performancePreset = value
        prefs.edit().putInt(KEY_PRESET, value).apply()
    }
}

/** One shared copy, so the player, its buttons and the settings always agree. */
object ExtraFeaturesStore {
    @Volatile
    private var instance: ExtraFeatures? = null

    fun get(context: Context): ExtraFeatures {
        return instance ?: synchronized(this) {
            instance ?: ExtraFeatures(
                context.applicationContext.getSharedPreferences(EXTRA_FEATURES_PREFS, Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}

@Composable
fun rememberExtraFeatures(): ExtraFeatures {
    val context = LocalContext.current
    return remember { ExtraFeaturesStore.get(context) }
}

/** Provided by the player screen so the controls can check which extras are switched on. */
val LocalExtraFeatures = staticCompositionLocalOf<ExtraFeatures?> { null }
