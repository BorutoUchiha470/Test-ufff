package dev.anilbeesetti.nextplayer.core.ui.glass

import dev.anilbeesetti.nextplayer.core.ui.extras.ExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.theme.AppLookState

/** One-tap looks: from lightest and smoothest to the fanciest. */
enum class PerformancePreset { SMOOTH, BALANCED, MAX }

fun applyPerformancePreset(
    preset: PerformancePreset,
    glass: GlassSettings,
    look: AppLookState,
    extras: ExtraFeatures,
) {
    glass.updateEnabled(true)
    when (preset) {
        PerformancePreset.SMOOTH -> {
            glass.updateRealGlass(false)
            glass.updateChromatic(false)
            glass.updateGlow(false)
            glass.updateShadow(false)
            glass.updateDepth(false)
            glass.updateVibrancy(false)
            look.updateGlassEnabled(false)
            look.updateFastTransitions(true)
            look.updateLiquidTransitions(false)
            extras.updateSeekPreview(false)
            extras.updateAmbientGlow(false)
        }

        PerformancePreset.BALANCED -> {
            glass.updateRealGlass(true)
            glass.updateChromatic(false)
            glass.updateGlow(false)
            glass.updateShadow(false)
            glass.updateDepth(true)
            glass.updateVibrancy(false)
            look.updateGlassEnabled(true)
            look.updateFastTransitions(true)
            look.updateLiquidTransitions(false)
            extras.updateSeekPreview(true)
            extras.updateAmbientGlow(false)
        }

        PerformancePreset.MAX -> {
            glass.updateRealGlass(true)
            glass.updateChromatic(true)
            glass.updateGlow(false)
            glass.updateShadow(true)
            glass.updateDepth(true)
            glass.updateVibrancy(true)
            look.updateGlassEnabled(true)
            look.updateFastTransitions(false)
            look.updateLiquidTransitions(true)
            extras.updateSeekPreview(true)
            extras.updateAmbientGlow(true)
        }
    }
    extras.updatePerformancePreset(preset.ordinal)
}
