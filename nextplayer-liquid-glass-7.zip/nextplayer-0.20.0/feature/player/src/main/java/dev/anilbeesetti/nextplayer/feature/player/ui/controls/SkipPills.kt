package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.extras.LocalExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.glass.LocalGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.feature.player.buttons.PlayerButton
import kotlinx.coroutines.delay

private const val INTRO_PILL_WINDOW_MS = 20_000L
private const val NEXT_PILL_WINDOW_MS = 20_000L

/**
 * Two small glass buttons that pop up when they are useful: "Skip intro" in the first seconds of a
 * video and "Next episode" in the last seconds.
 */
@Composable
fun SkipPills(player: Player?, modifier: Modifier = Modifier) {
    val extras = LocalExtraFeatures.current
    var showSkip by remember { mutableStateOf(false) }
    var showNext by remember { mutableStateOf(false) }

    // Checked once a second, and the screen only redraws when a button appears or disappears.
    LaunchedEffect(player) {
        while (true) {
            val positionMs = player?.currentPosition ?: 0L
            val durationMs = player?.duration?.takeIf { it > 0L } ?: 0L
            val skipMs = (extras?.skipIntroSeconds ?: 85) * 1_000L
            val skip = extras?.skipIntro != false &&
                positionMs in 1_000L..INTRO_PILL_WINDOW_MS &&
                positionMs < skipMs
            val next = extras?.nextEpisodePill != false &&
                player?.hasNextMediaItem() == true &&
                durationMs > 0L &&
                durationMs - positionMs in 500L..NEXT_PILL_WINDOW_MS
            if (showSkip != skip) showSkip = skip
            if (showNext != next) showNext = next
            delay(1_000)
        }
    }

    val skipSeconds = extras?.skipIntroSeconds ?: 85

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        AnimatedVisibility(visible = showSkip, enter = fadeIn(), exit = fadeOut()) {
            GlassPill(text = stringResource(R.string.skip_intro_pill, skipSeconds)) {
                player?.let {
                    val target = it.currentPosition + skipSeconds * 1_000L
                    val duration = it.duration
                    it.seekTo(if (duration > 0L) target.coerceAtMost(duration - 1_000L) else target)
                }
            }
        }
        AnimatedVisibility(visible = showNext, enter = fadeIn(), exit = fadeOut()) {
            GlassPill(text = stringResource(R.string.next_episode)) {
                player?.seekToNextMediaItem()
            }
        }
    }
}

@Composable
private fun GlassPill(text: String, onClick: () -> Unit) {
    val glass = LocalGlassSettings.current
    val shape = RoundedCornerShape(50)
    Text(
        text = text,
        color = Color.White,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier
            .then(
                if (glass != null && glass.enabled) {
                    Modifier.glassSurface(settings = glass, shape = shape)
                } else {
                    Modifier
                        .clip(shape)
                        .background(Color.Black.copy(alpha = 0.5f))
                },
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
    )
}

/** Bottom-row button: jumps ahead by the "skip intro" length (85 seconds by default). */
@Composable
fun SkipIntroButton(player: Player?, modifier: Modifier = Modifier) {
    val seconds = LocalExtraFeatures.current?.skipIntroSeconds ?: 85
    PlayerButton(
        onClick = {
            player?.let { it.seekTo(it.currentPosition + seconds * 1_000L) }
        },
        modifier = modifier,
    ) {
        Text(
            text = "+${seconds}s",
            style = MaterialTheme.typography.labelLarge,
            color = LocalContentColor.current,
        )
    }
}

/** Bottom-row button: turns the video enhancer (brightness, contrast, colour) on or off. */
@Composable
fun EnhancerButton(modifier: Modifier = Modifier) {
    val extras = LocalExtraFeatures.current ?: return
    PlayerButton(
        onClick = { extras.updateEnhancerEnabled(!extras.enhancerEnabled) },
        modifier = modifier,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_enhance),
            contentDescription = stringResource(R.string.extra_enhancer),
            tint = if (extras.enhancerEnabled) {
                MaterialTheme.colorScheme.primary
            } else {
                LocalContentColor.current
            },
        )
    }
}
