# Liquid glass added (AndroidLiquidGlass / Backdrop 2.0.1)

Real glass = the video (or app background) behind a control is blurred, bent at the edges like a lens, and lit with a bright rim. Needs Android 12+; older phones keep the painted glass look.

Player
- Every glass control (buttons, seekbar track + thumb, capture buttons, seek/zoom/info pills, D-pad indicator) now looks through the video. Press a button and it swells like a drop of liquid. The seekbar thumb grows into a glass bubble while held.
- Menus (audio, subtitles, speed, playlist, chapters, decoder, scale) are big glass sheets over the video.
- Video is shown on a TextureView while real glass is on (a SurfaceView cannot be bent). Frame capture was updated to read from it.

App
- Bottom bar and the round + button are glass over the colorful background and the screen scrolling under them.
- All switches are iOS style liquid switches; preference sliders are liquid sliders.
- Settings > Appearance > Glass style: new "Real liquid glass" switch and a live preview with shapes behind the bubbles.

Files: core/ui/glass/LiquidGlass.kt (engine), core/ui/components/LiquidSwitch.kt, LiquidSlider.kt, plus edits in the player, theme, MainActivity and navigation.

## Round 7 (clean one-colour player controls)
- New switch Appearance > Glass style > "Clean player controls (one color)" (on by default): while glass over video is off, buttons and seek bar use one simple colour (the glass colour) instead of the painted glass with coloured fringes. Cheaper to draw as well.
- Continue-watching history is only collected while the video list is on screen (nothing runs in the background during playback).
