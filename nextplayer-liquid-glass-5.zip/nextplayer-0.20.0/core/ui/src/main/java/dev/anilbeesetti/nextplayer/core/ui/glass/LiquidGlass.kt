package dev.anilbeesetti.nextplayer.core.ui.glass

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.BackdropEffectScope
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.isRenderEffectSupported
import com.kyant.backdrop.shadow.Shadow

/**
 * The picture that liquid glass looks through (the video in the player, the colorful background
 * in the app). When it is null, glass is painted instead of being real.
 */
val LocalGlassBackdrop = staticCompositionLocalOf<Backdrop?> { null }

/** True on Android 12+ where blur and light bending are possible. */
fun isRealGlassSupported(): Boolean = isRenderEffectSupported()

/**
 * Glass surface for a control. With a backdrop available this is real liquid glass: the video or
 * screen behind the control is blurred, bent at the edges like a glass lens and lit with a bright
 * rim. Otherwise it falls back to the painted look.
 *
 * [layerBlock] lets the control grow, stretch or move (for example when pressed) while the glass
 * keeps looking through to the right spot.
 */
@Composable
fun Modifier.glassSurface(
    settings: GlassSettings,
    shape: Shape = settings.shape,
    layerBlock: (GraphicsLayerScope.() -> Unit)? = null,
): Modifier {
    val backdrop = LocalGlassBackdrop.current
    val real = backdrop != null &&
        settings.realGlass &&
        settings.glassType != GlassType.SOLID &&
        shape is CornerBasedShape &&
        isRealGlassSupported()
    return if (real && backdrop != null) {
        liquidGlassSurface(backdrop, settings, shape, layerBlock)
    } else {
        val base = if (layerBlock != null) this.graphicsLayer(layerBlock) else this
        base.paintedGlassSurface(settings, shape)
    }
}

private fun BackdropEffectScope.safeLens(maxHeight: Dp, depth: Boolean, chromatic: Boolean) {
    // Small controls (thumbs, dots) need a smaller bend or the picture folds over itself.
    val height = minOf(maxHeight.toPx(), size.minDimension * 0.45f)
    if (height > 1f) {
        lens(
            refractionHeight = height,
            refractionAmount = height * 2f,
            depthEffect = depth,
            chromaticAberration = chromatic,
        )
    }
}

internal fun Modifier.liquidGlassSurface(
    backdrop: Backdrop,
    settings: GlassSettings,
    shape: Shape,
    layerBlock: (GraphicsLayerScope.() -> Unit)?,
): Modifier = drawBackdrop(
    backdrop = backdrop,
    shape = { shape },
    effects = {
        val type = settings.glassType
        if (settings.vibrancy || type == GlassType.LIQUID) vibrancy()
        blur(
            when (type) {
                GlassType.FROSTED -> 18.dp.toPx()
                GlassType.CLEAR -> 1.dp.toPx()
                else -> 3.dp.toPx()
            },
        )
        if (type != GlassType.FROSTED) {
            safeLens(maxHeight = 14.dp, depth = settings.depth, chromatic = settings.chromatic)
        }
    },
    highlight = {
        val scale = when (settings.glassType) {
            GlassType.FROSTED -> 0.5f
            GlassType.CLEAR -> 1.2f
            else -> 1f
        }
        val alpha = (settings.edgeShine * scale).coerceIn(0f, 1f)
        if (alpha > 0f) Highlight.Default.copy(alpha = alpha) else null
    },
    shadow = {
        when {
            settings.glow -> Shadow(
                radius = 18.dp,
                offset = DpOffset.Zero,
                color = Color(settings.tint).copy(alpha = 0.55f),
            )

            settings.shadow -> Shadow.Default
            else -> null
        }
    },
    layerBlock = layerBlock,
    onDrawSurface = {
        val type = settings.glassType
        var tint = Color(settings.tint)
        if (type == GlassType.FROSTED) tint = lerp(tint, Color.White, 0.35f)
        val alpha = when (type) {
            GlassType.FROSTED -> settings.opacity * 0.9f + 0.1f
            GlassType.CLEAR -> settings.opacity * 0.2f
            else -> settings.opacity * 0.5f
        }
        drawRect(color = tint.copy(alpha = alpha.coerceIn(0f, 1f)))
        if (settings.depth) {
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.14f),
                        Color.Transparent,
                        Color.Black.copy(alpha = 0.12f),
                    ),
                ),
            )
        }
    },
)

/**
 * A large glass sheet (menus, bars, panels). Looks through the backdrop when there is one and
 * falls back to a plain [fallbackColor] background when there is not.
 *
 * [tint] is drawn over the blurred picture so text on top stays easy to read.
 */
@Composable
fun Modifier.glassPanel(
    shape: CornerBasedShape,
    tint: Color,
    fallbackColor: Color,
    blurRadius: Dp = 20.dp,
    lensHeight: Dp = 12.dp,
): Modifier {
    val backdrop = LocalGlassBackdrop.current
    val settings = LocalGlassSettings.current
    val real = backdrop != null &&
        isRealGlassSupported() &&
        (settings == null || (settings.enabled && settings.realGlass))
    return if (real && backdrop != null) {
        drawBackdrop(
            backdrop = backdrop,
            shape = { shape },
            effects = {
                vibrancy()
                blur(blurRadius.toPx())
                safeLens(maxHeight = lensHeight, depth = false, chromatic = false)
            },
            onDrawSurface = { drawRect(color = tint) },
        )
    } else {
        this
            .clip(shape)
            .background(fallbackColor)
    }
}
