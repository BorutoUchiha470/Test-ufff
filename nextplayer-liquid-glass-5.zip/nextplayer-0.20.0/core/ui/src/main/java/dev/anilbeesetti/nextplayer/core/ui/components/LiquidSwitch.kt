package dev.anilbeesetti.nextplayer.core.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.Shadow

private val TrackWidth = 56.dp
private val TrackHeight = 32.dp
private val ThumbWidth = 36.dp
private val ThumbHeight = 28.dp
private val ThumbInset = 2.dp

/**
 * iOS style switch. The thumb is a white pill that turns into a clear glass bubble while it is
 * held, bending the colored track behind it.
 */
@Composable
fun LiquidSwitch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val fraction by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 380f),
        label = "liquidSwitchPosition",
    )
    val press by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "liquidSwitchPress",
    )
    val trackBackdrop = rememberLayerBackdrop()
    val accent = MaterialTheme.colorScheme.primary
    val offTrack = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)

    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.38f)
            .size(width = TrackWidth, height = TrackHeight)
            .then(
                if (onCheckedChange != null) {
                    Modifier.toggleable(
                        value = checked,
                        enabled = enabled,
                        role = Role.Switch,
                        interactionSource = interactionSource,
                        indication = null,
                        onValueChange = onCheckedChange,
                    )
                } else {
                    Modifier
                },
            ),
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .layerBackdrop(trackBackdrop)
                .clip(CircleShape)
                .drawBehind { drawRect(lerp(offTrack, accent, fraction)) },
        )
        Box(
            modifier = Modifier
                .graphicsLayer {
                    val start = ThumbInset.toPx()
                    val end = (TrackWidth - ThumbWidth - ThumbInset).toPx()
                    translationX = lerp(start, end, fraction)
                }
                .drawBackdrop(
                    backdrop = trackBackdrop,
                    shape = { CircleShape },
                    effects = {
                        blur(6.dp.toPx() * (1f - press))
                        lens(
                            refractionHeight = 5.dp.toPx() * press,
                            refractionAmount = 10.dp.toPx() * press,
                            chromaticAberration = true,
                        )
                    },
                    highlight = { Highlight.Ambient.copy(alpha = press.coerceIn(0f, 1f)) },
                    shadow = { Shadow(radius = 4.dp, color = Color.Black.copy(alpha = 0.15f)) },
                    layerBlock = {
                        val scale = lerp(1f, 1.2f, press)
                        scaleX = scale
                        scaleY = scale
                    },
                    onDrawSurface = {
                        drawRect(Color.White.copy(alpha = 1f - press * 0.85f))
                    },
                )
                .size(width = ThumbWidth, height = ThumbHeight),
        )
    }
}
