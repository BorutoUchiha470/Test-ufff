package dev.anilbeesetti.nextplayer.settings.screens.appearance

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R

private const val ICON_ALIAS_PREFIX = "dev.anilbeesetti.nextplayer.Icon"

private class AppIconChoice(val label: String, val aliasSuffix: String, val colors: List<Color>)

private val appIcons = listOf(
    AppIconChoice("Rose Gold", "RoseGold", listOf(Color(0xFF3A1C71), Color(0xFFD76D77), Color(0xFFFFAF7B))),
    AppIconChoice("Ocean", "Ocean", listOf(Color(0xFF1E3C72), Color(0xFF2A5298), Color(0xFF00C6FF))),
    AppIconChoice("Emerald", "Emerald", listOf(Color(0xFF0B486B), Color(0xFF1FA89A), Color(0xFFA8E063))),
    AppIconChoice("Violet", "Violet", listOf(Color(0xFF41295A), Color(0xFF7F00FF), Color(0xFFE100FF))),
    AppIconChoice("Sunset", "Sunset", listOf(Color(0xFFDD2476), Color(0xFFFF512F), Color(0xFFF09819))),
    AppIconChoice("Midnight", "Midnight", listOf(Color(0xFF0F0C29), Color(0xFF302B63), Color(0xFF24243E))),
)

private fun componentFor(context: Context, icon: AppIconChoice) =
    ComponentName(context.packageName, ICON_ALIAS_PREFIX + icon.aliasSuffix)

/** Rose Gold is on unless the user changed it, so "default" counts as on only for that one. */
private fun isIconEnabled(context: Context, icon: AppIconChoice): Boolean {
    val state = context.packageManager.getComponentEnabledSetting(componentFor(context, icon))
    return if (icon.aliasSuffix == "RoseGold") {
        state != PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    } else {
        state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
    }
}

private fun selectIcon(context: Context, selected: AppIconChoice) {
    val manager = context.packageManager
    // Switch the new one on first, so there is always an icon on the home screen.
    manager.setComponentEnabledSetting(
        componentFor(context, selected),
        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
        PackageManager.DONT_KILL_APP,
    )
    appIcons.filter { it !== selected }.forEach {
        manager.setComponentEnabledSetting(
            componentFor(context, it),
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP,
        )
    }
}

/** Lets the user pick the app icon (the home screen may take a few seconds to update). */
@Composable
fun AppIconSettings(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var current by remember {
        mutableStateOf(appIcons.firstOrNull { isIconEnabled(context, it) } ?: appIcons.first())
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            appIcons.forEach { icon ->
                val selected = icon === current
                Column(
                    modifier = Modifier.clickable {
                        selectIcon(context, icon)
                        current = icon
                        Toast.makeText(
                            context,
                            context.getString(R.string.app_icon_changed),
                            Toast.LENGTH_LONG,
                        ).show()
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Brush.linearGradient(colors = icon.colors))
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) Color.White else Color.Gray,
                                shape = RoundedCornerShape(16.dp),
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Image(
                            painter = painterResource(R.drawable.ic_app_logo),
                            contentDescription = icon.label,
                            modifier = Modifier.size(60.dp),
                        )
                    }
                    Text(text = icon.label, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Text(
            text = stringResource(R.string.app_icon_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
