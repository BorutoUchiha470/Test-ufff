package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.glass.PerformancePreset
import dev.anilbeesetti.nextplayer.core.ui.glass.applyPerformancePreset
import dev.anilbeesetti.nextplayer.core.ui.glass.rememberGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook

/** One-tap choice between the lightest and the fanciest look. */
@Composable
fun PerformancePresetsSettings(modifier: Modifier = Modifier) {
    val glass = rememberGlassSettings()
    val look = rememberAppLook()
    val extras = rememberExtraFeatures()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PerformancePreset.entries.forEach { preset ->
                FilterChip(
                    selected = extras.performancePreset == preset.ordinal,
                    onClick = { applyPerformancePreset(preset, glass, look, extras) },
                    label = {
                        Text(
                            text = stringResource(
                                when (preset) {
                                    PerformancePreset.SMOOTH -> R.string.perf_smooth
                                    PerformancePreset.BALANCED -> R.string.perf_balanced
                                    PerformancePreset.MAX -> R.string.perf_max
                                },
                            ),
                        )
                    },
                )
            }
        }
        Text(
            text = stringResource(R.string.perf_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
