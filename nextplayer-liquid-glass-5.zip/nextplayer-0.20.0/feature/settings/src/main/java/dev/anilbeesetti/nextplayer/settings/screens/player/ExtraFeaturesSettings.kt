package dev.anilbeesetti.nextplayer.settings.screens.player

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.settings.screens.appearance.SliderRow
import dev.anilbeesetti.nextplayer.settings.screens.appearance.SwitchRow
import kotlin.math.roundToInt

/** On/off switches for the extra features added to the player. */
@Composable
fun ExtraFeaturesSettings(modifier: Modifier = Modifier) {
    val extras = rememberExtraFeatures()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SwitchRow(
            title = stringResource(R.string.extra_seek_preview),
            description = stringResource(R.string.extra_seek_preview_desc),
            checked = extras.seekPreview,
            onCheckedChange = { extras.updateSeekPreview(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_capture_buttons),
            description = stringResource(R.string.extra_capture_buttons_desc),
            checked = extras.captureButtons,
            onCheckedChange = { extras.updateCaptureButtons(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_sleep_timer),
            description = stringResource(R.string.extra_sleep_timer_desc),
            checked = extras.sleepTimerButton,
            onCheckedChange = { extras.updateSleepTimerButton(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_skip_intro),
            description = stringResource(R.string.extra_skip_intro_desc),
            checked = extras.skipIntro,
            onCheckedChange = { extras.updateSkipIntro(it) },
        )
        if (extras.skipIntro) {
            SliderRow(
                title = stringResource(R.string.extra_skip_seconds),
                valueText = "${extras.skipIntroSeconds}s",
                value = extras.skipIntroSeconds.toFloat(),
                valueRange = 10f..180f,
                onValueChange = { extras.updateSkipIntroSeconds(it.roundToInt()) },
            )
        }
        SwitchRow(
            title = stringResource(R.string.extra_next_pill),
            description = stringResource(R.string.extra_next_pill_desc),
            checked = extras.nextEpisodePill,
            onCheckedChange = { extras.updateNextEpisodePill(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_enhancer),
            description = stringResource(R.string.extra_enhancer_desc),
            checked = extras.enhancerEnabled,
            onCheckedChange = { extras.updateEnhancerEnabled(it) },
        )
        if (extras.enhancerEnabled) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = { extras.updateEnhancer(0f, 1f, 1f) }) {
                    Text(text = stringResource(R.string.enh_reset))
                }
                TextButton(onClick = { extras.updateEnhancer(0.03f, 1.12f, 1.35f) }) {
                    Text(text = stringResource(R.string.enh_vivid))
                }
                TextButton(onClick = { extras.updateEnhancer(-0.02f, 1.2f, 0.9f) }) {
                    Text(text = stringResource(R.string.enh_cinema))
                }
                TextButton(onClick = { extras.updateEnhancer(0.05f, 0.92f, 1.05f) }) {
                    Text(text = stringResource(R.string.enh_soft))
                }
            }
            SliderRow(
                title = stringResource(R.string.enh_brightness),
                valueText = "${(extras.brightness * 100).roundToInt()}",
                value = extras.brightness,
                valueRange = -0.3f..0.3f,
                onValueChange = { extras.updateEnhancer(it, extras.contrast, extras.saturation) },
            )
            SliderRow(
                title = stringResource(R.string.enh_contrast),
                valueText = "${(extras.contrast * 100).roundToInt()}%",
                value = extras.contrast,
                valueRange = 0.7f..1.5f,
                onValueChange = { extras.updateEnhancer(extras.brightness, it, extras.saturation) },
            )
            SliderRow(
                title = stringResource(R.string.enh_saturation),
                valueText = "${(extras.saturation * 100).roundToInt()}%",
                value = extras.saturation,
                valueRange = 0.4f..2f,
                onValueChange = { extras.updateEnhancer(extras.brightness, extras.contrast, it) },
            )
        }
        SwitchRow(
            title = stringResource(R.string.extra_watched_marks),
            description = stringResource(R.string.extra_watched_marks_desc),
            checked = extras.watchedMarks,
            onCheckedChange = { extras.updateWatchedMarks(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_continue),
            description = stringResource(R.string.extra_continue_desc),
            checked = extras.continueWatching,
            onCheckedChange = { extras.updateContinueWatching(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_ambient),
            description = stringResource(R.string.extra_ambient_desc),
            checked = extras.ambientGlow,
            onCheckedChange = { extras.updateAmbientGlow(it) },
        )
        if (extras.ambientGlow) {
            SliderRow(
                title = stringResource(R.string.extra_ambient_strength),
                valueText = "${(extras.ambientStrength * 100).roundToInt()}%",
                value = extras.ambientStrength,
                valueRange = 0.2f..1f,
                onValueChange = { extras.updateAmbientStrength(it) },
            )
        }
        Text(text = stringResource(R.string.extra_default_decoder))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = extras.defaultDecoder == 0,
                onClick = { extras.updateDefaultDecoder(0) },
                label = { Text(text = "HW") },
            )
            FilterChip(
                selected = extras.defaultDecoder == 1,
                onClick = { extras.updateDefaultDecoder(1) },
                label = { Text(text = "HW+") },
            )
        }
        Text(
            text = stringResource(R.string.extra_default_decoder_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        SwitchRow(
            title = stringResource(R.string.extra_stats),
            description = stringResource(R.string.extra_stats_desc),
            checked = extras.showStats,
            onCheckedChange = { extras.updateShowStats(it) },
        )
        SwitchRow(
            title = stringResource(R.string.extra_fast_skip),
            description = stringResource(R.string.extra_fast_skip_desc),
            checked = extras.fastSkip,
            onCheckedChange = { extras.updateFastSkip(it) },
        )
    }
}
