package dev.anilbeesetti.nextplayer.feature.player

import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.stringResource
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.state.ProgressStateWithTickInterval
import dev.anilbeesetti.nextplayer.core.model.ControlButtonsPosition
import dev.anilbeesetti.nextplayer.core.model.PlayerPreferences
import dev.anilbeesetti.nextplayer.core.ui.extras.LocalExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.glass.LocalGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.rememberGlassSettings
import dev.anilbeesetti.nextplayer.feature.player.extensions.nameRes
import dev.anilbeesetti.nextplayer.feature.player.state.ChaptersState
import dev.anilbeesetti.nextplayer.feature.player.state.ControlsVisibilityState
import dev.anilbeesetti.nextplayer.feature.player.state.SeekGestureState
import dev.anilbeesetti.nextplayer.feature.player.state.VideoZoomAndContentScaleState
import dev.anilbeesetti.nextplayer.feature.player.state.seekAmountFormatted
import dev.anilbeesetti.nextplayer.feature.player.state.seekToPositionFormated
import dev.anilbeesetti.nextplayer.feature.player.ui.InfoView
import dev.anilbeesetti.nextplayer.feature.player.ui.OverlayView
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.CaptureButtons
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.LocalSeekPreviewVisible
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.PlaybackStatsOverlay
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.SkipPills
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.ControlsBottomView
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.ControlsMiddleView
import dev.anilbeesetti.nextplayer.feature.player.ui.controls.ControlsTopView
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.DecoderMode

@OptIn(UnstableApi::class)
@Composable
fun PlayerControls(
    player: Player?,
    title: String,
    playerPreferences: PlayerPreferences,
    videoDecoderMode: DecoderMode?,
    controlsVisibilityState: ControlsVisibilityState,
    seekGestureState: SeekGestureState,
    videoZoomAndContentScaleState: VideoZoomAndContentScaleState,
    progressState: ProgressStateWithTickInterval,
    chaptersState: ChaptersState,
    isPipSupported: Boolean,
    onShowOverlay: (OverlayView) -> Unit,
    onBackClick: () -> Unit,
    onPlayInBackgroundClick: () -> Unit,
    onToggleTimeDisplay: () -> Unit,
    onPictureInPictureClick: () -> Unit,
    modifier: Modifier = Modifier,
    middleControlsModifier: Modifier = Modifier,
) {
    val glassSettings = rememberGlassSettings()
    val extraFeatures = rememberExtraFeatures()
    val seekPreviewVisible = remember { mutableStateOf(false) }
    CompositionLocalProvider(
        LocalGlassSettings provides glassSettings,
        LocalExtraFeatures provides extraFeatures,
        LocalSeekPreviewVisible provides seekPreviewVisible,
    ) {
        Box(
            modifier = modifier.fillMaxSize(),
            contentAlignment = Alignment.Center,
        ) {
            Column {
                AnimatedVisibility(
                    visible = controlsVisibilityState.controlsVisible,
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    ControlsTopView(
                        title = title,
                        videoDecoderMode = videoDecoderMode,
                        onDecoderClick = { onShowOverlay(OverlayView.DECODER_SELECTOR) },
                        onAudioClick = { onShowOverlay(OverlayView.AUDIO_SELECTOR) },
                        onSubtitleClick = { onShowOverlay(OverlayView.SUBTITLE_SELECTOR) },
                        onPlaylistClick = { onShowOverlay(OverlayView.PLAYLIST) },
                        onBackClick = onBackClick,
                    )
                }
                Spacer(modifier = Modifier.weight(weight = 1f))
                AnimatedVisibility(
                    visible =
                        controlsVisibilityState.controlsVisible &&
                            !controlsVisibilityState.controlsLocked,
                    enter = fadeIn(),
                    exit = fadeOut(),
                ) {
                    ControlsBottomView(
                        player = player,
                        progressState = progressState,
                        chaptersState = chaptersState,
                        onChaptersClick = { onShowOverlay(OverlayView.CHAPTERS) },
                        controlsAlignment = when (playerPreferences.controlButtonsPosition) {
                            ControlButtonsPosition.LEFT -> Alignment.Start
                            ControlButtonsPosition.RIGHT -> Alignment.End
                        },
                        videoContentScale = videoZoomAndContentScaleState.videoContentScale,
                        isPipSupported = isPipSupported,
                        showRemainingTime = playerPreferences.showRemainingTime,
                        onToggleTimeDisplay = onToggleTimeDisplay,
                        onSeek = seekGestureState::onSeek,
                        onSeekEnd = seekGestureState::onSeekEnd,
                        onPlaybackSpeedClick = { onShowOverlay(OverlayView.PLAYBACK_SPEED) },
                        onPlayInBackgroundClick = onPlayInBackgroundClick,
                        onLockControlsClick = {
                            controlsVisibilityState.showControls()
                            controlsVisibilityState.lockControls()
                        },
                        onVideoContentScaleClick = {
                            controlsVisibilityState.showControls()
                            videoZoomAndContentScaleState.switchToNextVideoContentScale()
                        },
                        onVideoContentScaleLongClick = {
                            onShowOverlay(OverlayView.VIDEO_CONTENT_SCALE)
                        },
                        onPictureInPictureClick = onPictureInPictureClick,
                    )
                }
            }
            AnimatedVisibility(
                visible =
                    controlsVisibilityState.controlsVisible &&
                        !controlsVisibilityState.controlsLocked &&
                        extraFeatures.captureButtons,
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                CaptureButtons(player = player)
            }
            if (extraFeatures.showStats) {
                PlaybackStatsOverlay(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 12.dp),
                )
            }
            SkipPills(
                player = player,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 24.dp, bottom = 120.dp),
            )
            when {
                seekGestureState.seekAmount != null && seekPreviewVisible.value -> Unit

                seekGestureState.seekAmount != null -> InfoView(
                    info =
                        "${seekGestureState.seekAmountFormatted}\n" +
                            "[${seekGestureState.seekToPositionFormated}]",
                )

                videoZoomAndContentScaleState.isZooming -> InfoView(
                    info = "${(videoZoomAndContentScaleState.zoom * 100).toInt()}%",
                )

                videoZoomAndContentScaleState.showContentScaleIndicator -> InfoView(
                    info = stringResource(videoZoomAndContentScaleState.videoContentScale.nameRes()),
                )

                controlsVisibilityState.controlsVisible -> ControlsMiddleView(
                    player = player,
                    modifier = middleControlsModifier,
                )
            }
        }
    }
}
