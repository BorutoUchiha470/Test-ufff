package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.feature.player.utils.PlaybackStats

/** A small panel: which decoder is used (HW or SW), the video format and dropped frames. */
@Composable
fun PlaybackStatsOverlay(modifier: Modifier = Modifier) {
    val kind = if (PlaybackStats.isSoftware) "SW" else "HW"
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Text(
            text = "$kind  ${PlaybackStats.decoderName}",
            color = if (PlaybackStats.isSoftware) Color(0xFFFFB74D) else Color(0xFF81C784),
            style = MaterialTheme.typography.labelMedium,
        )
        Text(
            text = PlaybackStats.format,
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
        )
        Text(
            text = "Dropped frames: ${PlaybackStats.droppedFrames}",
            color = Color.White,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
