package dev.anilbeesetti.nextplayer.feature.player.utils

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import dev.anilbeesetti.nextplayer.core.ui.extras.ExtraFeatures

/** Sets (or clears) the colour correction on the video picture. Works on a TextureView. */
fun applyVideoEnhancement(rootView: View, extras: ExtraFeatures?) {
    val paint = extras?.let {
        Paint().apply {
            colorFilter = ColorMatrixColorFilter(
                enhancerMatrix(
                    brightness = it.brightness,
                    contrast = it.contrast,
                    saturation = it.saturation,
                ),
            )
        }
    }
    rootView.rootView.forEachTextureView { it.setLayerPaint(paint) }
}

private fun enhancerMatrix(brightness: Float, contrast: Float, saturation: Float): ColorMatrix {
    val matrix = ColorMatrix()
    matrix.setSaturation(saturation)
    // Contrast pivots around middle grey; brightness shifts everything up or down.
    val shift = (-0.5f * contrast + 0.5f + brightness) * 255f
    val contrastMatrix = ColorMatrix(
        floatArrayOf(
            contrast, 0f, 0f, 0f, shift,
            0f, contrast, 0f, 0f, shift,
            0f, 0f, contrast, 0f, shift,
            0f, 0f, 0f, 1f, 0f,
        ),
    )
    matrix.postConcat(contrastMatrix)
    return matrix
}

private fun View.forEachTextureView(action: (TextureView) -> Unit) {
    if (this is TextureView) {
        action(this)
    } else if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).forEachTextureView(action)
        }
    }
}
