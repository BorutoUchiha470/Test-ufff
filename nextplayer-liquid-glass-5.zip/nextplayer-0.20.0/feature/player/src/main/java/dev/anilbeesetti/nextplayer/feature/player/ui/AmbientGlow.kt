package dev.anilbeesetti.nextplayer.feature.player.ui

import android.graphics.Bitmap
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private const val SAMPLE_WIDTH = 32
private const val SAMPLE_HEIGHT = 18
private const val SAMPLE_INTERVAL_MS = 900L
private const val EDGE_THICKNESS = 3

private data class AmbientColors(
    val left: Color = Color.Transparent,
    val right: Color = Color.Transparent,
    val top: Color = Color.Transparent,
    val bottom: Color = Color.Transparent,
)

/**
 * A soft glow behind the video that matches the colours at the edges of the picture. It shows
 * in the black bars around the video. Needs the video to be on a TextureView.
 */
@Composable
fun AmbientGlow(strength: Float, modifier: Modifier = Modifier) {
    val rootView = LocalView.current
    var target by remember { mutableStateOf(AmbientColors()) }

    LaunchedEffect(Unit) {
        val bitmap = Bitmap.createBitmap(SAMPLE_WIDTH, SAMPLE_HEIGHT, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(SAMPLE_WIDTH * SAMPLE_HEIGHT)
        while (isActive) {
            val textureView = rootView.rootView.findTextureView()
            if (textureView != null && textureView.isAvailable) {
                val copied = runCatching { textureView.getBitmap(bitmap) }.isSuccess
                if (copied) {
                    bitmap.getPixels(pixels, 0, SAMPLE_WIDTH, 0, 0, SAMPLE_WIDTH, SAMPLE_HEIGHT)
                    target = sampleEdges(pixels)
                }
            }
            delay(SAMPLE_INTERVAL_MS)
        }
    }

    val left by animateColorAsState(target.left, tween(durationMillis = 900), label = "ambient_left")
    val right by animateColorAsState(target.right, tween(durationMillis = 900), label = "ambient_right")
    val top by animateColorAsState(target.top, tween(durationMillis = 900), label = "ambient_top")
    val bottom by animateColorAsState(target.bottom, tween(durationMillis = 900), label = "ambient_bottom")

    Box(
        modifier = modifier.drawBehind {
            val alpha = strength.coerceIn(0f, 1f)
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(left.copy(alpha = alpha), Color.Transparent),
                    startX = 0f,
                    endX = size.width * 0.55f,
                ),
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, right.copy(alpha = alpha)),
                    startX = size.width * 0.45f,
                    endX = size.width,
                ),
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(top.copy(alpha = alpha), Color.Transparent),
                    startY = 0f,
                    endY = size.height * 0.5f,
                ),
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, bottom.copy(alpha = alpha)),
                    startY = size.height * 0.5f,
                    endY = size.height,
                ),
            )
        },
    )
}

private fun sampleEdges(pixels: IntArray): AmbientColors {
    fun average(xRange: IntRange, yRange: IntRange): Color {
        var red = 0L
        var green = 0L
        var blue = 0L
        var count = 0
        for (y in yRange) {
            for (x in xRange) {
                val pixel = pixels[y * SAMPLE_WIDTH + x]
                red += (pixel shr 16) and 0xFF
                green += (pixel shr 8) and 0xFF
                blue += pixel and 0xFF
                count++
            }
        }
        if (count == 0) return Color.Transparent
        return Color(
            red = (red / count).toInt(),
            green = (green / count).toInt(),
            blue = (blue / count).toInt(),
        )
    }

    val allX = 0 until SAMPLE_WIDTH
    val allY = 0 until SAMPLE_HEIGHT
    return AmbientColors(
        left = average(0 until EDGE_THICKNESS, allY),
        right = average(SAMPLE_WIDTH - EDGE_THICKNESS until SAMPLE_WIDTH, allY),
        top = average(allX, 0 until EDGE_THICKNESS),
        bottom = average(allX, SAMPLE_HEIGHT - EDGE_THICKNESS until SAMPLE_HEIGHT),
    )
}

private fun View.findTextureView(): TextureView? {
    if (this is TextureView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findTextureView()?.let { return it }
        }
    }
    return null
}
