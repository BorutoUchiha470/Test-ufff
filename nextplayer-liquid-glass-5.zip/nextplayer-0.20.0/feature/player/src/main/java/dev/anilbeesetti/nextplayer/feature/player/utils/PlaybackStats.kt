package dev.anilbeesetti.nextplayer.feature.player.utils

import androidx.annotation.OptIn
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.analytics.AnalyticsListener

/** Live facts about the playing video, for the stats overlay. Handy to find out why a video lags. */
object PlaybackStats {
    var decoderName by mutableStateOf("")
        private set
    var format by mutableStateOf("")
        private set
    var droppedFrames by mutableIntStateOf(0)
        private set

    /** True when the decoder is a software one (Google's software codecs or FFmpeg). */
    val isSoftware: Boolean
        get() {
            val name = decoderName.lowercase()
            return name.startsWith("omx.google") ||
                name.startsWith("c2.android") ||
                name.contains("ffmpeg") ||
                name.contains("sw")
        }

    @OptIn(UnstableApi::class)
    val listener = object : AnalyticsListener {
        override fun onVideoDecoderInitialized(
            eventTime: AnalyticsListener.EventTime,
            decoderName: String,
            initializedTimestampMs: Long,
            initializationDurationMs: Long,
        ) {
            PlaybackStats.decoderName = decoderName
        }

        override fun onVideoInputFormatChanged(
            eventTime: AnalyticsListener.EventTime,
            format: Format,
            decoderReuseEvaluation: DecoderReuseEvaluation?,
        ) {
            val fps = if (format.frameRate > 0f) " ${format.frameRate.toInt()}fps" else ""
            PlaybackStats.format = "${format.width}x${format.height}$fps ${format.sampleMimeType.orEmpty()}"
        }

        override fun onDroppedVideoFrames(
            eventTime: AnalyticsListener.EventTime,
            droppedFrames: Int,
            elapsedMs: Long,
        ) {
            PlaybackStats.droppedFrames += droppedFrames
        }

        override fun onMediaItemTransition(
            eventTime: AnalyticsListener.EventTime,
            mediaItem: MediaItem?,
            reason: Int,
        ) {
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) PlaybackStats.droppedFrames = 0
        }
    }
}
