package dev.anilbeesetti.nextplayer.core.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext

private const val PREFS_NAME = "app_look"
private const val KEY_PALETTE = "palette"
private const val KEY_GLASS = "glass"
private const val KEY_CARD = "card_opacity"

/** Color themes the user can pick. DEFAULT follows the system (Material You) or the built-in teal. */
enum class ThemePalette(val label: String, val seed: Color?) {
    DEFAULT("Default", null),
    OCEAN("Ocean", Color(0xFF3B82F6)),
    SUNSET("Sunset", Color(0xFFFF7A45)),
    FOREST("Forest", Color(0xFF3FB68B)),
    SAKURA("Sakura", Color(0xFFF472B6)),
    VIOLET("Violet", Color(0xFF8B5CF6)),
    GOLD("Gold", Color(0xFFF5B301)),
}

/** The chosen color theme and glass look of the app screens. Saved and shared everywhere. */
@Stable
class AppLookState(private val prefs: SharedPreferences) {
    var paletteIndex by mutableIntStateOf(prefs.getInt(KEY_PALETTE, 0))
        private set
    var glassEnabled by mutableStateOf(prefs.getBoolean(KEY_GLASS, true))
        private set
    var cardOpacity by mutableFloatStateOf(prefs.getFloat(KEY_CARD, 0.10f))
        private set

    val palette: ThemePalette
        get() = ThemePalette.entries[paletteIndex.coerceIn(0, ThemePalette.entries.size - 1)]

    fun selectPalette(value: ThemePalette) {
        paletteIndex = value.ordinal
        prefs.edit().putInt(KEY_PALETTE, value.ordinal).apply()
    }

    fun updateGlassEnabled(value: Boolean) {
        glassEnabled = value
        prefs.edit().putBoolean(KEY_GLASS, value).apply()
    }

    fun updateCardOpacity(value: Float) {
        cardOpacity = value
        prefs.edit().putFloat(KEY_CARD, value).apply()
    }
}

object AppLookStore {
    @Volatile
    private var instance: AppLookState? = null

    fun get(context: Context): AppLookState {
        return instance ?: synchronized(this) {
            instance ?: AppLookState(
                context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}

@Composable
fun rememberAppLook(): AppLookState {
    val context = LocalContext.current
    return remember { AppLookStore.get(context) }
}

/** The see-through card color while the liquid glass app look is on, otherwise null. */
val LocalGlassCardColor = compositionLocalOf<Color?> { null }

/** Base color of a screen: see-through when the glass look is on (the gradient shows behind). */
@Composable
fun screenContainerColor(): Color {
    return if (LocalGlassCardColor.current != null) {
        Color.Transparent
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }
}

private fun hsv(hue: Float, saturation: Float, value: Float): Color {
    val wrapped = ((hue % 360f) + 360f) % 360f
    return Color(
        android.graphics.Color.HSVToColor(
            floatArrayOf(wrapped, saturation.coerceIn(0f, 1f), value.coerceIn(0f, 1f)),
        ),
    )
}

/** Builds a full color scheme out of one main color. */
internal fun paletteScheme(seed: Color, dark: Boolean): ColorScheme {
    val values = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), values)
    val h = values[0]
    return if (dark) {
        darkColorScheme(
            primary = hsv(h, 0.45f, 1f),
            onPrimary = hsv(h, 0.9f, 0.22f),
            primaryContainer = hsv(h, 0.75f, 0.38f),
            onPrimaryContainer = hsv(h, 0.2f, 1f),
            secondary = hsv(h + 15f, 0.3f, 0.92f),
            onSecondary = hsv(h + 15f, 0.8f, 0.2f),
            secondaryContainer = hsv(h + 15f, 0.45f, 0.34f),
            onSecondaryContainer = hsv(h + 15f, 0.15f, 1f),
            tertiary = hsv(h + 60f, 0.4f, 0.95f),
            onTertiary = hsv(h + 60f, 0.9f, 0.2f),
            tertiaryContainer = hsv(h + 60f, 0.6f, 0.36f),
            onTertiaryContainer = hsv(h + 60f, 0.2f, 1f),
            background = hsv(h, 0.3f, 0.09f),
            onBackground = hsv(h, 0.06f, 0.93f),
            surface = hsv(h, 0.3f, 0.09f),
            onSurface = hsv(h, 0.06f, 0.93f),
            surfaceVariant = hsv(h, 0.22f, 0.22f),
            onSurfaceVariant = hsv(h, 0.1f, 0.78f),
            outline = hsv(h, 0.12f, 0.58f),
            outlineVariant = hsv(h, 0.2f, 0.3f),
            inversePrimary = hsv(h, 0.85f, 0.55f),
            surfaceDim = hsv(h, 0.3f, 0.08f),
            surfaceBright = hsv(h, 0.26f, 0.25f),
            surfaceContainerLowest = hsv(h, 0.32f, 0.06f),
            surfaceContainerLow = hsv(h, 0.3f, 0.11f),
            surfaceContainer = hsv(h, 0.28f, 0.14f),
            surfaceContainerHigh = hsv(h, 0.26f, 0.18f),
            surfaceContainerHighest = hsv(h, 0.24f, 0.22f),
        )
    } else {
        lightColorScheme(
            primary = hsv(h, 0.85f, 0.55f),
            onPrimary = Color.White,
            primaryContainer = hsv(h, 0.25f, 1f),
            onPrimaryContainer = hsv(h, 0.9f, 0.25f),
            secondary = hsv(h + 15f, 0.5f, 0.45f),
            onSecondary = Color.White,
            secondaryContainer = hsv(h + 15f, 0.15f, 0.97f),
            onSecondaryContainer = hsv(h + 15f, 0.8f, 0.22f),
            tertiary = hsv(h + 60f, 0.6f, 0.5f),
            onTertiary = Color.White,
            tertiaryContainer = hsv(h + 60f, 0.2f, 1f),
            onTertiaryContainer = hsv(h + 60f, 0.9f, 0.25f),
            background = hsv(h, 0.05f, 0.99f),
            onBackground = hsv(h, 0.3f, 0.12f),
            surface = hsv(h, 0.05f, 0.99f),
            onSurface = hsv(h, 0.3f, 0.12f),
            surfaceVariant = hsv(h, 0.1f, 0.91f),
            onSurfaceVariant = hsv(h, 0.2f, 0.33f),
            outline = hsv(h, 0.15f, 0.5f),
            outlineVariant = hsv(h, 0.1f, 0.8f),
            inversePrimary = hsv(h, 0.4f, 1f),
            surfaceDim = hsv(h, 0.08f, 0.87f),
            surfaceBright = hsv(h, 0.05f, 0.99f),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = hsv(h, 0.05f, 0.97f),
            surfaceContainer = hsv(h, 0.07f, 0.95f),
            surfaceContainerHigh = hsv(h, 0.08f, 0.93f),
            surfaceContainerHighest = hsv(h, 0.09f, 0.91f),
        )
    }
}

/** Soft blobs of color behind the whole app, so the glass cards have something to frost. */
internal fun Modifier.auroraBackground(
    base: Color,
    first: Color,
    second: Color,
    third: Color,
    strength: Float,
): Modifier = this.drawBehind {
    drawRect(color = base)
    val radius = size.maxDimension * 0.75f
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(first.copy(alpha = 0.40f * strength), Color.Transparent),
            center = Offset(size.width * 0.05f, size.height * 0.05f),
            radius = radius,
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(second.copy(alpha = 0.32f * strength), Color.Transparent),
            center = Offset(size.width * 0.95f, size.height * 0.55f),
            radius = radius,
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(third.copy(alpha = 0.26f * strength), Color.Transparent),
            center = Offset(size.width * 0.2f, size.height * 0.98f),
            radius = radius,
        ),
    )
}
