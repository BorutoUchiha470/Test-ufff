package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.anilbeesetti.nextplayer.core.model.ThemeConfig
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.theme.ClassicThemes
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val usingGreen = Color(0xFF2ED47A)

/**
 * "App Theme" block: three big mode cards (Adaptive / Light / Dark), then the Classic Themes grid.
 * Light swatches switch the app to light, the two-tone swatches switch it to dark.
 */
@Composable
fun AppThemePicker(
    themeConfig: ThemeConfig,
    onThemeConfigChange: (ThemeConfig) -> Unit,
    modifier: Modifier = Modifier,
) {
    val look = rememberAppLook()
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeModeCard(
                label = stringResource(R.string.theme_adaptive),
                brush = Brush.linearGradient(listOf(Color(0xFFA9CCFF), Color(0xFFD9E8FF))),
                dark = false,
                selected = themeConfig == ThemeConfig.SYSTEM,
                modifier = Modifier.weight(1f),
            ) {
                look.selectClassic(-1)
                onThemeConfigChange(ThemeConfig.SYSTEM)
            }
            ThemeModeCard(
                label = stringResource(R.string.theme_light),
                brush = Brush.linearGradient(listOf(Color(0xFFEAF4FF), Color(0xFFFFFFFF))),
                dark = false,
                selected = themeConfig == ThemeConfig.OFF,
                modifier = Modifier.weight(1f),
            ) { onThemeConfigChange(ThemeConfig.OFF) }
            ThemeModeCard(
                label = stringResource(R.string.theme_dark),
                brush = Brush.linearGradient(listOf(Color(0xFF05060A), Color(0xFF23262E))),
                dark = true,
                selected = themeConfig == ThemeConfig.ON,
                modifier = Modifier.weight(1f),
            ) { onThemeConfigChange(ThemeConfig.ON) }
        }

        Text(
            text = stringResource(R.string.classic_themes),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(top = 4.dp),
        )

        // Six swatches per row, like a color chart.
        ClassicThemes.chunked(6).forEachIndexed { rowIndex, rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEachIndexed { col, theme ->
                    val index = rowIndex * 6 + col
                    val selected = look.classicIndex == index
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (theme.dark) {
                                    Brush.verticalGradient(
                                        0.5f to theme.seed,
                                        0.5f to darkTone(theme.seed),
                                    )
                                } else {
                                    Brush.linearGradient(listOf(theme.seed, theme.seed))
                                },
                            )
                            .border(
                                width = if (selected) 3.dp else 0.dp,
                                color = MaterialTheme.colorScheme.onSurface,
                                shape = RoundedCornerShape(14.dp),
                            )
                            .clickable {
                                look.selectClassic(index)
                                onThemeConfigChange(if (theme.dark) ThemeConfig.ON else ThemeConfig.OFF)
                            },
                    )
                }
                // Keep the last row's swatches the same size as the others.
                repeat(6 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

private fun darkTone(seed: Color): Color = Color(
    red = seed.red * 0.18f + 0.12f,
    green = seed.green * 0.18f + 0.12f,
    blue = seed.blue * 0.18f + 0.14f,
)

@Composable
private fun ThemeModeCard(
    label: String,
    brush: Brush,
    dark: Boolean,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1.6f)
            .clip(RoundedCornerShape(16.dp))
            .background(brush)
            .border(
                width = if (selected) 2.dp else 0.dp,
                color = MaterialTheme.colorScheme.primary,
                shape = RoundedCornerShape(16.dp),
            )
            .clickable(onClick = onClick),
    ) {
        // A little sun/moon so the three cards are easy to tell apart.
        Canvas(Modifier.matchParentSize()) {
            val c = if (dark) Color.White else Color(0xFFFFC94D)
            drawCircle(c.copy(alpha = if (dark) 0.85f else 0.9f), radius = size.minDimension * 0.18f, center = Offset(size.width * 0.8f, size.height * 0.28f))
            if (dark) {
                drawCircle(Color(0xFF23262E), radius = size.minDimension * 0.15f, center = Offset(size.width * 0.86f, size.height * 0.24f))
            }
        }
        Text(
            text = label,
            color = if (dark) Color.White else Color(0xFF263248),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 10.dp),
        )
        if (selected) {
            Text(
                text = stringResource(R.string.theme_using),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(usingGreen, RoundedCornerShape(bottomStart = 8.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

/** Pick your own photo as the app background, and tune how dark / blurry it is. */
@Composable
fun BackgroundPhotoSettings(modifier: Modifier = Modifier) {
    val look = rememberAppLook()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val saved = withContext(Dispatchers.IO) { look.setBackgroundPhoto(context, uri) }
                // The photo only shows through the glass look, so make sure it is on.
                if (saved) look.updateGlassEnabled(true)
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = stringResource(R.string.background_photo_desc),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(
                modifier = Modifier.weight(1f),
                onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            ) { Text(stringResource(if (look.hasBackgroundPhoto) R.string.background_change_photo else R.string.background_pick_photo)) }
            if (look.hasBackgroundPhoto) {
                OutlinedButton(onClick = { look.clearBackgroundPhoto(context) }) {
                    Text(stringResource(R.string.background_remove))
                }
            }
        }
        if (look.hasBackgroundPhoto) {
            Text(stringResource(R.string.background_dim), style = MaterialTheme.typography.labelLarge)
            Slider(
                value = look.backgroundDim,
                onValueChange = { look.updateBackgroundDim(it) },
                valueRange = 0f..0.8f,
            )
            Text(stringResource(R.string.background_blur), style = MaterialTheme.typography.labelLarge)
            Slider(
                value = look.backgroundBlur,
                onValueChange = { look.updateBackgroundBlur(it) },
                valueRange = 0f..25f,
            )
        }
        Spacer(Modifier.height(4.dp))
    }
}
