package dev.anilbeesetti.nextplayer.settings.navigation

import androidx.compose.runtime.SideEffect
import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import dev.anilbeesetti.nextplayer.settings.screens.appearance.AppearancePreferencesViewModel
import dev.anilbeesetti.nextplayer.settings.screens.appearance.ThemePreferencesScreen
import kotlinx.serialization.Serializable
import org.koin.compose.viewmodel.koinViewModel
import org.koin.core.parameter.parametersOf

@Serializable
object ThemePreferencesRoute : NavKey

fun NavBackStack<NavKey>.navigateToThemePreferences() {
    add(element = ThemePreferencesRoute)
}

fun EntryProviderScope<NavKey>.themePreferencesEntry(onNavigateUp: () -> Unit) {
    entry<ThemePreferencesRoute> {
        val output = AppearancePreferencesViewModel.Output(navigateUp = onNavigateUp)
        val viewModel = koinViewModel<AppearancePreferencesViewModel>(
            parameters = { parametersOf(output) },
        )
        SideEffect { viewModel.output = output }
        ThemePreferencesScreen(viewModel = viewModel)
    }
}
