package dev.anilbeesetti.nextplayer.settings.navigation

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import dev.anilbeesetti.nextplayer.settings.screens.shorts.ShortsPreferencesScreen
import kotlinx.serialization.Serializable

@Serializable
object ShortsPreferencesRoute : NavKey

fun NavBackStack<NavKey>.navigateToShortsPreferences() {
    add(element = ShortsPreferencesRoute)
}

fun EntryProviderScope<NavKey>.shortsPreferencesEntry(onNavigateUp: () -> Unit) {
    entry<ShortsPreferencesRoute> {
        ShortsPreferencesScreen(onNavigateUp = onNavigateUp)
    }
}
