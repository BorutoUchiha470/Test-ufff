package dev.anilbeesetti.nextplayer.settings.screens.shorts

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.ClickablePreferenceItem
import dev.anilbeesetti.nextplayer.core.ui.components.ListSectionTitle
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitch
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.shorts.ShortsPrefs
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook
import dev.anilbeesetti.nextplayer.core.ui.theme.screenContainerColor

/** Settings for the Shorts tab: what shows up, how it swipes, the side buttons, blocked and liked videos. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShortsPreferencesScreen(onNavigateUp: () -> Unit) {
    val context = LocalContext.current
    val prefs = ShortsPrefs.get(context)
    val look = rememberAppLook()

    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(id = R.string.shorts_prefs_name),
                navigationIcon = {
                    FilledTonalIconButton(onClick = onNavigateUp) {
                        Icon(
                            imageVector = NextIcons.ArrowBack,
                            contentDescription = stringResource(id = R.string.navigate_up),
                        )
                    }
                },
            )
        },
        containerColor = screenContainerColor(),
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(state = rememberScrollState())
                .padding(paddingValues = innerPadding)
                .padding(horizontal = 16.dp),
        ) {
            ListSectionTitle(text = stringResource(id = R.string.shorts_general))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_enable),
                    description = stringResource(R.string.shorts_enable_desc),
                    icon = NextIcons.Shorts,
                    isChecked = look.showShortsTab,
                    onClick = { look.updateShowShortsTab(!look.showShortsTab) },
                    isFirstItem = true,
                )
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_auto_next),
                    description = stringResource(R.string.shorts_auto_next_desc),
                    icon = NextIcons.Play,
                    isChecked = prefs.autoNext,
                    onClick = { prefs.updateAutoNext(!prefs.autoNext) },
                )
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_muted),
                    icon = NextIcons.VolumeOff,
                    isChecked = prefs.startMuted,
                    onClick = { prefs.updateStartMuted(!prefs.startMuted) },
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.shorts_discovery))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_include_normal),
                    description = stringResource(R.string.shorts_include_normal_desc),
                    icon = NextIcons.Movie,
                    isChecked = prefs.includeNormal,
                    onClick = { prefs.updateIncludeNormal(!prefs.includeNormal) },
                    isFirstItem = true,
                )
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_shuffle),
                    description = stringResource(R.string.shorts_shuffle_desc),
                    icon = NextIcons.Shuffle,
                    isChecked = prefs.shuffle,
                    onClick = { prefs.updateShuffle(!prefs.shuffle) },
                    isLastItem = prefs.includeNormal.not(),
                )
                if (prefs.includeNormal) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text(
                            text = stringResource(R.string.shorts_max_h) + " · " +
                                stringResource(R.string.shorts_max_h_value, prefs.maxHorizontalSeconds),
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Slider(
                            value = prefs.maxHorizontalSeconds.toFloat(),
                            onValueChange = { prefs.updateMaxHorizontalSeconds(it.toInt()) },
                            valueRange = 10f..180f,
                            steps = 16,
                        )
                    }
                }
            }

            ListSectionTitle(text = stringResource(id = R.string.shorts_controls))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_glass_controls),
                    description = stringResource(R.string.shorts_glass_controls_desc),
                    icon = NextIcons.Appearance,
                    isChecked = prefs.glassControls,
                    onClick = { prefs.updateGlassControls(!prefs.glassControls) },
                    isFirstItem = true,
                )
                PreferenceSwitch(
                    title = stringResource(R.string.shorts_show_back),
                    description = stringResource(R.string.shorts_show_back_desc),
                    icon = NextIcons.ArrowBack,
                    isChecked = prefs.showBack,
                    onClick = { prefs.updateShowBack(!prefs.showBack) },
                    isLastItem = true,
                )
            }

            ListSectionTitle(text = stringResource(id = R.string.shorts_manage))
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ClickablePreferenceItem(
                    title = stringResource(R.string.shorts_blocked),
                    description = stringResource(R.string.shorts_blocked_desc, prefs.blocked.size),
                    icon = NextIcons.Block,
                    enabled = prefs.blocked.isNotEmpty(),
                    onClick = { prefs.clearBlocked() },
                    isFirstItem = true,
                )
                ClickablePreferenceItem(
                    title = stringResource(R.string.shorts_liked_manage),
                    description = stringResource(R.string.shorts_liked_manage_desc, prefs.liked.size),
                    icon = NextIcons.Favorite,
                    enabled = prefs.liked.isNotEmpty(),
                    onClick = { prefs.clearLiked() },
                    isLastItem = true,
                )
            }
        }
    }
}
