package dev.anilbeesetti.nextplayer.settings.screens.appearance

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.ClickablePreferenceItem
import dev.anilbeesetti.nextplayer.core.ui.components.PreferenceSwitch
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook

/** Opens the system's per-app language screen. */
@Composable
fun AppLanguageItem() {
    val context = LocalContext.current
    ClickablePreferenceItem(
        title = stringResource(R.string.app_language),
        description = stringResource(R.string.app_language_desc),
        icon = NextIcons.Language,
        onClick = {
            val intent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Intent(Settings.ACTION_APP_LOCALE_SETTINGS).setData(Uri.fromParts("package", context.packageName, null))
            } else {
                Intent(Settings.ACTION_LOCALE_SETTINGS)
            }
            runCatching { context.startActivity(intent) }
        },
        isFirstItem = true,
        isLastItem = true,
    )
}

/** Choose which tabs appear in the bottom bar. Home and You are always there. */
@Composable
fun BottomTabsSettings() {
    val look = rememberAppLook()
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        PreferenceSwitch(
            title = stringResource(R.string.tab_home),
            description = stringResource(R.string.tab_home_desc),
            icon = NextIcons.Home,
            isChecked = true,
            enabled = false,
            isFirstItem = true,
        )
        PreferenceSwitch(
            title = stringResource(R.string.tab_shorts),
            description = stringResource(R.string.tab_shorts_desc),
            icon = NextIcons.Shorts,
            isChecked = look.showShortsTab,
            onClick = { look.updateShowShortsTab(!look.showShortsTab) },
        )
        PreferenceSwitch(
            title = stringResource(R.string.tab_network),
            description = stringResource(R.string.tab_network_desc),
            icon = NextIcons.Network,
            isChecked = look.showNetworkTab,
            onClick = { look.updateShowNetworkTab(!look.showNetworkTab) },
            isLastItem = true,
        )
    }
}
