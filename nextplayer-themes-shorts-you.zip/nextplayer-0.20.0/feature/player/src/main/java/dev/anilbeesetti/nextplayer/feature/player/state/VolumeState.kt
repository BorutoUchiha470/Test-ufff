package dev.anilbeesetti.nextplayer.feature.player.state

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import androidx.annotation.OptIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.DisposableEffectResult
import androidx.compose.runtime.DisposableEffectScope
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat.getSystemService
import androidx.media3.common.Player
import androidx.media3.common.listen
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import dev.anilbeesetti.nextplayer.feature.player.service.getIsLoudnessGainSupported
import dev.anilbeesetti.nextplayer.feature.player.service.getLoudnessGain
import dev.anilbeesetti.nextplayer.feature.player.service.setLoudnessGain
import kotlinx.coroutines.CoroutineScope
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun rememberVolumeState(player: Player?, showVolumePanelIfHeadsetIsOn: Boolean): VolumeState {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val volumeState = remember(player) {
        VolumeState(
            player = player,
            context = context,
            showVolumePanelIfHeadsetIsOn = showVolumePanelIfHeadsetIsOn,
            scope = scope,
        )
    }
    LaunchedEffect(key1 = player) { volumeState.initialize() }
    DisposableEffect(key1 = context) { volumeState.handleLifecycle(disposableEffectScope = this) }
    return volumeState
}

@Stable
class VolumeState(
    private val player: Player?,
    private val context: Context,
    private val showVolumePanelIfHeadsetIsOn: Boolean,
    private val scope: CoroutineScope,
) {
    private val audioManager = getSystemService(
        context,
        AudioManager::class.java,
    )!!

    private val systemMaxVolume: Int = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

    private var isLoudnessGainSupported: Boolean by mutableStateOf(value = false)

    val maxVolume: Int
        get() = if (isLoudnessGainSupported) systemMaxVolume * 2 else systemMaxVolume

    val maxVolumePercentage: Int
        get() = if (isLoudnessGainSupported) {
            MAX_VOLUME_PERCENTAGE_BOOST
        } else {
            MAX_VOLUME_PERCENTAGE_NORMAL
        }

    var currentVolume: Int by mutableIntStateOf(audioManager.currentStreamVolume)
        private set

    var volumePercentage: Int by mutableIntStateOf(value = calculateVolumePercentage())
        private set

    /**
     * Exact (not rounded to a system step) volume while the finger is moving. The on-screen bar
     * and the swipe follow this, so they move smoothly instead of jumping a whole step at a time.
     */
    var smoothPercentage: Float by mutableFloatStateOf(value = calculateVolumePercentage().toFloat())
        private set

    /** True while a swipe is in progress: system volume broadcasts must not move the bar then. */
    @Volatile
    var isAdjusting: Boolean = false

    // What was last sent, so the system and the player are only called when something changed.
    private var appliedSystemVolume = -1
    private var appliedGain = Int.MIN_VALUE

    fun syncWithSystem() {
        if (currentVolume > systemMaxVolume) return
        val systemVolume = audioManager.currentStreamVolume
        if (systemVolume != currentVolume) {
            currentVolume = systemVolume
            refreshPercentage()
        }
        appliedSystemVolume = systemVolume
    }

    /** Smooth volume change for the swipe gesture (percentage is not rounded to a system step). */
    fun updateVolumePercentage(percentage: Float) {
        val percent = percentage.coerceIn(0f, maxVolumePercentage.toFloat())
        smoothPercentage = percent
        volumePercentage = percent.roundToInt()

        val normal = percent.coerceAtMost(MAX_VOLUME_PERCENTAGE_NORMAL.toFloat())
        val systemStep = (normal * systemMaxVolume / MAX_VOLUME_PERCENTAGE_NORMAL).roundToInt()
        currentVolume = if (percent <= MAX_VOLUME_PERCENTAGE_NORMAL) {
            systemStep
        } else {
            systemMaxVolume + ((percent - MAX_VOLUME_PERCENTAGE_NORMAL) / MAX_VOLUME_PERCENTAGE_NORMAL * systemMaxVolume).roundToInt()
        }

        if (systemStep != appliedSystemVolume) {
            setSystemVolume(volume = systemStep, showVolumePanel = false)
        }
        val gain = if (percent > MAX_VOLUME_PERCENTAGE_NORMAL) {
            ((percent - MAX_VOLUME_PERCENTAGE_NORMAL) / MAX_VOLUME_PERCENTAGE_NORMAL * MAX_BOOST_GAIN_MB).toInt()
        } else {
            0
        }
        applyGain(gain = (gain / GAIN_STEP_MB) * GAIN_STEP_MB)
    }

    fun increaseVolume(showVolumePanel: Boolean = false) {
        setVolume(
            volume = currentVolume + 1,
            showVolumePanel = showVolumePanel,
        )
    }

    fun decreaseVolume(showVolumePanel: Boolean = false) {
        setVolume(
            volume = currentVolume - 1,
            showVolumePanel = showVolumePanel,
        )
    }

    fun handleLifecycle(disposableEffectScope: DisposableEffectScope): DisposableEffectResult =
        with(receiver = disposableEffectScope) {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context, intent: Intent) {
                    if (intent.action == VOLUME_CHANGED_ACTION) {
                        if (!isAdjusting && currentVolume <= systemMaxVolume) {
                            currentVolume = audioManager.currentStreamVolume
                            appliedSystemVolume = currentVolume
                            refreshPercentage()
                        }
                    }
                }
            }

            context.registerReceiver(
                receiver,
                IntentFilter(VOLUME_CHANGED_ACTION),
            )

            onDispose { context.unregisterReceiver(receiver) }
        }

    suspend fun initialize() {
        val player = player as? MediaController ?: return
        isLoudnessGainSupported = player.getIsLoudnessGainSupported()
        val loudnessGain = player.getLoudnessGain()
        val systemVolume = audioManager.currentStreamVolume

        if (loudnessGain > 0 && isLoudnessGainSupported) {
            if (systemVolume < systemMaxVolume) {
                currentVolume = systemVolume
                refreshPercentage()
                player.setLoudnessGain(gain = 0)
            } else {
                val boostVolume = (loudnessGain * systemMaxVolume) / MAX_BOOST_GAIN_MB
                currentVolume = systemMaxVolume + boostVolume
                refreshPercentage()
            }
        }

        player.listen { events ->
            if (events.contains(Player.EVENT_AUDIO_SESSION_ID)) {
                scope.launch { isLoudnessGainSupported = player.getIsLoudnessGainSupported() }
            }
        }
    }

    private fun setVolume(volume: Int, showVolumePanel: Boolean = false) {
        val clampedVolume = volume.coerceIn(
            minimumValue = 0,
            maximumValue = maxVolume,
        )
        currentVolume = clampedVolume
        refreshPercentage()

        if (clampedVolume <= systemMaxVolume) {
            setSystemVolume(
                volume = clampedVolume,
                showVolumePanel = showVolumePanel,
            )
            applyVolumeBoost(volume = 0)
        } else {
            setSystemVolume(
                volume = systemMaxVolume,
                showVolumePanel = showVolumePanel,
            )
            applyVolumeBoost(volume = clampedVolume - systemMaxVolume)
        }
    }

    private fun refreshPercentage() {
        volumePercentage = calculateVolumePercentage()
        smoothPercentage = volumePercentage.toFloat()
    }

    private fun setSystemVolume(volume: Int, showVolumePanel: Boolean) {
        val shouldShowUi =
            showVolumePanel || (showVolumePanelIfHeadsetIsOn && audioManager.isHeadsetOn)
        val target = volume.coerceIn(
            minimumValue = 0,
            maximumValue = systemMaxVolume,
        )
        appliedSystemVolume = target
        audioManager.setStreamVolume(
            AudioManager.STREAM_MUSIC,
            target,
            if (shouldShowUi) AudioManager.FLAG_SHOW_UI else 0,
        )
    }

    private fun applyVolumeBoost(volume: Int) {
        val player = player as? MediaController ?: return
        val gainMillibels = (volume.toFloat() / systemMaxVolume * MAX_BOOST_GAIN_MB).toInt()
        applyGain(gain = gainMillibels)
    }

    /** Sends the boost to the player only when it really changed (each call is an IPC message). */
    private fun applyGain(gain: Int) {
        if (gain == appliedGain) return
        val player = player as? MediaController ?: return
        appliedGain = gain
        try {
            player.setLoudnessGain(gain = gain)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun calculateVolumePercentage(): Int =
        (currentVolume.toFloat() / systemMaxVolume * MAX_VOLUME_PERCENTAGE_NORMAL).toInt()

    private val AudioManager.currentStreamVolume: Int
        get() = getStreamVolume(AudioManager.STREAM_MUSIC)

    private val AudioManager.isHeadsetOn: Boolean
        get() = getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { device ->
            device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
                        device.type == AudioDeviceInfo.TYPE_USB_HEADSET
                    )
        }

    companion object {
        private const val VOLUME_CHANGED_ACTION = "android.media.VOLUME_CHANGED_ACTION"
        private const val MAX_VOLUME_PERCENTAGE_NORMAL = 100
        private const val MAX_VOLUME_PERCENTAGE_BOOST = 200
        private const val MAX_BOOST_GAIN_MB = 2000
        private const val GAIN_STEP_MB = 20
    }
}
