package dev.anilbeesetti.nextplayer.core.ui.designsystem

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.CompareArrows
import androidx.compose.material.icons.automirrored.rounded.DriveFileMove
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.PlaylistPlay
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.SlowMotionVideo
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.AppSettingsAlt
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.BrightnessHigh
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Contrast
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Dashboard
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Deselect
import androidx.compose.material.icons.rounded.DeveloperBoard
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.DoubleArrow
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FileOpen
import androidx.compose.material.icons.rounded.FilterFrames
import androidx.compose.material.icons.rounded.Fingerprint
import androidx.compose.material.icons.rounded.FlipToBack
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.FolderOff
import androidx.compose.material.icons.rounded.FontDownload
import androidx.compose.material.icons.rounded.FormatBold
import androidx.compose.material.icons.rounded.FormatSize
import androidx.compose.material.icons.rounded.Headset
import androidx.compose.material.icons.rounded.HeadsetOff
import androidx.compose.material.icons.rounded.HideSource
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lan
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.LocalMovies
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.MiscellaneousServices
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PanToolAlt
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.Pinch
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.PriorityHigh
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ResetTv
import androidx.compose.material.icons.rounded.ScreenRotationAlt
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.SmartButton
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.Straighten
import androidx.compose.material.icons.rounded.Style
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material.icons.rounded.SwipeVertical
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material.icons.rounded.Title
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Update

object NextIcons {
    val Add = Icons.Rounded.Add
    val Appearance = Icons.Rounded.Palette
    val ArrowBack = Icons.AutoMirrored.Rounded.ArrowBack
    val ArrowForward = Icons.AutoMirrored.Rounded.ArrowForward
    val ArrowDownward = Icons.Rounded.ArrowDownward
    val ArrowUpward = Icons.Rounded.ArrowUpward
    val Audio = Icons.Rounded.Audiotrack
    val Background = Icons.Rounded.FlipToBack
    val Bold = Icons.Rounded.FormatBold
    val Brightness = Icons.Rounded.BrightnessHigh
    val Calendar = Icons.Rounded.CalendarMonth
    val Caption = Icons.Rounded.ClosedCaption
    val Check = Icons.Rounded.Check
    val CheckBox = Icons.Rounded.CheckCircle
    val CheckBoxOutline = Icons.Rounded.RadioButtonUnchecked
    val Contrast = Icons.Rounded.Contrast
    val DarkMode = Icons.Rounded.DarkMode
    val DashBoard = Icons.Rounded.Dashboard
    val Decoder = Icons.Rounded.DeveloperBoard
    val Delete = Icons.Rounded.Delete
    val DoubleTap = Icons.Rounded.DoubleArrow
    val Edit = Icons.Rounded.Edit
    val Fast = Icons.Rounded.FastForward
    val FileOpen = Icons.Rounded.FileOpen
    val Focus = Icons.Rounded.CenterFocusStrong
    val Folder = Icons.Rounded.Folder
    val FolderOff = Icons.Rounded.FolderOff
    val Font = Icons.Rounded.FontDownload
    val FontSize = Icons.Rounded.FormatSize
    val Headset = Icons.Rounded.Headset
    val HeadsetOff = Icons.Rounded.HeadsetOff
    val Info = Icons.Rounded.Info
    val Home = Icons.Rounded.Home
    val HomeOutline = Icons.Outlined.Home
    val Network = Icons.Rounded.Lan
    val Cloud = Icons.Rounded.Cloud
    val Dns = Icons.Rounded.Dns
    val Storage = Icons.Rounded.Storage
    val Language = Icons.Rounded.Translate
    val Length = Icons.Rounded.Straighten
    val Link = Icons.Rounded.Link
    val Location = Icons.Rounded.LocationOn
    val Movie = Icons.Rounded.LocalMovies
    val Pip = Icons.Rounded.PictureInPictureAlt
    val Pinch = Icons.Rounded.Pinch
    val Play = Icons.Rounded.PlayArrow
    val Player = Icons.Rounded.PlayCircle
    val Playlist = Icons.AutoMirrored.Rounded.PlaylistPlay
    val PlaylistAdd = Icons.AutoMirrored.Rounded.PlaylistAdd
    val Priority = Icons.Rounded.PriorityHigh
    val Replay = Icons.Rounded.Replay10
    val Resume = Icons.Rounded.ResetTv
    val Rotation = Icons.Rounded.ScreenRotationAlt
    val Search = Icons.Rounded.Search
    val Selection = Icons.Rounded.DoneAll
    val Settings = Icons.Rounded.Settings
    val Share = Icons.Rounded.Share
    val SmartButton = Icons.Rounded.SmartButton
    val Style = Icons.Rounded.Style
    val Subtitle = Icons.Rounded.Subtitles
    val Size = Icons.AutoMirrored.Rounded.CompareArrows
    val Sensitivity = Icons.Rounded.Tune
    val Speed = Icons.Rounded.Speed
    val SwipeHorizontal = Icons.Rounded.Swipe
    val SwipeVertical = Icons.Rounded.SwipeVertical
    val Tap = Icons.Rounded.TouchApp
    val Timer = Icons.Rounded.Timer
    val Title = Icons.Rounded.Title
    val Update = Icons.Rounded.Update
    val Video = Icons.Rounded.Movie
    val VolumeUp = Icons.AutoMirrored.Rounded.VolumeUp
    val ButtonsPosition = Icons.Rounded.AppSettingsAlt
    val Close = Icons.Rounded.Close
    val History = Icons.Rounded.History
    val Pan = Icons.Rounded.PanToolAlt
    val HideSource = Icons.Rounded.HideSource
    val SelectAll = Icons.Rounded.SelectAll
    val DeselectAll = Icons.Rounded.Deselect
    val FastForward = Icons.Rounded.FastForward
    val BugReport = Icons.Rounded.BugReport
    val Copy = Icons.Rounded.ContentCopy
    val Move = Icons.AutoMirrored.Rounded.DriveFileMove
    val ExtraSettings = Icons.Rounded.MiscellaneousServices
    val MoreVert = Icons.Rounded.MoreVert
    val More = Icons.Rounded.MoreHoriz
    val DeleteSweep = Icons.Rounded.DeleteSweep
    val Image = Icons.Rounded.Image
    val Frame = Icons.Rounded.FilterFrames
    val Lock = Icons.Rounded.Lock
    val Fingerprint = Icons.Rounded.Fingerprint
    val DragHandle = Icons.Rounded.DragHandle
    val Reorder = Icons.Rounded.SwapVert
    val Shorts = Icons.Rounded.SlowMotionVideo
    val Person = Icons.Rounded.Person
    val Favorite = Icons.Rounded.Favorite
    val FavoriteBorder = Icons.Rounded.FavoriteBorder
    val VolumeOff = Icons.Rounded.VolumeOff
    val Pause = Icons.Rounded.Pause
    val Block = Icons.Rounded.Block
    val Fullscreen = Icons.Rounded.Fullscreen
    val FullscreenExit = Icons.Rounded.FullscreenExit
    val ChevronRight = Icons.AutoMirrored.Rounded.KeyboardArrowRight
    val MoreVert = Icons.Rounded.MoreVert
    val Shuffle = Icons.Rounded.Shuffle
}
