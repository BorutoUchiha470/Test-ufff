package dev.anilbeesetti.nextplayer.core.ui.theme

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext

private const val PREFS_NAME = "app_look"
private const val KEY_PALETTE = "palette"
private const val KEY_GLASS = "glass"
private const val KEY_CARD = "card_opacity"
private const val KEY_CARD_TINT = "card_tint"
private const val KEY_FAST_TRANSITIONS = "fast_transitions"
private const val KEY_LIQUID_TRANSITIONS = "liquid_transitions"
private const val KEY_PRESS_EFFECT = "press_effect"
private const val KEY_CLASSIC = "classic_theme"
private const val KEY_BG_VERSION = "bg_version"
private const val KEY_BG_DIM = "bg_dim"
private const val KEY_BG_BLUR = "bg_blur"
private const val KEY_BG_COLOR = "bg_color"
private const val KEY_TAB_SHORTS = "tab_shorts"
private const val KEY_TAB_NETWORK = "tab_network"
private const val BACKGROUND_FILE = "app_background.jpg"

/** One of the "Classic Themes" swatches. [dark] swatches are the two-tone ones that switch the app to dark. */
data class ClassicTheme(val seed: Color, val dark: Boolean)

private val classicSeeds = listOf(
    0xFFFA5F55, 0xFFFF9A55, 0xFFFFC435, 0xFF9E6650, 0xFFCED417, 0xFFA3DA4F,
    0xFF4FCF66, 0xFF1BC191, 0xFF4EB4E8, 0xFF548EE0, 0xFF5468E8, 0xFF9566EE,
    0xFFD855E8, 0xFFFF4F88, 0xFFE5468B,
).map { Color(it) }

/** 16 light swatches (the last one is neutral grey) followed by 15 dark two-tone ones. */
val ClassicThemes: List<ClassicTheme> =
    classicSeeds.map { ClassicTheme(it, dark = false) } +
        ClassicTheme(Color(0xFFDEE1E4), dark = false) +
        classicSeeds.map { ClassicTheme(it, dark = true) }

/** Color themes the user can pick. DEFAULT follows the system (Material You) or the built-in teal. */
enum class ThemePalette(val label: String, val seed: Color?) {
    DEFAULT("Default", null),
    OCEAN("Ocean", Color(0xFF3B82F6)),
    SUNSET("Sunset", Color(0xFFFF7A45)),
    FOREST("Forest", Color(0xFF3FB68B)),
    SAKURA("Sakura", Color(0xFFF472B6)),
    VIOLET("Violet", Color(0xFF8B5CF6)),
    GOLD("Gold", Color(0xFFF5B301)),
}

/** The chosen color theme and glass look of the app screens. Saved and shared everywhere. */
@Stable
class AppLookState(private val prefs: SharedPreferences) {
    var paletteIndex by mutableIntStateOf(prefs.getInt(KEY_PALETTE, 0))
        private set
    var glassEnabled by mutableStateOf(prefs.getBoolean(KEY_GLASS, true))
        private set
    var cardOpacity by mutableFloatStateOf(prefs.getFloat(KEY_CARD, 0.10f))
        private set

    var fastTransitions by mutableStateOf(prefs.getBoolean(KEY_FAST_TRANSITIONS, true))
        private set

    /** The colour of the glass cards (without transparency). White by default. */
    var cardTint by mutableIntStateOf(prefs.getInt(KEY_CARD_TINT, 0xFFFFFFFF.toInt()))
        private set

    fun updateCardTint(value: Int) {
        cardTint = value
        prefs.edit().putInt(KEY_CARD_TINT, value).apply()
    }

    /** Index into [ClassicThemes], or -1 when no classic swatch is chosen. */
    var classicIndex by mutableIntStateOf(prefs.getInt(KEY_CLASSIC, -1))
        private set

    val classicTheme: ClassicTheme?
        get() = ClassicThemes.getOrNull(classicIndex)

    fun selectClassic(index: Int) {
        classicIndex = index
        prefs.edit().putInt(KEY_CLASSIC, index).apply()
    }

    /** Bumped every time a new background photo is saved, so screens reload it. */
    var backgroundVersion by mutableIntStateOf(prefs.getInt(KEY_BG_VERSION, 0))
        private set

    var backgroundDim by mutableFloatStateOf(prefs.getFloat(KEY_BG_DIM, 0.35f))
        private set

    var backgroundBlur by mutableFloatStateOf(prefs.getFloat(KEY_BG_BLUR, 0f))
        private set

    val hasBackgroundPhoto: Boolean get() = backgroundVersion > 0

    /** A plain background colour (ARGB), or 0 for the default colourful gradient. A photo wins over it. */
    var backgroundColor by mutableIntStateOf(prefs.getInt(KEY_BG_COLOR, 0))
        private set

    fun updateBackgroundColor(context: Context, value: Int) {
        // A plain colour replaces the photo, so the pick takes effect straight away.
        if (hasBackgroundPhoto) clearBackgroundPhoto(context)
        backgroundColor = value
        prefs.edit().putInt(KEY_BG_COLOR, value).apply()
    }

    /** Bottom bar tabs the user can switch off (Home and You are always shown). */
    var showShortsTab by mutableStateOf(prefs.getBoolean(KEY_TAB_SHORTS, true))
        private set
    var showNetworkTab by mutableStateOf(prefs.getBoolean(KEY_TAB_NETWORK, true))
        private set

    fun updateShowShortsTab(value: Boolean) {
        showShortsTab = value
        prefs.edit().putBoolean(KEY_TAB_SHORTS, value).apply()
    }

    fun updateShowNetworkTab(value: Boolean) {
        showNetworkTab = value
        prefs.edit().putBoolean(KEY_TAB_NETWORK, value).apply()
    }

    fun updateBackgroundDim(value: Float) {
        backgroundDim = value
        prefs.edit().putFloat(KEY_BG_DIM, value).apply()
    }

    fun updateBackgroundBlur(value: Float) {
        backgroundBlur = value
        prefs.edit().putFloat(KEY_BG_BLUR, value).apply()
    }

    /** Copies the picked photo into app storage (so it keeps working after a restart) and starts using it. */
    fun setBackgroundPhoto(context: Context, uri: android.net.Uri): Boolean {
        val ok = runCatching {
            val bitmap = decodeScaledBitmap(context, uri, maxSide = 1920) ?: return false
            java.io.File(context.filesDir, BACKGROUND_FILE).outputStream().use {
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it)
            }
            true
        }.getOrDefault(false)
        if (ok) {
            backgroundVersion += 1
            prefs.edit().putInt(KEY_BG_VERSION, backgroundVersion).apply()
        }
        return ok
    }

    fun clearBackgroundPhoto(context: Context) {
        java.io.File(context.filesDir, BACKGROUND_FILE).delete()
        backgroundVersion = 0
        prefs.edit().putInt(KEY_BG_VERSION, 0).apply()
    }

    var pressEffect by mutableStateOf(prefs.getBoolean(KEY_PRESS_EFFECT, true))
        private set

    fun updatePressEffect(value: Boolean) {
        pressEffect = value
        prefs.edit().putBoolean(KEY_PRESS_EFFECT, value).apply()
    }

    var liquidTransitions by mutableStateOf(prefs.getBoolean(KEY_LIQUID_TRANSITIONS, false))
        private set

    fun updateLiquidTransitions(value: Boolean) {
        liquidTransitions = value
        prefs.edit().putBoolean(KEY_LIQUID_TRANSITIONS, value).apply()
    }

    fun updateFastTransitions(value: Boolean) {
        fastTransitions = value
        prefs.edit().putBoolean(KEY_FAST_TRANSITIONS, value).apply()
    }

    val palette: ThemePalette
        get() = ThemePalette.entries[paletteIndex.coerceIn(0, ThemePalette.entries.size - 1)]

    fun selectPalette(value: ThemePalette) {
        paletteIndex = value.ordinal
        prefs.edit().putInt(KEY_PALETTE, value.ordinal).apply()
    }

    fun updateGlassEnabled(value: Boolean) {
        glassEnabled = value
        prefs.edit().putBoolean(KEY_GLASS, value).apply()
    }

    fun updateCardOpacity(value: Float) {
        cardOpacity = value
        prefs.edit().putFloat(KEY_CARD, value).apply()
    }
}

object AppLookStore {
    @Volatile
    private var instance: AppLookState? = null

    /** The state if the app look has already been loaded (it is, as soon as the theme is shown). */
    fun peek(): AppLookState? = instance

    fun get(context: Context): AppLookState {
        return instance ?: synchronized(this) {
            instance ?: AppLookState(
                context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}

@Composable
fun rememberAppLook(): AppLookState {
    val context = LocalContext.current
    return remember { AppLookStore.get(context) }
}

/** The see-through card color while the liquid glass app look is on, otherwise null. */
val LocalGlassCardColor = compositionLocalOf<Color?> { null }

/** Base color of a screen: see-through when the glass look is on (the gradient shows behind). */
@Composable
fun screenContainerColor(): Color {
    return if (LocalGlassCardColor.current != null) {
        Color.Transparent
    } else {
        MaterialTheme.colorScheme.surfaceContainer
    }
}

private fun hsv(hue: Float, saturation: Float, value: Float): Color {
    val wrapped = ((hue % 360f) + 360f) % 360f
    return Color(
        android.graphics.Color.HSVToColor(
            floatArrayOf(wrapped, saturation.coerceIn(0f, 1f), value.coerceIn(0f, 1f)),
        ),
    )
}

/** Builds a full color scheme out of one main color. */
internal fun paletteScheme(seed: Color, dark: Boolean): ColorScheme {
    val values = FloatArray(3)
    android.graphics.Color.colorToHSV(seed.toArgb(), values)
    val h = values[0]
    // A grey swatch should give a grey app, not a tinted one.
    val k = if (values[1] < 0.12f) 0f else 1f
    fun tone(hue: Float, saturation: Float, value: Float) = hsv(hue, saturation * k, value)
    return if (dark) {
        darkColorScheme(
            primary = tone(h, 0.45f, 1f),
            onPrimary = tone(h, 0.9f, 0.22f),
            primaryContainer = tone(h, 0.75f, 0.38f),
            onPrimaryContainer = tone(h, 0.2f, 1f),
            secondary = tone(h + 15f, 0.3f, 0.92f),
            onSecondary = tone(h + 15f, 0.8f, 0.2f),
            secondaryContainer = tone(h + 15f, 0.45f, 0.34f),
            onSecondaryContainer = tone(h + 15f, 0.15f, 1f),
            tertiary = tone(h + 60f, 0.4f, 0.95f),
            onTertiary = tone(h + 60f, 0.9f, 0.2f),
            tertiaryContainer = tone(h + 60f, 0.6f, 0.36f),
            onTertiaryContainer = tone(h + 60f, 0.2f, 1f),
            background = tone(h, 0.3f, 0.09f),
            onBackground = tone(h, 0.06f, 0.93f),
            surface = tone(h, 0.3f, 0.09f),
            onSurface = tone(h, 0.06f, 0.93f),
            surfaceVariant = tone(h, 0.22f, 0.22f),
            onSurfaceVariant = tone(h, 0.1f, 0.78f),
            outline = tone(h, 0.12f, 0.58f),
            outlineVariant = tone(h, 0.2f, 0.3f),
            inversePrimary = tone(h, 0.85f, 0.55f),
            surfaceDim = tone(h, 0.3f, 0.08f),
            surfaceBright = tone(h, 0.26f, 0.25f),
            surfaceContainerLowest = tone(h, 0.32f, 0.06f),
            surfaceContainerLow = tone(h, 0.3f, 0.11f),
            surfaceContainer = tone(h, 0.28f, 0.14f),
            surfaceContainerHigh = tone(h, 0.26f, 0.18f),
            surfaceContainerHighest = tone(h, 0.24f, 0.22f),
        )
    } else {
        lightColorScheme(
            primary = tone(h, 0.85f, 0.55f),
            onPrimary = Color.White,
            primaryContainer = tone(h, 0.25f, 1f),
            onPrimaryContainer = tone(h, 0.9f, 0.25f),
            secondary = tone(h + 15f, 0.5f, 0.45f),
            onSecondary = Color.White,
            secondaryContainer = tone(h + 15f, 0.15f, 0.97f),
            onSecondaryContainer = tone(h + 15f, 0.8f, 0.22f),
            tertiary = tone(h + 60f, 0.6f, 0.5f),
            onTertiary = Color.White,
            tertiaryContainer = tone(h + 60f, 0.2f, 1f),
            onTertiaryContainer = tone(h + 60f, 0.9f, 0.25f),
            background = tone(h, 0.05f, 0.99f),
            onBackground = tone(h, 0.3f, 0.12f),
            surface = tone(h, 0.05f, 0.99f),
            onSurface = tone(h, 0.3f, 0.12f),
            surfaceVariant = tone(h, 0.1f, 0.91f),
            onSurfaceVariant = tone(h, 0.2f, 0.33f),
            outline = tone(h, 0.15f, 0.5f),
            outlineVariant = tone(h, 0.1f, 0.8f),
            inversePrimary = tone(h, 0.4f, 1f),
            surfaceDim = tone(h, 0.08f, 0.87f),
            surfaceBright = tone(h, 0.05f, 0.99f),
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = tone(h, 0.05f, 0.97f),
            surfaceContainer = tone(h, 0.07f, 0.95f),
            surfaceContainerHigh = tone(h, 0.08f, 0.93f),
            surfaceContainerHighest = tone(h, 0.09f, 0.91f),
        )
    }
}

/** Soft blobs of color behind the whole app, so the glass cards have something to frost. */
internal fun Modifier.auroraBackground(
    base: Color,
    first: Color,
    second: Color,
    third: Color,
    strength: Float,
): Modifier = this.drawBehind {
    drawRect(color = base)
    val radius = size.maxDimension * 0.75f
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(first.copy(alpha = 0.40f * strength), Color.Transparent),
            center = Offset(size.width * 0.05f, size.height * 0.05f),
            radius = radius,
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(second.copy(alpha = 0.32f * strength), Color.Transparent),
            center = Offset(size.width * 0.95f, size.height * 0.55f),
            radius = radius,
        ),
    )
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(third.copy(alpha = 0.26f * strength), Color.Transparent),
            center = Offset(size.width * 0.2f, size.height * 0.98f),
            radius = radius,
        ),
    )
}

/** Reads an image from [uri], shrunk so that its longest side is at most [maxSide] pixels. */
fun decodeScaledBitmap(context: Context, uri: android.net.Uri, maxSide: Int): android.graphics.Bitmap? {
    val resolver = context.contentResolver
    val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
    resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
    val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
    return resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
}

/** The saved background photo, loaded off the main thread. Reloads when [version] changes. */
@Composable
fun rememberBackgroundPhoto(version: Int): androidx.compose.ui.graphics.ImageBitmap? {
    val context = LocalContext.current
    val photo = androidx.compose.runtime.produceState<androidx.compose.ui.graphics.ImageBitmap?>(
        initialValue = null,
        key1 = version,
    ) {
        value = if (version <= 0) {
            null
        } else {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    val file = java.io.File(context.filesDir, BACKGROUND_FILE)
                    android.graphics.BitmapFactory.decodeFile(file.path)?.asImageBitmap()
                }.getOrNull()
            }
        }
    }
    return photo.value
}
