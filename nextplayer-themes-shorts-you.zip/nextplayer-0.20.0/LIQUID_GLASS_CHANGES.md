# Liquid glass added (AndroidLiquidGlass / Backdrop 2.0.1)

Real glass = the video (or app background) behind a control is blurred, bent at the edges like a lens, and lit with a bright rim. Needs Android 12+; older phones keep the painted glass look.

Player
- Every glass control (buttons, seekbar track + thumb, capture buttons, seek/zoom/info pills, D-pad indicator) now looks through the video. Press a button and it swells like a drop of liquid. The seekbar thumb grows into a glass bubble while held.
- Menus (audio, subtitles, speed, playlist, chapters, decoder, scale) are big glass sheets over the video.
- Video is shown on a TextureView while real glass is on (a SurfaceView cannot be bent). Frame capture was updated to read from it.

App
- Bottom bar and the round + button are glass over the colorful background and the screen scrolling under them.
- All switches are iOS style liquid switches; preference sliders are liquid sliders.
- Settings > Appearance > Glass style: new "Real liquid glass" switch and a live preview with shapes behind the bubbles.

Files: core/ui/glass/LiquidGlass.kt (engine), core/ui/components/LiquidSwitch.kt, LiquidSlider.kt, plus edits in the player, theme, MainActivity and navigation.

## Round 9 (captures next to the video)
- Screen captures now get the date of the video (date taken, else last changed, else date added) + 1 s, written to MediaStore DATE_TAKEN/DATE_MODIFIED and to the picture's EXIF date, so the Gallery shows them beside the video like Samsung Video Player. Switch: Settings > Player > Extra features > Captures next to the video.

## Round 10 (themes, photo background, Shorts, You)
- Settings > Appearance > App Theme: Adaptive / Light / Dark cards and the Classic Themes colour grid (light swatches = light mode, two-tone swatches = dark mode, grey = neutral).
- Settings > Appearance > Background: pick your own photo for the whole app, with dimming and blur sliders (photo is copied into app storage; turns the glass look on).
- New bottom bar: Home, Shorts, Network, You. Playlists moved into You (still the same screen).
- Shorts: vertical swipe feed of vertical videos (up to 3 min) and, optionally, normal videos up to 1 min. Tap to pause, like, mute, open in the normal player, auto-next. Uses its own small player; the main video player is not touched.
- You: profile photo + name, stats (videos / watched / liked shorts), shortcuts to Playlists, Themes & background, Vault, Pick file, Trash, History. Settings button stays on the round + button.
