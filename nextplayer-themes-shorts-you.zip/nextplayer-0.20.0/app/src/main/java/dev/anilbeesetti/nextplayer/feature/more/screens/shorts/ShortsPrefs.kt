package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf

/** Small saved settings for the Shorts tab (kept apart from the main player settings). */
class ShortsPrefs private constructor(private val prefs: SharedPreferences) {
    var autoNext by mutableStateOf(prefs.getBoolean(KEY_AUTO_NEXT, false))
        private set
    var includeNormal by mutableStateOf(prefs.getBoolean(KEY_INCLUDE_NORMAL, false))
        private set
    var startMuted by mutableStateOf(prefs.getBoolean(KEY_MUTED, false))
        private set

    val liked = mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet(KEY_LIKED, emptySet()).orEmpty())
    }

    fun updateAutoNext(value: Boolean) {
        autoNext = value
        prefs.edit().putBoolean(KEY_AUTO_NEXT, value).apply()
    }

    fun updateIncludeNormal(value: Boolean) {
        includeNormal = value
        prefs.edit().putBoolean(KEY_INCLUDE_NORMAL, value).apply()
    }

    fun updateStartMuted(value: Boolean) {
        startMuted = value
        prefs.edit().putBoolean(KEY_MUTED, value).apply()
    }

    fun toggleLike(uri: String) {
        if (!liked.remove(uri)) liked.add(uri)
        prefs.edit().putStringSet(KEY_LIKED, liked.toSet()).apply()
    }

    companion object {
        private const val KEY_AUTO_NEXT = "auto_next"
        private const val KEY_INCLUDE_NORMAL = "include_normal"
        private const val KEY_MUTED = "muted"
        private const val KEY_LIKED = "liked"

        @Volatile
        private var instance: ShortsPrefs? = null

        fun get(context: Context): ShortsPrefs = instance ?: synchronized(this) {
            instance ?: ShortsPrefs(
                context.applicationContext.getSharedPreferences("shorts_prefs", Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}
