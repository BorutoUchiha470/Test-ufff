package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.annotation.OptIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import dev.anilbeesetti.nextplayer.core.model.Video
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.LocalNavigationBottomPadding
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.shorts.ShortsPrefs
import kotlinx.coroutines.delay

private val lovedRed = Color(0xFFFF3B55)
private val progressBlue = Color(0xFFA9B8FF)

/** Full-screen vertical feed of short / vertical videos, laid out like a short-video app. */
@Composable
fun ShortsScreen(viewModel: ShortsViewModel, onOpenInPlayer: (String) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { ShortsPrefs.get(context) }
    val allVideos by viewModel.videos.collectAsStateWithLifecycle()
    val shorts = remember(
        allVideos,
        prefs.includeNormal,
        prefs.maxHorizontalSeconds,
        prefs.shuffle,
        prefs.blocked.size,
    ) {
        allVideos.orEmpty().filterShorts(
            includeNormal = prefs.includeNormal,
            maxHorizontalSeconds = prefs.maxHorizontalSeconds,
            blocked = prefs.blocked.toSet(),
            shuffle = prefs.shuffle,
        )
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when {
            allVideos == null -> Unit
            shorts.isEmpty() -> EmptyShorts()
            else -> ShortsPager(shorts, prefs, onOpenInPlayer, onBack)
        }
    }
}

@Composable
private fun EmptyShorts() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(NextIcons.Shorts, null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.shorts_empty_title), color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text(
            stringResource(R.string.shorts_empty_desc),
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun ShortsPager(
    videos: List<Video>,
    prefs: ShortsPrefs,
    onOpenInPlayer: (String) -> Unit,
    onBack: () -> Unit,
) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(pageCount = { videos.size })
    val player = remember {
        ExoPlayer.Builder(context).build().apply { repeatMode = Player.REPEAT_MODE_ONE }
    }
    val exoPlayer = player
    var muted by remember { mutableStateOf(prefs.startMuted) }
    var free by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var showMore by remember { mutableStateOf(false) }
    val ended = remember { mutableStateOf(false) }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) player.pause()
            if (event == Lifecycle.Event.ON_RESUME && !paused) player.play()
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            player.release()
        }
    }

    // Load whichever short is on screen. Keyed on the video itself so blocking one moves on to the next.
    val currentUri = videos.getOrNull(pagerState.settledPage)?.uriString
    LaunchedEffect(currentUri, prefs.autoNext) {
        val uri = currentUri ?: return@LaunchedEffect
        player.setMediaItem(MediaItem.fromUri(uri.toUri()))
        player.repeatMode = if (prefs.autoNext) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
        player.prepare()
        paused = false
        player.play()
    }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && prefs.autoNext) ended.value = true
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(ended.value) {
        if (ended.value) {
            ended.value = false
            val next = pagerState.currentPage + 1
            if (next < videos.size) pagerState.animateScrollToPage(next)
        }
    }

    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            progress = if (d > 0) (player.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(200)
        }
    }

    val bottomPad = LocalNavigationBottomPadding.current

    VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 0) { page ->
        val video = videos[page]
        val isCurrent = page == pagerState.settledPage
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                    paused = !paused
                    if (paused) player.pause() else player.play()
                },
        ) {
            if (isCurrent) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            setShutterBackgroundColor(android.graphics.Color.BLACK)
                            this.player = exoPlayer
                        }
                    },
                    update = {
                        it.resizeMode = if (free) {
                            AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        } else {
                            AspectRatioFrameLayout.RESIZE_MODE_FIT
                        }
                    },
                )
                if (paused) {
                    Icon(
                        NextIcons.Play, null, tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.align(Alignment.Center).size(72.dp),
                    )
                }
            }

            // Soft shade so the text stays readable on bright videos.
            Box(
                modifier = Modifier.fillMaxWidth().height(260.dp).align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f)))),
            )

            // Right side: Love / Block / Free / Back / More
            val loved = video.uriString in prefs.liked
            Column(
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = bottomPad + 40.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                SideButton(
                    icon = if (loved) NextIcons.Favorite else NextIcons.FavoriteBorder,
                    label = stringResource(if (loved) R.string.short_loved else R.string.short_love),
                    tint = if (loved) lovedRed else Color.White,
                    glass = prefs.glassControls,
                ) { prefs.toggleLike(video.uriString) }
                SideButton(NextIcons.Block, stringResource(R.string.short_block), glass = prefs.glassControls) {
                    prefs.block(video.uriString)
                }
                SideButton(
                    icon = if (free) NextIcons.FullscreenExit else NextIcons.Fullscreen,
                    label = stringResource(R.string.short_free),
                    glass = prefs.glassControls,
                ) { free = !free }
                if (prefs.showBack) {
                    SideButton(NextIcons.ArrowBack, stringResource(R.string.short_back), glass = prefs.glassControls) {
                        player.pause()
                        onBack()
                    }
                }
                SideButton(NextIcons.MoreVert, stringResource(R.string.short_more), glass = prefs.glassControls) {
                    showMore = true
                }
            }

            // Bottom left: file name and info chips
            Column(
                modifier = Modifier.align(Alignment.BottomStart)
                    .padding(start = 14.dp, end = 86.dp, bottom = bottomPad + 46.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = video.nameWithExtension,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val quality = minOf(video.width, video.height)
                    if (quality > 0) InfoChip("${quality}p")
                    if (video.formattedFileSize.isNotBlank()) InfoChip(video.formattedFileSize)
                }
            }

            if (isCurrent) {
                SegmentedProgress(
                    progress = progress,
                    onSeek = { fraction ->
                        val d = player.duration
                        if (d > 0) player.seekTo((d * fraction).toLong())
                    },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomPad + 8.dp),
                )
            }
        }
    }

    if (showMore) {
        MoreSheet(
            prefs = prefs,
            muted = muted,
            onMutedChange = { muted = it },
            onOpenPlayer = {
                showMore = false
                videos.getOrNull(pagerState.settledPage)?.let {
                    player.pause()
                    onOpenInPlayer(it.uriString)
                }
            },
            onDismiss = { showMore = false },
        )
    }
}

@Composable
private fun SideButton(
    icon: ImageVector,
    label: String,
    glass: Boolean,
    tint: Color = Color.White,
    onClick: () -> Unit,
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(if (glass) Color.White.copy(alpha = 0.16f) else Color.Black.copy(alpha = 0.45f))
                .then(if (glass) Modifier.border(BorderStroke(1.dp, Color.White.copy(alpha = 0.28f)), CircleShape) else Modifier)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(24.dp))
        }
        Text(label, color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun InfoChip(text: String) {
    Text(
        text = text,
        color = Color.White,
        fontSize = 11.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
    )
}

/** Thin two-part bar: played part (blue) and the rest (grey), with a tiny gap. Tap or drag to seek. */
@Composable
private fun SegmentedProgress(progress: Float, onSeek: (Float) -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .height(28.dp),
        contentAlignment = Alignment.Center,
    ) {
        val widthPx = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(widthPx) { detectTapGestures { onSeek((it.x / widthPx).coerceIn(0f, 1f)) } }
                .pointerInput(widthPx) {
                    detectHorizontalDragGestures { change, _ -> onSeek((change.position.x / widthPx).coerceIn(0f, 1f)) }
                },
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            val played = progress.coerceIn(0.001f, 0.999f)
            Box(Modifier.weight(played).height(3.dp).clip(CircleShape).background(progressBlue))
            Box(Modifier.weight(1f - played).height(3.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MoreSheet(
    prefs: ShortsPrefs,
    muted: Boolean,
    onMutedChange: (Boolean) -> Unit,
    onOpenPlayer: () -> Unit,
    onDismiss: () -> Unit,
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SheetSwitch(R.string.shorts_auto_next, R.string.shorts_auto_next_desc, prefs.autoNext, prefs::updateAutoNext)
            SheetSwitch(R.string.shorts_include_normal, R.string.shorts_include_normal_desc, prefs.includeNormal, prefs::updateIncludeNormal)
            SheetSwitch(R.string.shorts_muted, null, muted, onMutedChange)
            TextButton(onClick = onOpenPlayer, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.shorts_open_player))
            }
        }
    }
}

@Composable
private fun SheetSwitch(title: Int, desc: Int?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(stringResource(title), style = MaterialTheme.typography.bodyLarge)
            if (desc != null) {
                Text(
                    stringResource(desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
