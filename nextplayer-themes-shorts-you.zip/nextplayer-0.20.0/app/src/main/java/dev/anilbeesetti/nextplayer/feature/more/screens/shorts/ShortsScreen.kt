package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import dev.anilbeesetti.nextplayer.core.model.Video
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.LocalNavigationBottomPadding
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import kotlinx.coroutines.delay

/** Full-screen vertical feed of short / vertical videos from the phone. One small player is reused for all pages. */
@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
fun ShortsScreen(viewModel: ShortsViewModel, onOpenInPlayer: (String) -> Unit) {
    val context = LocalContext.current
    val prefs = remember { ShortsPrefs.get(context) }
    val allVideos by viewModel.videos.collectAsStateWithLifecycle()
    val shorts = remember(allVideos, prefs.includeNormal) {
        allVideos.orEmpty().filterShorts(includeNormal = prefs.includeNormal)
    }
    var showSettings by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        when {
            allVideos == null -> Unit
            shorts.isEmpty() -> EmptyShorts()
            else -> ShortsPager(shorts, prefs, onOpenInPlayer)
        }

        Row(
            modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.shorts),
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            RoundIcon(NextIcons.Settings, stringResource(R.string.shorts_settings)) { showSettings = true }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text(stringResource(R.string.shorts_settings)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SettingRow(R.string.shorts_auto_next, R.string.shorts_auto_next_desc, prefs.autoNext, prefs::updateAutoNext)
                    SettingRow(R.string.shorts_include_normal, R.string.shorts_include_normal_desc, prefs.includeNormal, prefs::updateIncludeNormal)
                    SettingRow(R.string.shorts_muted, null, prefs.startMuted, prefs::updateStartMuted)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text(stringResource(R.string.done)) } },
        )
    }
}

@Composable
private fun SettingRow(title: Int, desc: Int?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(stringResource(title), style = MaterialTheme.typography.bodyLarge)
            if (desc != null) {
                Text(
                    stringResource(desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun EmptyShorts() {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(NextIcons.Shorts, null, tint = Color.White.copy(alpha = 0.7f), modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.shorts_empty_title), color = Color.White, style = MaterialTheme.typography.titleMedium)
        Text(
            stringResource(R.string.shorts_empty_desc),
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.bodyMedium,
        )
    }
}

@OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
private fun ShortsPager(videos: List<Video>, prefs: ShortsPrefs, onOpenInPlayer: (String) -> Unit) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(pageCount = { videos.size })
    val player = remember {
        ExoPlayer.Builder(context).build().apply { repeatMode = Player.REPEAT_MODE_ONE }
    }
    var muted by remember { mutableStateOf(prefs.startMuted) }
    var progress by remember { mutableFloatStateOf(0f) }
    var paused by remember { mutableStateOf(false) }
    val ended = remember { mutableStateOf(false) }
    val exoPlayer = player

    // Release with the screen, and pause while the app is in the background.
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) player.pause()
            if (event == Lifecycle.Event.ON_RESUME && !paused) player.play()
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            player.release()
        }
    }

    // Load whichever short is on screen.
    LaunchedEffect(pagerState.settledPage, videos) {
        val video = videos.getOrNull(pagerState.settledPage) ?: return@LaunchedEffect
        player.setMediaItem(MediaItem.fromUri(video.uriString.toUri()))
        player.repeatMode = if (prefs.autoNext) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
        player.prepare()
        paused = false
        player.play()
    }
    LaunchedEffect(muted) { player.volume = if (muted) 0f else 1f }

    // Auto swipe to next short when one ends.
    DisposableEffect(player, prefs.autoNext) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && prefs.autoNext) {
                    ended.value = true
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(ended.value) {
        if (ended.value) {
            ended.value = false
            val next = pagerState.currentPage + 1
            if (next < videos.size) pagerState.animateScrollToPage(next)
        }
    }

    // Thin progress line along the bottom.
    LaunchedEffect(player) {
        while (true) {
            val d = player.duration
            progress = if (d > 0) (player.currentPosition.toFloat() / d).coerceIn(0f, 1f) else 0f
            delay(250)
        }
    }

    VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize(), beyondViewportPageCount = 0) { page ->
        val video = videos[page]
        val isCurrent = page == pagerState.settledPage
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    indication = null,
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                ) {
                    paused = !paused
                    if (paused) player.pause() else player.play()
                },
        ) {
            if (isCurrent) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShutterBackgroundColor(android.graphics.Color.BLACK)
                            this.player = exoPlayer
                        }
                    },
                    update = { it.player = exoPlayer },
                )
            }
            if (paused && isCurrent) {
                Icon(
                    NextIcons.Play, null, tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.align(Alignment.Center).size(72.dp),
                )
            }

            Box(
                modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).height(220.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f)))),
            )

            val liked = video.uriString in prefs.liked
            Column(
                modifier = Modifier.align(Alignment.BottomEnd)
                    .padding(end = 12.dp, bottom = LocalNavigationBottomPadding.current + 90.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                RoundIcon(
                    icon = if (liked) NextIcons.Favorite else NextIcons.FavoriteBorder,
                    description = stringResource(R.string.shorts_like),
                    tint = if (liked) Color(0xFFFF4F6D) else Color.White,
                ) { prefs.toggleLike(video.uriString) }
                RoundIcon(
                    icon = if (muted) NextIcons.VolumeOff else NextIcons.VolumeUp,
                    description = null,
                ) { muted = !muted }
                RoundIcon(NextIcons.Play, stringResource(R.string.shorts_open_player)) {
                    player.pause()
                    onOpenInPlayer(video.uriString)
                }
            }

            Column(
                modifier = Modifier.align(Alignment.BottomStart)
                    .padding(start = 16.dp, end = 84.dp, bottom = LocalNavigationBottomPadding.current + 96.dp),
            ) {
                Text(
                    text = video.displayName,
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = video.formattedDuration,
                    color = Color.White.copy(alpha = 0.75f),
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            if (isCurrent) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter)
                        .padding(bottom = LocalNavigationBottomPadding.current + 80.dp).height(2.dp),
                    color = Color.White,
                    trackColor = Color.White.copy(alpha = 0.25f),
                )
            }
        }
    }
}

@Composable
private fun RoundIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String?,
    tint: Color = Color.White,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier.size(46.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, description, tint = tint, modifier = Modifier.size(24.dp))
    }
}
