package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable
import org.koin.compose.viewmodel.koinViewModel

@Serializable
object ShortsRoute : NavKey

fun EntryProviderScope<NavKey>.shortsEntry(onPlayVideo: (String) -> Unit, onBack: () -> Unit) {
    entry<ShortsRoute> {
        ShortsScreen(
            viewModel = koinViewModel<ShortsViewModel>(),
            onOpenInPlayer = onPlayVideo,
            onBack = onBack,
        )
    }
}
