package dev.anilbeesetti.nextplayer.navigation

import android.content.Context
import androidx.core.net.toUri
import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavKey
import dev.anilbeesetti.nextplayer.feature.more.screens.shorts.shortsEntry

fun EntryProviderScope<NavKey>.shortsNavGraph(context: Context) {
    shortsEntry(onPlayVideo = { context.startPlayback(it.toUri()) })
}
