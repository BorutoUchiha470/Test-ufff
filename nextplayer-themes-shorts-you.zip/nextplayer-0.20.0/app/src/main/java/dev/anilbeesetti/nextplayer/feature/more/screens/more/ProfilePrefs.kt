package dev.anilbeesetti.nextplayer.feature.more.screens.more

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import dev.anilbeesetti.nextplayer.core.ui.theme.decodeScaledBitmap
import java.io.File

/** The name and profile photo shown on the You tab. Stored on the phone only. */
class ProfilePrefs private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("profile", Context.MODE_PRIVATE)

    var name by mutableStateOf(prefs.getString("name", "").orEmpty())
        private set
    var avatarVersion by mutableIntStateOf(prefs.getInt("avatar_version", 0))
        private set

    val avatarFile: File get() = File(context.filesDir, "profile_avatar.jpg")

    fun updateName(value: String) {
        name = value.trim()
        prefs.edit().putString("name", name).apply()
    }

    fun setAvatar(uri: Uri): Boolean {
        val ok = runCatching {
            val bitmap = decodeScaledBitmap(context, uri, maxSide = 512) ?: return false
            avatarFile.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            true
        }.getOrDefault(false)
        if (ok) {
            avatarVersion += 1
            prefs.edit().putInt("avatar_version", avatarVersion).apply()
        }
        return ok
    }

    companion object {
        @Volatile
        private var instance: ProfilePrefs? = null

        fun get(context: Context): ProfilePrefs = instance ?: synchronized(this) {
            instance ?: ProfilePrefs(context.applicationContext).also { instance = it }
        }
    }
}
