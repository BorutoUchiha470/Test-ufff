package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dev.anilbeesetti.nextplayer.core.data.repository.MediaRepository
import dev.anilbeesetti.nextplayer.core.model.Video
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import org.koin.core.annotation.KoinViewModel

/** Every video on the phone; the screen decides which of them count as "shorts". */
@KoinViewModel
class ShortsViewModel(mediaRepository: MediaRepository) : ViewModel() {

    private val videosInternal = MutableStateFlow<List<Video>?>(null)
    val videos: StateFlow<List<Video>?> = videosInternal.asStateFlow()

    init {
        viewModelScope.launch {
            mediaRepository.observeVideos()
                .catch { videosInternal.value = emptyList() }
                .collect { videosInternal.value = it }
        }
    }
}

/** Vertical videos, and (optionally) normal videos up to [maxHorizontalSeconds]. Blocked ones are left out. */
fun List<Video>.filterShorts(
    includeNormal: Boolean,
    maxHorizontalSeconds: Int,
    blocked: Collection<String>,
    shuffle: Boolean,
): List<Video> {
    val maxNormalMs = maxHorizontalSeconds * 1000L
    val list = filter { video ->
        val vertical = video.height > video.width && video.duration in 1..MAX_VERTICAL_MS
        val shortNormal = includeNormal && video.duration in 1..maxNormalMs
        (vertical || shortNormal) && video.uriString !in blocked
    }
    return if (shuffle) list.shuffled() else list.sortedByDescending { it.dateAdded }
}

private const val MAX_VERTICAL_MS = 3 * 60 * 1000L
