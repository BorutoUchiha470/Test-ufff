package dev.anilbeesetti.nextplayer.feature.more.screens.more

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons
import dev.anilbeesetti.nextplayer.core.ui.theme.LocalGlassCardColor
import dev.anilbeesetti.nextplayer.feature.more.screens.shorts.ShortsPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Profile card (photo + name) and a row of three stats, shown at the top of the You tab. */
@Composable
internal fun YouHeader(videoCount: Int, watchedCount: Int) {
    val context = LocalContext.current
    val profile = remember { ProfilePrefs.get(context) }
    val shorts = remember { ShortsPrefs.get(context) }
    val scope = rememberCoroutineScope()
    var editName by remember { mutableStateOf(false) }

    val avatar by produceState<ImageBitmap?>(null, profile.avatarVersion) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (profile.avatarFile.exists()) {
                    android.graphics.BitmapFactory.decodeFile(profile.avatarFile.path)?.asImageBitmap()
                } else {
                    null
                }
            }.getOrNull()
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch { withContext(Dispatchers.IO) { profile.setAvatar(uri) } }
    }
    val cardColor = LocalGlassCardColor.current ?: MaterialTheme.colorScheme.surfaceContainerHigh

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cardColor).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                contentAlignment = Alignment.Center,
            ) {
                val bmp = avatar
                if (bmp != null) {
                    Image(bmp, stringResource(R.string.you_change_photo), contentScale = ContentScale.Crop, modifier = Modifier.size(72.dp))
                } else {
                    Icon(NextIcons.Person, stringResource(R.string.you_change_photo), modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
            Column(modifier = Modifier.weight(1f).clickable { editName = true }) {
                Text(
                    text = profile.name.ifBlank { stringResource(R.string.you_name_default) },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    text = stringResource(R.string.you_edit_name),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(videoCount.toString(), stringResource(R.string.you_videos), cardColor, Modifier.weight(1f))
            StatCard(watchedCount.toString(), stringResource(R.string.you_watched), cardColor, Modifier.weight(1f))
            StatCard(shorts.liked.size.toString(), stringResource(R.string.you_liked), cardColor, Modifier.weight(1f))
        }
    }

    if (editName) {
        var text by remember { mutableStateOf(profile.name) }
        AlertDialog(
            onDismissRequest = { editName = false },
            title = { Text(stringResource(R.string.you_edit_name)) },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(40) }, singleLine = true) },
            confirmButton = {
                TextButton(onClick = { profile.updateName(text); editName = false }) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                TextButton(onClick = { editName = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun StatCard(value: String, label: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(
        modifier = modifier.clip(RoundedCornerShape(18.dp)).background(color).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
