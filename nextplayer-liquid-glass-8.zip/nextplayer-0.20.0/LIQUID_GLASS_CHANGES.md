# Liquid glass added (AndroidLiquidGlass / Backdrop 2.0.1)

Real glass = the video (or app background) behind a control is blurred, bent at the edges like a lens, and lit with a bright rim. Needs Android 12+; older phones keep the painted glass look.

Player
- Every glass control (buttons, seekbar track + thumb, capture buttons, seek/zoom/info pills, D-pad indicator) now looks through the video. Press a button and it swells like a drop of liquid. The seekbar thumb grows into a glass bubble while held.
- Menus (audio, subtitles, speed, playlist, chapters, decoder, scale) are big glass sheets over the video.
- Video is shown on a TextureView while real glass is on (a SurfaceView cannot be bent). Frame capture was updated to read from it.

App
- Bottom bar and the round + button are glass over the colorful background and the screen scrolling under them.
- All switches are iOS style liquid switches; preference sliders are liquid sliders.
- Settings > Appearance > Glass style: new "Real liquid glass" switch and a live preview with shapes behind the bubbles.

Files: core/ui/glass/LiquidGlass.kt (engine), core/ui/components/LiquidSwitch.kt, LiquidSlider.kt, plus edits in the player, theme, MainActivity and navigation.

## Round 8 (glass over video without the TextureView)
- The video now always stays on the SurfaceView (zero-copy). Glass over video uses VideoSnapshotBackdrop: a custom Backdrop that draws a small PixelCopy picture of the video, renewed every 500 ms while the controls are visible. Only the video enhancer still needs a TextureView.
- Ambient glow samples a 32 px copy every 1.5 s (PixelCopy) and fades colours over 450 ms (was almost continuous animation).
- Seeking: bigger forward buffer (120 s), 60 s back buffer, start after 100 ms, time prioritised over size. Seek-preview loads fewer, smaller frames, and the loading circle waits 1 s.
- Control fades are 120 ms.
