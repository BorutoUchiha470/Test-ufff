package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import dev.anilbeesetti.nextplayer.core.ui.extras.isModernPlayerIcons
import dev.anilbeesetti.nextplayer.core.ui.extras.playerIconPainter
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.NextSwitch
import dev.anilbeesetti.nextplayer.core.ui.extras.DEFAULT_CAPTURE_PREVIEW_WIDTH
import dev.anilbeesetti.nextplayer.core.ui.extras.LocalExtraFeatures
import dev.anilbeesetti.nextplayer.core.ui.glass.LocalGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.feature.player.utils.CapturedFrame
import dev.anilbeesetti.nextplayer.feature.player.utils.saveCurrentFrame
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val PREFS_NAME = "capture_button"
private const val KEY_X = "x"
private const val KEY_Y = "y"
private const val KEY_SIZE = "size"
private const val DEFAULT_RIGHT_X = 0.92f
private const val DEFAULT_LEFT_X = 0.08f
private const val DEFAULT_Y = 0.55f
private const val DEFAULT_SIZE_DP = 52f
private const val MIN_SIZE_DP = 32f
private const val MAX_SIZE_DP = 110f
private const val PREVIEW_SHOWN_MS = 2_500L

/** Saved position, size and visibility of one floating button. */
private class ButtonConfig(
    private val prefs: SharedPreferences,
    private val name: String,
    private val defaultX: Float,
    useLegacyKeys: Boolean,
) {
    // Position is stored as a fraction of the free space, so it also fits after rotating the phone.
    val x = mutableFloatStateOf(
        prefs.getFloat("${name}_x", if (useLegacyKeys) prefs.getFloat(KEY_X, defaultX) else defaultX),
    )
    val y = mutableFloatStateOf(
        prefs.getFloat("${name}_y", if (useLegacyKeys) prefs.getFloat(KEY_Y, DEFAULT_Y) else DEFAULT_Y),
    )
    val size = mutableFloatStateOf(
        prefs.getFloat("${name}_size", if (useLegacyKeys) prefs.getFloat(KEY_SIZE, DEFAULT_SIZE_DP) else DEFAULT_SIZE_DP),
    )
    val visible = mutableStateOf(prefs.getBoolean("${name}_visible", true))

    fun save() {
        prefs.edit()
            .putFloat("${name}_x", x.floatValue)
            .putFloat("${name}_y", y.floatValue)
            .putFloat("${name}_size", size.floatValue)
            .putBoolean("${name}_visible", visible.value)
            .apply()
    }

    fun reset() {
        x.floatValue = defaultX
        y.floatValue = DEFAULT_Y
        size.floatValue = DEFAULT_SIZE_DP
        save()
    }
}

/**
 * Two floating screen-capture buttons (left and right side).
 * Tap: save the current frame. Drag: move it anywhere. Long-press: resize, reset or hide/show sides.
 */
@Composable
fun CaptureButtons(
    player: Player?,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val prefs = remember { context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE) }
    val left = remember { ButtonConfig(prefs, "left", DEFAULT_LEFT_X, useLegacyKeys = false) }
    val right = remember { ButtonConfig(prefs, "right", DEFAULT_RIGHT_X, useLegacyKeys = true) }
    var editing by remember { mutableStateOf<ButtonConfig?>(null) }
    var preview by remember { mutableStateOf<CapturedFrame?>(null) }
    // Size of the little picture after a capture. Settings > Player > Screen capture preview size.
    val captureWidthFraction = (LocalExtraFeatures.current?.capturePreviewWidth ?: DEFAULT_CAPTURE_PREVIEW_WIDTH)
        .coerceIn(0.08f, 0.5f)

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        if (left.visible.value) {
            CaptureCircle(
                config = left,
                widthPx = widthPx,
                heightPx = heightPx,
                player = player,
                onCaptured = { preview = it },
                onLongPress = { editing = left },
            )
        }
        if (right.visible.value) {
            CaptureCircle(
                config = right,
                widthPx = widthPx,
                heightPx = heightPx,
                player = player,
                onCaptured = { preview = it },
                onLongPress = { editing = right },
            )
        }
        CapturePreview(
            frame = preview,
            onHide = { preview = null },
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = maxWidth * 0.14f, bottom = maxHeight * 0.30f),
            width = maxWidth * captureWidthFraction,
        )
    }

    editing?.let { config ->
        AlertDialog(
            onDismissRequest = {
                config.save()
                editing = null
            },
            title = { Text(text = stringResource(R.string.capture_frame)) },
            text = {
                Column {
                    Text(text = stringResource(R.string.capture_button_hint))
                    Text(text = stringResource(R.string.size))
                    Slider(
                        value = config.size.floatValue,
                        onValueChange = { config.size.floatValue = it },
                        onValueChangeFinished = { config.save() },
                        valueRange = MIN_SIZE_DP..MAX_SIZE_DP,
                    )
                    // At least one side always stays on, so the button can never disappear completely.
                    SideSwitch(
                        label = stringResource(R.string.capture_left_button),
                        checked = left.visible.value,
                        onCheckedChange = { on ->
                            if (on || right.visible.value) {
                                left.visible.value = on
                                left.save()
                            }
                        },
                    )
                    SideSwitch(
                        label = stringResource(R.string.capture_right_button),
                        checked = right.visible.value,
                        onCheckedChange = { on ->
                            if (on || left.visible.value) {
                                right.visible.value = on
                                right.save()
                            }
                        },
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        config.save()
                        editing = null
                    },
                ) {
                    Text(text = stringResource(R.string.done))
                }
            },
            dismissButton = {
                TextButton(onClick = { config.reset() }) {
                    Text(text = stringResource(R.string.reset))
                }
            },
        )
    }
}

@Composable
private fun SideSwitch(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(text = label)
        NextSwitch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun CaptureCircle(
    config: ButtonConfig,
    widthPx: Float,
    heightPx: Float,
    player: Player?,
    onCaptured: (CapturedFrame) -> Unit,
    onLongPress: () -> Unit,
) {
    val context = LocalContext.current
    val view = LocalView.current
    val glass = LocalGlassSettings.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    val sizePx = with(density) { config.size.floatValue.dp.toPx() }
    val maxX = (widthPx - sizePx).coerceAtLeast(0f)
    val maxY = (heightPx - sizePx).coerceAtLeast(0f)
    val offsetX = config.x.floatValue.coerceIn(0f, 1f) * maxX
    val offsetY = config.y.floatValue.coerceIn(0f, 1f) * maxY

    Box(
        modifier = Modifier
            .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
            .size(config.size.floatValue.dp)
            .then(
                if (isModernPlayerIcons()) {
                    // Modern: just the icon, no bubble behind it.
                    Modifier.clip(CircleShape)
                } else if (glass != null && glass.enabled) {
                    Modifier.glassSurface(settings = glass)
                } else {
                    Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                },
            )
            .pointerInput(player) {
                detectTapGestures(
                    onTap = {
                        scope.launch {
                            val captured = runCatching { saveCurrentFrame(context, view, player) }
                                .getOrNull()
                            if (captured != null) {
                                // Like Samsung Video Player: a small picture of the capture, no text.
                                onCaptured(captured)
                            } else {
                                Toast.makeText(context, R.string.frame_capture_failed, Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onLongPress = { onLongPress() },
                )
            }
            .pointerInput(maxX, maxY) {
                detectDragGestures(
                    onDragEnd = { config.save() },
                    onDragCancel = { config.save() },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        if (maxX > 0f) {
                            config.x.floatValue =
                                ((config.x.floatValue * maxX + dragAmount.x) / maxX).coerceIn(0f, 1f)
                        }
                        if (maxY > 0f) {
                            config.y.floatValue =
                                ((config.y.floatValue * maxY + dragAmount.y) / maxY).coerceIn(0f, 1f)
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = playerIconPainter(R.drawable.ic_capture),
            contentDescription = stringResource(R.string.capture_frame),
            tint = Color.White,
            modifier = Modifier.size((config.size.floatValue * 0.5f).dp),
        )
    }
}

/**
 * Small picture of the capture with a white border, shown above the seek bar for a moment
 * (like Samsung Video Player). Tap it to open the saved picture.
 */
@Composable
private fun CapturePreview(
    frame: CapturedFrame?,
    onHide: () -> Unit,
    width: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    // Keep the last picture while it fades out.
    var shown by remember { mutableStateOf<CapturedFrame?>(null) }
    if (frame != null) shown = frame

    LaunchedEffect(frame) {
        if (frame != null) {
            delay(PREVIEW_SHOWN_MS)
            onHide()
        }
    }

    AnimatedVisibility(
        visible = frame != null,
        modifier = modifier,
        enter = fadeIn() + scaleIn(initialScale = 0.85f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
    ) {
        shown?.let { current ->
            val shape = RoundedCornerShape(8.dp)
            Image(
                bitmap = current.thumbnail.asImageBitmap(),
                contentDescription = stringResource(R.string.capture_frame),
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .width(width)
                    .aspectRatio(current.thumbnail.width.toFloat() / current.thumbnail.height.coerceAtLeast(1))
                    .clip(shape)
                    .background(Color.Black)
                    .border(width = 2.dp, color = Color.White, shape = shape)
                    .clickable(enabled = current.uri.scheme == "content") {
                        runCatching {
                            context.startActivity(
                                Intent(Intent.ACTION_VIEW)
                                    .setDataAndType(current.uri, "image/jpeg")
                                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    },
            )
        }
    }
}
