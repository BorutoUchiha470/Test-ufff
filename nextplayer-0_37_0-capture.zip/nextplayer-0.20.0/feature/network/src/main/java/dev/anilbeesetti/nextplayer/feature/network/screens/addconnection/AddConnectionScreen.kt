package dev.anilbeesetti.nextplayer.feature.network.screens.addconnection

import dev.anilbeesetti.nextplayer.core.ui.theme.screenContainerColor
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.anilbeesetti.nextplayer.core.model.NetworkAuthentication
import dev.anilbeesetti.nextplayer.core.model.NetworkConnection
import dev.anilbeesetti.nextplayer.core.model.NetworkProtocol
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.components.NextDialog
import dev.anilbeesetti.nextplayer.core.ui.components.NextOutlinedTextField
import dev.anilbeesetti.nextplayer.core.ui.components.NextTopAppBar
import dev.anilbeesetti.nextplayer.core.ui.components.tvFocusRing
import dev.anilbeesetti.nextplayer.core.ui.designsystem.NextIcons

/**
 * Default path per protocol: SMB starts with an empty share name and also accepts `/` to browse
 * the server's shares, while FTP and WebDAV are rooted at "/".
 */
private fun defaultPathFor(protocol: NetworkProtocol): String =
    if (protocol == NetworkProtocol.SMB) "" else "/"

private fun normalizedPathFor(protocol: NetworkProtocol, path: String): String {
    val trimmed = path.trim()
    if (protocol == NetworkProtocol.SMB) return trimmed
    return trimmed.trim('/').let { if (it.isEmpty()) "/" else "/$it" }
}

internal fun fingerprintAfterEndpointEdit(
    protocol: NetworkProtocol,
    previousValue: String,
    newValue: String,
    fingerprint: String,
): String = if (protocol == NetworkProtocol.SFTP && previousValue != newValue) "" else fingerprint

@Composable
fun AddConnectionScreen(viewModel: AddConnectionViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    AddConnectionScreenContent(
        state = state,
        onAction = viewModel::onAction,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun AddConnectionScreenContent(
    state: AddConnectionUiState,
    onAction: (AddConnectionAction) -> Unit,
) {
    val isEdit = state.isEdit
    val existing = state.existingConnection
    val saveState = state.saveState
    val selectedPrivateKey = state.selectedPrivateKey
    val keyPicker =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { onAction(AddConnectionAction.StagePrivateKey(uri = it)) }
        }

    var protocol by rememberSaveable { mutableStateOf(NetworkProtocol.SMB) }
    var name by rememberSaveable { mutableStateOf(value = "") }
    var host by rememberSaveable { mutableStateOf(value = "") }
    var port by rememberSaveable { mutableStateOf(value = "") }
    var path by rememberSaveable { mutableStateOf(value = defaultPathFor(NetworkProtocol.SMB)) }
    var username by rememberSaveable { mutableStateOf(value = "") }
    var password by remember { mutableStateOf(value = "") }
    var useHttps by rememberSaveable { mutableStateOf(value = false) }
    var authentication by rememberSaveable { mutableStateOf(NetworkAuthentication.PASSWORD) }
    var privateKeyPassphrase by remember { mutableStateOf(value = "") }
    var hostKeyFingerprint by rememberSaveable { mutableStateOf(value = "") }
    var existingPrivateKeyRemoved by rememberSaveable { mutableStateOf(value = false) }

    val focusManager = LocalFocusManager.current

    // Prefill when editing an existing connection (fires once it loads).
    LaunchedEffect(key1 = existing) {
        existing?.let {
            protocol = it.protocol
            name = it.name
            host = it.host
            port = it.port?.toString() ?: ""
            path = normalizedPathFor(
                it.protocol,
                it.path,
            )
            username = it.username
            password = it.password
            useHttps = it.useHttps
            authentication = it.authentication
            privateKeyPassphrase = it.privateKeyPassphrase
            hostKeyFingerprint = it.hostKeyFingerprint
            existingPrivateKeyRemoved = false
        }
    }

    val isTesting = saveState is SaveState.Testing
    val storedPrivateKeyName = existing
        ?.privateKeyFileName
        .orEmpty()
        .takeUnless { existingPrivateKeyRemoved }
        .orEmpty()
    val activeKeyName = selectedPrivateKey?.stagedFileName ?: storedPrivateKeyName
    val canSave = canSaveConnection(
        name = name,
        host = host,
        protocol = protocol,
        username = username,
        authentication = authentication,
        hasPrivateKey = activeKeyName.isNotBlank(),
        isTesting = isTesting,
    )

    fun submit() {
        onAction(
            AddConnectionAction.TestAndSave(
                connection = NetworkConnection(
                    name = name.trim(),
                    protocol = protocol,
                    host = host.trim(),
                    port = port.toIntOrNull(),
                    path = normalizedPathFor(
                        protocol = protocol,
                        path = path,
                    ),
                    username = username.trim(),
                    password = if (
                        protocol == NetworkProtocol.SFTP &&
                        authentication == NetworkAuthentication.SSH_KEY
                    ) {
                        ""
                    } else {
                        password
                    },
                    useHttps = protocol == NetworkProtocol.WEBDAV && useHttps,
                    authentication = if (protocol == NetworkProtocol.SFTP) {
                        authentication
                    } else {
                        NetworkAuthentication.PASSWORD
                    },
                    privateKeyFileName = if (
                        protocol == NetworkProtocol.SFTP &&
                        authentication == NetworkAuthentication.SSH_KEY
                    ) {
                        activeKeyName
                    } else {
                        ""
                    },
                    privateKeyPassphrase = if (
                        protocol == NetworkProtocol.SFTP &&
                        authentication == NetworkAuthentication.SSH_KEY
                    ) {
                        privateKeyPassphrase
                    } else {
                        ""
                    },
                    hostKeyFingerprint = if (protocol == NetworkProtocol.SFTP) {
                        hostKeyFingerprint
                    } else {
                        ""
                    },
                ),
            ),
        )
    }

    val onChange: (() -> Unit) -> Unit = { setter ->
        setter()
        onAction(AddConnectionAction.ClearError)
    }

    Scaffold(
        topBar = {
            NextTopAppBar(
                title = stringResource(
                    id = if (isEdit) R.string.edit_connection else R.string.add_connection,
                ),
                navigationIcon = {
                    FilledTonalIconButton(
                        onClick = {
                            onAction(AddConnectionAction.Cancel)
                        },
                        modifier = Modifier.tvFocusRing(),
                    ) {
                        Icon(
                            imageVector = NextIcons.Close,
                            contentDescription = stringResource(R.string.navigate_up),
                        )
                    }
                },
            )
        },
        containerColor = screenContainerColor(),
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues = padding)
                .imePadding()
                .verticalScroll(state = rememberScrollState())
                .padding(
                    horizontal = 20.dp,
                    vertical = 12.dp,
                ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = stringResource(R.string.protocol),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                val protocols = listOf(
                    NetworkProtocol.SMB,
                    NetworkProtocol.FTP,
                    NetworkProtocol.WEBDAV,
                )
                protocols.forEachIndexed { index, entry ->
                    SegmentedButton(
                        selected = if (entry == NetworkProtocol.FTP) {
                            protocol == NetworkProtocol.FTP || protocol == NetworkProtocol.SFTP
                        } else {
                            protocol == entry
                        },
                        enabled = !isTesting,
                        onClick = {
                            onChange {
                                // Keep the path in sync with the protocol's default unless the user
                                // has customized it (SMB wants a bare share name, others a "/" root).
                                if (path == defaultPathFor(protocol = protocol)) {
                                    path =
                                        defaultPathFor(protocol = entry)
                                }
                                if (protocol == NetworkProtocol.SFTP &&
                                    entry != NetworkProtocol.SFTP
                                ) {
                                    authentication = NetworkAuthentication.PASSWORD
                                    privateKeyPassphrase = ""
                                    hostKeyFingerprint = ""
                                    if (selectedPrivateKey != null) {
                                        onAction(AddConnectionAction.RemoveSelectedPrivateKey)
                                    }
                                }
                                protocol = entry
                            }
                        },
                        shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            protocols.size,
                        ),
                        modifier = Modifier.tvFocusRing(
                            shape = SegmentedButtonDefaults.itemShape(
                                index = index,
                                protocols.size,
                            ),
                        ),
                    ) {
                        Text(
                            text = if (entry == NetworkProtocol.FTP) {
                                stringResource(R.string.ftp_sftp)
                            } else {
                                entry.name
                            },
                        )
                    }
                }
            }
            if (protocol == NetworkProtocol.FTP || protocol == NetworkProtocol.SFTP) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(R.string.use_sftp),
                        modifier = Modifier.weight(weight = 1f),
                    )
                    Switch(
                        checked = protocol == NetworkProtocol.SFTP,
                        onCheckedChange = { useSftp ->
                            onChange {
                                protocol =
                                    if (useSftp) NetworkProtocol.SFTP else NetworkProtocol.FTP
                                if (!useSftp) {
                                    authentication = NetworkAuthentication.PASSWORD
                                    privateKeyPassphrase = ""
                                    hostKeyFingerprint = ""
                                    if (selectedPrivateKey != null) {
                                        onAction(AddConnectionAction.RemoveSelectedPrivateKey)
                                    }
                                }
                            }
                        },
                        enabled = !isTesting,
                    )
                }
            }

            val moveToNext =
                KeyboardActions(onNext = { focusManager.moveFocus(FocusDirection.Down) })

            NextOutlinedTextField(
                value = name,
                enabled = !isTesting,
                onValueChange = { onChange { name = it } },
                label = { Text(text = stringResource(R.string.connection_name)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = moveToNext,
                modifier = Modifier.fillMaxWidth(),
            )
            NextOutlinedTextField(
                value = host,
                enabled = !isTesting,
                onValueChange = { newHost ->
                    onChange {
                        hostKeyFingerprint = fingerprintAfterEndpointEdit(
                            protocol = protocol,
                            previousValue = host,
                            newValue = newHost,
                            fingerprint = hostKeyFingerprint,
                        )
                        host = newHost
                    }
                },
                label = { Text(text = stringResource(R.string.host)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Uri,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = moveToNext,
                modifier = Modifier.fillMaxWidth(),
            )
            NextOutlinedTextField(
                value = port,
                enabled = !isTesting,
                onValueChange = { input ->
                    onChange {
                        val newPort = input.filter { it.isDigit() }
                        hostKeyFingerprint = fingerprintAfterEndpointEdit(
                            protocol = protocol,
                            previousValue = port,
                            newValue = newPort,
                            fingerprint = hostKeyFingerprint,
                        )
                        port = newPort
                    }
                },
                label = {
                    Text(
                        text = stringResource(
                            R.string.port_hint,
                            protocol.defaultPort,
                        ),
                    )
                },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number,
                    imeAction = ImeAction.Next,
                ),
                keyboardActions = moveToNext,
                modifier = Modifier.fillMaxWidth(),
            )
            NextOutlinedTextField(
                value = path,
                enabled = !isTesting,
                onValueChange = { onChange { path = it } },
                label = { Text(text = stringResource(R.string.path_share)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = moveToNext,
                modifier = Modifier.fillMaxWidth(),
            )
            NextOutlinedTextField(
                value = username,
                enabled = !isTesting,
                onValueChange = { onChange { username = it } },
                label = { Text(text = stringResource(R.string.username)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                keyboardActions = moveToNext,
                modifier = Modifier.fillMaxWidth(),
            )
            if (protocol == NetworkProtocol.SFTP) {
                Text(
                    text = stringResource(R.string.authentication),
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    val methods = NetworkAuthentication.entries
                    methods.forEachIndexed { index, method ->
                        val shape = SegmentedButtonDefaults.itemShape(
                            index = index,
                            methods.size,
                        )
                        SegmentedButton(
                            selected = authentication == method,
                            enabled = !isTesting,
                            onClick = {
                                onChange {
                                    authentication = method
                                    when (method) {
                                        NetworkAuthentication.PASSWORD -> {
                                            privateKeyPassphrase = ""
                                            if (selectedPrivateKey != null) {
                                                onAction(
                                                    AddConnectionAction.RemoveSelectedPrivateKey,
                                                )
                                            }
                                        }

                                        NetworkAuthentication.SSH_KEY -> password = ""
                                    }
                                }
                            },
                            shape = shape,
                            modifier = Modifier.tvFocusRing(shape = shape),
                        ) {
                            Text(
                                text = stringResource(
                                    id = if (method == NetworkAuthentication.PASSWORD) {
                                        R.string.password
                                    } else {
                                        R.string.ssh_key
                                    },
                                ),
                            )
                        }
                    }
                }
            }

            if (protocol != NetworkProtocol.SFTP ||
                authentication == NetworkAuthentication.PASSWORD
            ) {
                NextOutlinedTextField(
                    value = password,
                    enabled = !isTesting,
                    onValueChange = { onChange { password = it } },
                    label = { Text(text = stringResource(R.string.password)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (canSave) submit()
                        },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = { keyPicker.launch(input = arrayOf("*/*")) },
                        enabled = !isTesting,
                        modifier = Modifier.weight(weight = 1f),
                    ) {
                        Text(
                            text = stringResource(
                                id = if (activeKeyName.isBlank()) {
                                    R.string.choose_private_key
                                } else {
                                    R.string.replace_private_key
                                },
                            ),
                        )
                    }
                    if (activeKeyName.isNotBlank()) {
                        TextButton(
                            enabled = !isTesting,
                            onClick = {
                                if (selectedPrivateKey != null) {
                                    onAction(AddConnectionAction.RemoveSelectedPrivateKey)
                                } else {
                                    onChange { existingPrivateKeyRemoved = true }
                                }
                            },
                        ) { Text(text = stringResource(R.string.remove_private_key)) }
                    }
                }
                if (activeKeyName.isNotBlank()) {
                    Text(
                        text = selectedPrivateKey?.let {
                            stringResource(
                                R.string.selected_private_key,
                                it.displayName,
                            )
                        } ?: stringResource(R.string.private_key_stored),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                NextOutlinedTextField(
                    value = privateKeyPassphrase,
                    enabled = !isTesting,
                    onValueChange = { onChange { privateKeyPassphrase = it } },
                    label = { Text(text = stringResource(R.string.private_key_passphrase)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (canSave) submit()
                        },
                    ),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (protocol == NetworkProtocol.WEBDAV) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = stringResource(R.string.use_https),
                        modifier = Modifier.weight(weight = 1f),
                    )
                    Switch(
                        checked = useHttps,
                        onCheckedChange = { onChange { useHttps = it } },
                        enabled = !isTesting,
                    )
                }
            }

            (saveState as? SaveState.Error)?.let {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = it.message ?: stringResource(R.string.connection_failed),
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    it.hostKeyMismatch?.let { mismatch ->
                        SelectionContainer {
                            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                Text(
                                    text = stringResource(
                                        R.string.ssh_host_key_trusted_fingerprint,
                                        mismatch.trustedFingerprint,
                                    ),
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                                Text(
                                    text = stringResource(
                                        R.string.ssh_host_key_presented_fingerprint,
                                        mismatch.presentedFingerprint,
                                    ),
                                    color = MaterialTheme.colorScheme.error,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.size(4.dp))
            Button(
                onClick = { submit() },
                enabled = canSave,
                modifier = Modifier
                    .fillMaxWidth()
                    .tvFocusRing(shape = MaterialTheme.shapes.large),
            ) {
                if (isTesting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                    Spacer(Modifier.size(8.dp))
                    Text(text = stringResource(R.string.connecting))
                } else {
                    Text(text = stringResource(R.string.test_and_save))
                }
            }
        }
    }

    (saveState as? SaveState.ConfirmHostKey)?.confirmation?.let { confirmation ->
        NextDialog(
            onDismissRequest = { onAction(AddConnectionAction.RejectHostKey) },
            title = { Text(text = stringResource(R.string.confirm_ssh_host_key)) },
            content = {
                Text(text = stringResource(R.string.confirm_ssh_host_key_description))
                Spacer(Modifier.size(12.dp))
                Text(text = "${confirmation.host}:${confirmation.port}")
                Text(
                    text = stringResource(
                        R.string.ssh_host_key_algorithm,
                        confirmation.algorithm,
                    ),
                )
                SelectionContainer {
                    Text(
                        text = stringResource(
                            R.string.ssh_host_key_fingerprint,
                            confirmation.fingerprint,
                        ),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { onAction(AddConnectionAction.AcceptHostKey) }) {
                    Text(text = stringResource(R.string.trust))
                }
            },
            dismissButton = {
                TextButton(onClick = { onAction(AddConnectionAction.RejectHostKey) }) {
                    Text(text = stringResource(R.string.reject))
                }
            },
        )
    }
}
