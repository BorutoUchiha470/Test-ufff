package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import dev.anilbeesetti.nextplayer.feature.player.extensions.formatted
import kotlin.math.roundToInt
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** True while the seek-bar preview picture is on screen (the centre seek pop-up hides then). */
val LocalSeekPreviewVisible = staticCompositionLocalOf<MutableState<Boolean>?> { null }

private const val THUMBNAIL_HEIGHT = 180
private const val BUCKET_MS = 1_000L
private const val MAX_CACHED_FRAMES = 60

/** Reads small preview pictures from the video file. Only open while the user drags the seek bar. */
private class ThumbnailSource(
    private val context: Context,
    private val uri: Uri,
) {
    private val mutex = Mutex()
    private var retriever: MediaMetadataRetriever? = null
    private var released = false
    private var width = 320
    private var height = THUMBNAIL_HEIGHT

    suspend fun frameAt(positionMs: Long): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (released) return@withLock null
            runCatching {
                val source = retriever ?: open().also { retriever = it }
                val timeUs = positionMs * 1_000L
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    source.getScaledFrameAtTime(
                        timeUs,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                        width,
                        height,
                    )
                } else {
                    source.getFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                }
            }.getOrNull()
        }
    }

    private fun open(): MediaMetadataRetriever {
        val source = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> source.setDataSource(uri.toString(), HashMap<String, String>())
                else -> source.setDataSource(context, uri)
            }
            val videoWidth = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH,
            )?.toIntOrNull()
            val videoHeight = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT,
            )?.toIntOrNull()
            val rotation = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION,
            )?.toIntOrNull() ?: 0
            if (videoWidth != null && videoHeight != null && videoWidth > 0 && videoHeight > 0) {
                val shownWidth = if (rotation == 90 || rotation == 270) videoHeight else videoWidth
                val shownHeight = if (rotation == 90 || rotation == 270) videoWidth else videoHeight
                height = THUMBNAIL_HEIGHT
                width = (THUMBNAIL_HEIGHT * shownWidth.toFloat() / shownHeight).roundToInt()
                    .coerceAtLeast(1)
            }
        } catch (e: Throwable) {
            runCatching { source.release() }
            throw e
        }
        return source
    }

    fun release() {
        // Wait for a running read to finish before closing, then free the decoder.
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                released = true
                runCatching { retriever?.release() }
                retriever = null
            }
        }
    }
}

/** A small picture of the scene (and its time) floating above the seek bar while dragging. */
@Composable
internal fun SeekPreviewPopup(
    uri: Uri,
    positionMs: Long,
    durationMs: Long,
    barWidthPx: Int,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val source = remember(uri) { ThumbnailSource(context.applicationContext, uri) }
    DisposableEffect(source) { onDispose { source.release() } }

    var thumbnail by remember { mutableStateOf<ImageBitmap?>(null) }
    val cache = remember(uri) { HashMap<Long, ImageBitmap>() }
    val failed = remember(uri) { HashSet<Long>() }
    val latestPositionMs by rememberUpdatedState(positionMs)
    // One long-running loop that always loads the newest position. (Restarting a load on every
    // small move meant nothing ever finished while the finger was still dragging.)
    LaunchedEffect(source) {
        while (true) {
            val bucket = latestPositionMs / BUCKET_MS
            val cached = cache[bucket]
            if (cached != null) {
                thumbnail = cached
            } else if (bucket !in failed) {
                val frame = source.frameAt(bucket * BUCKET_MS)?.asImageBitmap()
                if (frame != null) {
                    if (cache.size >= MAX_CACHED_FRAMES) cache.clear()
                    cache[bucket] = frame
                    thumbnail = frame
                } else {
                    failed.add(bucket)
                }
            }
            delay(60)
        }
    }

    val popupWidth = 160.dp
    val popupWidthPx = with(density) { popupWidth.roundToPx() }
    val popupHeightPx = with(density) { 118.dp.roundToPx() }
    val gapPx = with(density) { 12.dp.roundToPx() }
    val fraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
    } else {
        0f
    }
    val centerX = (fraction * barWidthPx).roundToInt()
    val x = (centerX - popupWidthPx / 2).coerceIn(0, (barWidthPx - popupWidthPx).coerceAtLeast(0))

    Popup(
        alignment = Alignment.TopStart,
        offset = IntOffset(x, -(popupHeightPx + gapPx)),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(width = popupWidth, height = 90.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                thumbnail?.let { picture ->
                    Image(
                        bitmap = picture,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Text(
                text = positionMs.milliseconds.formatted(),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
