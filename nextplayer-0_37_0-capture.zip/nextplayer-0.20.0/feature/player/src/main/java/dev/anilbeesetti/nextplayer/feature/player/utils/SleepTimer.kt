package dev.anilbeesetti.nextplayer.feature.player.utils

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import dev.anilbeesetti.nextplayer.feature.player.service.PlayerService

/** Pauses playback after a chosen number of minutes, also when playing in the background. */
object SleepTimer {
    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null

    /** When playback will stop (SystemClock.elapsedRealtime), or 0 when no timer is running. */
    var endAtMs by mutableLongStateOf(0L)
        private set

    fun start(minutes: Int) {
        cancel()
        val delayMs = minutes * 60_000L
        endAtMs = SystemClock.elapsedRealtime() + delayMs
        val task = Runnable {
            runCatching { PlayerService.activePlayer?.pause() }
            endAtMs = 0L
            pending = null
        }
        pending = task
        handler.postDelayed(task, delayMs)
    }

    fun cancel() {
        pending?.let { handler.removeCallbacks(it) }
        pending = null
        endAtMs = 0L
    }
}
