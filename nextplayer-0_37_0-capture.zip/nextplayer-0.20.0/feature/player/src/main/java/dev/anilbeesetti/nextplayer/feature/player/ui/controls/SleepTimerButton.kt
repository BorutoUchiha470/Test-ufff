package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.os.SystemClock
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.feature.player.buttons.PlayerButton
import dev.anilbeesetti.nextplayer.feature.player.utils.SleepTimer
import kotlinx.coroutines.delay

private val SLEEP_TIMER_OPTIONS_MINUTES = listOf(15, 30, 45, 60, 90)

@Composable
fun SleepTimerButton(modifier: Modifier = Modifier) {
    var showDialog by remember { mutableStateOf(false) }

    PlayerButton(
        onClick = { showDialog = true },
        modifier = modifier,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_sleep_timer),
            contentDescription = stringResource(R.string.sleep_timer),
            tint = if (SleepTimer.endAtMs > 0L) {
                MaterialTheme.colorScheme.primary
            } else {
                LocalContentColor.current
            },
        )
    }

    if (showDialog) {
        SleepTimerDialog(onDismiss = { showDialog = false })
    }
}

@Composable
private fun SleepTimerDialog(onDismiss: () -> Unit) {
    var remainingMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            val endAt = SleepTimer.endAtMs
            remainingMs = if (endAt > 0L) {
                (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
            } else {
                0L
            }
            delay(1_000)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(text = stringResource(R.string.sleep_timer)) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                if (remainingMs > 0L) {
                    val totalSeconds = remainingMs / 1_000
                    Text(
                        text = stringResource(
                            R.string.sleep_timer_stops_in,
                            "${totalSeconds / 60}:${(totalSeconds % 60).toString().padStart(2, '0')}",
                        ),
                    )
                }
                SLEEP_TIMER_OPTIONS_MINUTES.forEach { minutes ->
                    TextButton(
                        onClick = {
                            SleepTimer.start(minutes)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(text = stringResource(R.string.sleep_timer_minutes, minutes))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(text = stringResource(R.string.done))
            }
        },
        dismissButton = {
            if (SleepTimer.endAtMs > 0L) {
                TextButton(
                    onClick = {
                        SleepTimer.cancel()
                        onDismiss()
                    },
                ) {
                    Text(text = stringResource(R.string.sleep_timer_off))
                }
            }
        },
    )
}
