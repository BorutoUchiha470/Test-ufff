package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.net.Uri
import androidx.annotation.OptIn
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.media3.common.util.UnstableApi
import androidx.media3.extractor.metadata.Chapter
import dev.anilbeesetti.nextplayer.core.ui.glass.LocalGlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.feature.player.LocalUseMaterialYouControls
import dev.anilbeesetti.nextplayer.feature.player.state.currentChapterIndex

@OptIn(
    ExperimentalMaterial3Api::class,
    UnstableApi::class,
)
@Composable
internal fun PlayerSeekbar(
    modifier: Modifier = Modifier,
    position: Float,
    duration: Float,
    chapters: List<Chapter>,
    onSeek: (Float) -> Unit,
    onSeekFinished: () -> Unit,
    previewUri: Uri? = null,
) {
    val hapticFeedback = LocalHapticFeedback.current
    var scrubValue by remember { mutableFloatStateOf(value = 0f) }
    var barWidthPx by remember { mutableIntStateOf(value = 0) }
    val currentOnSeekFinished by rememberUpdatedState(newValue = onSeekFinished)
    var isScrubbing by remember { mutableStateOf(value = false) }
    var lastSeekChapterIndex by remember(chapters) { mutableStateOf<Int?>(value = null) }
    val onValueChange: (Float) -> Unit = { value ->
        isScrubbing = true
        scrubValue = value
        val chapterIndex = chapters.currentChapterIndex(value.toLong())
        val previousChapterIndex =
            lastSeekChapterIndex ?: chapters.currentChapterIndex(position.toLong())
        if (chapterIndex != previousChapterIndex) {
            hapticFeedback.performHapticFeedback(HapticFeedbackType.SegmentTick)
        }
        lastSeekChapterIndex = chapterIndex
        onSeek(value)
    }
    val onValueChangeFinished = {
        lastSeekChapterIndex = null
        if (isScrubbing) {
            isScrubbing = false
            currentOnSeekFinished()
        }
    }
    val useMaterialYouControls = LocalUseMaterialYouControls.current
    DisposableEffect(key1 = useMaterialYouControls) {
        // Controls can disappear or change style before a pointer/key release reaches the slider.
        onDispose { onValueChangeFinished() }
    }
    var isFocused by remember { mutableStateOf(value = false) }
    val focusModifier = modifier
        .fillMaxWidth()
        .onSizeChanged { barWidthPx = it.width }
        .onFocusChanged {
            if (isFocused && !it.isFocused) onValueChangeFinished()
            isFocused = it.isFocused
        }
    val previewFlag = LocalSeekPreviewVisible.current
    val previewShowing = isScrubbing && previewUri != null && duration > 0f
    LaunchedEffect(previewShowing) { previewFlag?.value = previewShowing }
    DisposableEffect(previewFlag) { onDispose { previewFlag?.value = false } }
    CompositionLocalProvider(value = LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box {
            if (useMaterialYouControls) {
                MaterialYouSlider(
                    modifier = focusModifier,
                    isFocused = isFocused,
                    chapters = chapters,
                    value = position,
                    valueRange = 0f..(duration.takeIf { it > 0 } ?: 0f),
                    onValueChange = onValueChange,
                    onValueChangeFinished = onValueChangeFinished,
                )
            } else {
                SimpleSlider(
                    modifier = focusModifier,
                    isFocused = isFocused,
                    chapters = chapters,
                    value = position,
                    valueRange = 0f..(duration.takeIf { it > 0 } ?: 0f),
                    onValueChange = onValueChange,
                    onValueChangeFinished = onValueChangeFinished,
                )
            }
            if (isScrubbing && previewUri != null && duration > 0f) {
                SeekPreviewPopup(
                    uri = previewUri,
                    positionMs = scrubValue.toLong(),
                    durationMs = duration.toLong(),
                    barWidthPx = barWidthPx,
                )
            }
        }
    }
}

@OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MaterialYouSlider(
    modifier: Modifier = Modifier,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    isFocused: Boolean = false,
    chapters: List<Chapter> = emptyList(),
) {
    val primaryColor = MaterialTheme.colorScheme.primary
    val interactionSource = remember { MutableInteractionSource() }
    val trackHeight = 8.dp
    val thumbWidth = 4.dp
    val trackThumbGapWidth = 12.dp
    val focusedThumbWidth by animateDpAsState(
        targetValue = if (isFocused) 10.dp else thumbWidth,
        label = "thumbWidth",
    )
    val focusedThumbHeight by animateDpAsState(
        targetValue = if (isFocused) 24.dp else 20.dp,
        label = "thumbHeight",
    )

    Slider(
        value = value,
        valueRange = valueRange,
        onValueChange = onValueChange,
        onValueChangeFinished = onValueChangeFinished,
        interactionSource = interactionSource,
        modifier = modifier.size(24.dp),
        track = { sliderState ->
            val disabledAlpha = 0.4f

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(height = trackHeight)
                    .chapterGaps(
                        chapters = chapters,
                        valueRange.endInclusive,
                    ),
            ) {
                val min = sliderState.valueRange.start
                val max = sliderState.valueRange.endInclusive
                val range = (max - min).takeIf { it > 0f } ?: 1f
                val playedFraction = ((sliderState.value - min) / range).coerceIn(
                    minimumValue = 0f,
                    maximumValue = 1f,
                )
                val playedPixels = size.width * playedFraction

                val endCornerRadius = size.height / 2f
                val insideCornerRadius = 2.dp.toPx()
                val gapHalf = trackThumbGapWidth.toPx() / 2f
                val leftEnd = (playedPixels - gapHalf).coerceIn(
                    minimumValue = 0f,
                    size.width,
                )
                val rightStart = (playedPixels + gapHalf).coerceIn(
                    minimumValue = 0f,
                    size.width,
                )

                // Inactive track left side
                if (leftEnd > 0f) {
                    drawRoundedRect(
                        offset = Offset(
                            x = 0f,
                            y = 0f,
                        ),
                        size = Size(
                            width = leftEnd,
                            size.height,
                        ),
                        color = primaryColor.copy(alpha = disabledAlpha),
                        startCornerRadius = endCornerRadius,
                        endCornerRadius = insideCornerRadius,
                    )
                }

                // Inactive track right side
                if (rightStart < size.width) {
                    drawRoundedRect(
                        offset = Offset(
                            x = rightStart,
                            y = 0f,
                        ),
                        size = Size(
                            width = size.width - rightStart,
                            size.height,
                        ),
                        color = primaryColor.copy(alpha = disabledAlpha),
                        startCornerRadius = insideCornerRadius,
                        endCornerRadius = endCornerRadius,
                    )
                }

                // Active track
                if (leftEnd > 0f) {
                    drawRoundedRect(
                        offset = Offset(
                            x = 0f,
                            y = 0f,
                        ),
                        size = Size(
                            width = leftEnd,
                            size.height,
                        ),
                        color = primaryColor,
                        startCornerRadius = endCornerRadius,
                        endCornerRadius = insideCornerRadius,
                    )
                }
            }
        },
        thumb = {
            Box(
                modifier = Modifier
                    .width(width = focusedThumbWidth)
                    .height(height = focusedThumbHeight)
                    .background(
                        color = primaryColor,
                        shape = CircleShape,
                    )
                    .then(
                        other = if (isFocused) {
                            Modifier.border(
                                2.dp,
                                Color.White,
                                shape = CircleShape,
                            )
                        } else {
                            Modifier
                        },
                    ),
            )
        },
    )
}

private fun DrawScope.drawRoundedRect(
    offset: Offset,
    size: Size,
    color: Color,
    startCornerRadius: Float,
    endCornerRadius: Float,
) {
    val startCorner = CornerRadius(
        x = startCornerRadius,
        y = startCornerRadius,
    )
    val endCorner = CornerRadius(
        x = endCornerRadius,
        y = endCornerRadius,
    )
    val track = RoundRect(
        rect = Rect(
            offset = Offset(
                offset.x,
                y = 0f,
            ),
            size = Size(
                size.width,
                size.height,
            ),
        ),
        topLeft = startCorner,
        topRight = endCorner,
        bottomRight = endCorner,
        bottomLeft = startCorner,
    )
    drawPath(
        path = Path().apply { addRoundRect(roundRect = track) },
        color = color,
    )
}

@kotlin.OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleSlider(
    modifier: Modifier = Modifier,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    isFocused: Boolean = false,
    chapters: List<Chapter> = emptyList(),
) {
    val glass = LocalGlassSettings.current
    val useGlass = glass != null && glass.enabled
    val thumbSize by animateDpAsState(
        targetValue = if (isFocused) 22.dp else if (useGlass) 20.dp else 16.dp,
        label = "thumbSize",
    )
    val trackHeight = if (useGlass) 6.dp else 4.dp
    Slider(
        value = value,
        valueRange = valueRange,
        onValueChange = onValueChange,
        onValueChangeFinished = onValueChangeFinished,
        modifier = modifier.height(24.dp),
        thumb = {
            Box(
                modifier = Modifier
                    .size(size = thumbSize)
                    .then(
                        if (glass != null && glass.enabled) {
                            Modifier
                                .glassSurface(settings = glass, shape = CircleShape)
                                .background(Color.White.copy(alpha = 0.35f), CircleShape)
                        } else {
                            Modifier
                                .shadow(
                                    4.dp,
                                    shape = CircleShape,
                                )
                                .background(Color.White)
                        },
                    )
                    .then(
                        other = if (isFocused) {
                            Modifier.border(
                                2.dp,
                                MaterialTheme.colorScheme.primary,
                                shape = CircleShape,
                            )
                        } else {
                            Modifier
                        },
                    ),
            )
        },
        track = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(trackHeight)
                    .chapterGaps(
                        chapters = chapters,
                        valueRange.endInclusive,
                    )
                    .then(
                        if (glass != null && glass.enabled) {
                            Modifier.glassSurface(settings = glass, shape = RoundedCornerShape(50))
                        } else {
                            Modifier
                                .clip(MaterialTheme.shapes.extraSmall)
                                .background(Color.White.copy(alpha = 0.5f))
                        },
                    ),
            ) {
                if (valueRange.endInclusive > 0f) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction = value / valueRange.endInclusive)
                            .height(trackHeight)
                            .background(MaterialTheme.colorScheme.primary),
                    )
                }
            }
        },
    )
}

@OptIn(UnstableApi::class)
private fun Modifier.chapterGaps(chapters: List<Chapter>, duration: Float): Modifier =
    drawWithCache {
        val gaps = Path()
        if (duration > 0f) {
            val halfGap = 1.5.dp.toPx()
            chapters.forEach { chapter ->
                if (chapter.startTimeMs > 0 && chapter.startTimeMs < duration) {
                    val x = size.width * (chapter.startTimeMs / duration)
                    gaps.addRect(
                        rect = Rect(
                            left = x - halfGap,
                            top = 0f,
                            right = x + halfGap,
                            size.height,
                        ),
                    )
                }
            }
        }
        onDrawWithContent {
            clipPath(
                path = gaps,
                ClipOp.Difference,
            ) { this@onDrawWithContent.drawContent() }
        }
    }
