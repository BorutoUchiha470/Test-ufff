package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.theme.ThemePalette
import dev.anilbeesetti.nextplayer.core.ui.theme.rememberAppLook
import kotlin.math.roundToInt

/** Color theme picker and the liquid glass switch for the app screens. */
@Composable
fun AppLookSettings(modifier: Modifier = Modifier) {
    val look = rememberAppLook()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            ThemePalette.entries.forEach { palette ->
                val selected = look.palette == palette
                Column(
                    modifier = Modifier.clickable { look.selectPalette(palette) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(palette.seed ?: MaterialTheme.colorScheme.primary)
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) Color.White else Color.Gray,
                                shape = CircleShape,
                            ),
                    )
                    Text(
                        text = palette.label,
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }

        SwitchRow(
            title = stringResource(R.string.app_glass),
            description = stringResource(R.string.app_glass_desc),
            checked = look.glassEnabled,
            onCheckedChange = { look.updateGlassEnabled(it) },
        )

        SwitchRow(
            title = stringResource(R.string.fast_transitions),
            description = stringResource(R.string.fast_transitions_desc),
            checked = look.fastTransitions,
            onCheckedChange = { look.updateFastTransitions(it) },
        )

        if (look.glassEnabled) {
            SliderRow(
                title = stringResource(R.string.app_glass_opacity),
                valueText = "${(look.cardOpacity * 100).roundToInt()}%",
                value = look.cardOpacity,
                valueRange = 0.04f..0.3f,
                onValueChange = { look.updateCardOpacity(it) },
            )
        }

        Box(modifier = Modifier.padding(bottom = 4.dp))
    }
}
