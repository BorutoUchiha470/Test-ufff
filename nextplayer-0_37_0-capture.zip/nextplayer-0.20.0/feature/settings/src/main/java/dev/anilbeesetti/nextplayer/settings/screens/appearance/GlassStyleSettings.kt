package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.glass.GlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.GlassTintPresets
import dev.anilbeesetti.nextplayer.core.ui.glass.GlassType
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.core.ui.glass.rememberGlassSettings
import kotlin.math.roundToInt

/** Lets the user change how the glass player controls look, with a live preview. */
@Composable
fun GlassStyleSettings(modifier: Modifier = Modifier) {
    val glass = rememberGlassSettings()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF3A1C71), Color(0xFFD76D77), Color(0xFFFFAF7B)),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(3) { PreviewBubble(glass = glass) }
            }
        }

        SwitchRow(
            title = stringResource(R.string.glass_controls),
            description = null,
            checked = glass.enabled,
            onCheckedChange = { glass.updateEnabled(it) },
        )

        SectionTitle(text = stringResource(R.string.glass_look))
        GlassTypeRow(glass, GlassType.LIQUID, stringResource(R.string.glass_type_liquid))
        GlassTypeRow(glass, GlassType.FROSTED, stringResource(R.string.glass_type_frosted))
        GlassTypeRow(glass, GlassType.CLEAR, stringResource(R.string.glass_type_clear))
        GlassTypeRow(glass, GlassType.SOLID, stringResource(R.string.glass_type_solid))

        SliderRow(
            title = stringResource(R.string.glass_transparency),
            valueText = "${(glass.opacity * 100).roundToInt()}%",
            value = glass.opacity,
            valueRange = 0.05f..0.8f,
            onValueChange = { glass.updateOpacity(it) },
        )
        SliderRow(
            title = stringResource(R.string.glass_edge_shine),
            valueText = "${(glass.edgeShine * 100).roundToInt()}%",
            value = glass.edgeShine,
            valueRange = 0f..1f,
            onValueChange = { glass.updateEdgeShine(it) },
        )
        SliderRow(
            title = stringResource(R.string.glass_corner_radius),
            valueText = "${glass.cornerPercent}%",
            value = glass.cornerPercent.toFloat(),
            valueRange = 0f..50f,
            onValueChange = { glass.updateCornerPercent(it.roundToInt()) },
        )

        Text(text = stringResource(R.string.glass_color))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassTintPresets.forEach { preset ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(preset))
                        .border(
                            width = if (glass.tint == preset) 3.dp else 1.dp,
                            color = if (glass.tint == preset) Color.White else Color.Gray,
                            shape = CircleShape,
                        )
                        .clickable { glass.updateTint(preset) },
                )
            }
        }

        SectionTitle(text = stringResource(R.string.glass_effects))
        SwitchRow(
            title = stringResource(R.string.glass_glow),
            description = stringResource(R.string.glass_glow_desc),
            checked = glass.glow,
            onCheckedChange = { glass.updateGlow(it) },
        )
        SwitchRow(
            title = stringResource(R.string.glass_shadow),
            description = stringResource(R.string.glass_shadow_desc),
            checked = glass.shadow,
            onCheckedChange = { glass.updateShadow(it) },
        )
        SwitchRow(
            title = stringResource(R.string.glass_depth),
            description = stringResource(R.string.glass_depth_desc),
            checked = glass.depth,
            onCheckedChange = { glass.updateDepth(it) },
        )
        SwitchRow(
            title = stringResource(R.string.glass_chromatic),
            description = stringResource(R.string.glass_chromatic_desc),
            checked = glass.chromatic,
            onCheckedChange = { glass.updateChromatic(it) },
        )
        SwitchRow(
            title = stringResource(R.string.glass_vibrancy),
            description = stringResource(R.string.glass_vibrancy_desc),
            checked = glass.vibrancy,
            onCheckedChange = { glass.updateVibrancy(it) },
        )

        TextButton(
            onClick = { glass.reset() },
            modifier = Modifier.padding(bottom = 16.dp),
        ) {
            Text(text = stringResource(R.string.reset))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp),
    )
}

@Composable
private fun GlassTypeRow(glass: GlassSettings, type: GlassType, label: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { glass.updateType(type) },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(
            selected = glass.glassType == type,
            onClick = { glass.updateType(type) },
        )
        Text(text = label)
    }
}

@Composable
internal fun SliderRow(
    title: String,
    valueText: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    onValueChange: (Float) -> Unit,
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = title)
            Text(text = valueText)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
        )
    }
}

@Composable
internal fun SwitchRow(
    title: String,
    description: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title)
            if (description != null) {
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun PreviewBubble(glass: GlassSettings) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .then(
                if (glass.enabled) {
                    Modifier.glassSurface(settings = glass)
                } else {
                    Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.3f))
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_capture),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp),
        )
    }
}
