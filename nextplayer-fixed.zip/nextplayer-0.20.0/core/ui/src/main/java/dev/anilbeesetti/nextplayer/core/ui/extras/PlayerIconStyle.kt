package dev.anilbeesetti.nextplayer.core.ui.extras

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import dev.anilbeesetti.nextplayer.core.ui.R

/** True when the player should use the thin, flat "Modern" icons instead of the "Legacy" ones. */
@Composable
fun isModernPlayerIcons(): Boolean = rememberExtraFeatures().modernPlayerIcons

/** Gives the Modern version of a player icon when Modern is chosen, otherwise the usual one. */
@Composable
fun playerIconPainter(@DrawableRes id: Int): Painter {
    val modern = isModernPlayerIcons()
    val resource = if (modern) modernIcons[id] ?: id else id
    return painterResource(resource)
}

private val modernIcons: Map<Int, Int> by lazy {
    mapOf(
        R.drawable.ic_arrow_left to R.drawable.ic_arrow_left_modern,
        R.drawable.ic_subtitle_track to R.drawable.ic_subtitle_track_modern,
        R.drawable.ic_audio_track to R.drawable.ic_audio_track_modern,
        R.drawable.ic_playlist to R.drawable.ic_playlist_modern,
        R.drawable.ic_headset to R.drawable.ic_headset_modern,
        R.drawable.ic_lock to R.drawable.ic_lock_modern,
        R.drawable.ic_lock_open to R.drawable.ic_lock_open_modern,
        R.drawable.ic_screen_rotation to R.drawable.ic_screen_rotation_modern,
        R.drawable.ic_pip to R.drawable.ic_pip_modern,
        R.drawable.ic_capture to R.drawable.ic_capture_modern,
        R.drawable.ic_skip_prev to R.drawable.ic_skip_prev_modern,
        R.drawable.ic_skip_next to R.drawable.ic_skip_next_modern,
        R.drawable.ic_play to R.drawable.ic_play_modern,
        R.drawable.ic_pause to R.drawable.ic_pause_modern,
        R.drawable.ic_shuffle to R.drawable.ic_shuffle_modern,
        R.drawable.ic_shuffle_on to R.drawable.ic_shuffle_on_modern,
        R.drawable.ic_loop_all to R.drawable.ic_loop_all_modern,
        R.drawable.ic_loop_one to R.drawable.ic_loop_one_modern,
        R.drawable.ic_loop_off to R.drawable.ic_loop_off_modern,
        R.drawable.ic_sleep_timer to R.drawable.ic_sleep_timer_modern,
        R.drawable.ic_enhance to R.drawable.ic_enhance_modern,
        R.drawable.ic_fast to R.drawable.ic_fast_modern,
        R.drawable.ic_close to R.drawable.ic_close_modern,
        R.drawable.ic_add to R.drawable.ic_add_modern,
        R.drawable.ic_remove to R.drawable.ic_remove_modern,
        R.drawable.ic_volume to R.drawable.ic_volume_modern,
        R.drawable.ic_brightness to R.drawable.ic_brightness_modern,
        R.drawable.ic_reset to R.drawable.ic_reset_modern,
        R.drawable.ic_drag_handle to R.drawable.ic_drag_handle_modern,
    )
}
