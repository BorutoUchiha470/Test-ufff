package dev.anilbeesetti.nextplayer.core.ui.shorts

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Saved settings and lists (liked / blocked) for the Shorts tab. Shared by the feed and its settings page. */
class ShortsPrefs private constructor(private val prefs: SharedPreferences) {
    var autoNext by mutableStateOf(prefs.getBoolean(KEY_AUTO_NEXT, false))
        private set
    var includeNormal by mutableStateOf(prefs.getBoolean(KEY_INCLUDE_NORMAL, false))
        private set
    var startMuted by mutableStateOf(prefs.getBoolean(KEY_MUTED, false))
        private set
    var glassControls by mutableStateOf(prefs.getBoolean(KEY_GLASS, true))
        private set
    var showBack by mutableStateOf(prefs.getBoolean(KEY_BACK, true))
        private set
    var shuffle by mutableStateOf(prefs.getBoolean(KEY_SHUFFLE, false))
        private set
    var holdToSpeed by mutableStateOf(prefs.getBoolean(KEY_HOLD_SPEED, true))
        private set

    /** Longest normal (horizontal) video, in seconds, that still counts as a short. */
    var maxHorizontalSeconds by mutableIntStateOf(prefs.getInt(KEY_MAX_H, 60))
        private set

    val liked = mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet(KEY_LIKED, emptySet()).orEmpty())
    }
    val blocked = mutableStateListOf<String>().apply {
        addAll(prefs.getStringSet(KEY_BLOCKED, emptySet()).orEmpty())
    }

    fun updateAutoNext(value: Boolean) = putBool(KEY_AUTO_NEXT, value) { autoNext = value }
    fun updateIncludeNormal(value: Boolean) = putBool(KEY_INCLUDE_NORMAL, value) { includeNormal = value }
    fun updateStartMuted(value: Boolean) = putBool(KEY_MUTED, value) { startMuted = value }
    fun updateGlassControls(value: Boolean) = putBool(KEY_GLASS, value) { glassControls = value }
    fun updateShowBack(value: Boolean) = putBool(KEY_BACK, value) { showBack = value }
    fun updateShuffle(value: Boolean) = putBool(KEY_SHUFFLE, value) { shuffle = value }
    fun updateHoldToSpeed(value: Boolean) = putBool(KEY_HOLD_SPEED, value) { holdToSpeed = value }

    fun updateMaxHorizontalSeconds(value: Int) {
        maxHorizontalSeconds = value
        prefs.edit().putInt(KEY_MAX_H, value).apply()
    }

    fun toggleLike(uri: String) {
        if (!liked.remove(uri)) liked.add(uri)
        prefs.edit().putStringSet(KEY_LIKED, liked.toSet()).apply()
    }

    fun block(uri: String) {
        if (uri !in blocked) blocked.add(uri)
        prefs.edit().putStringSet(KEY_BLOCKED, blocked.toSet()).apply()
    }

    fun clearBlocked() {
        blocked.clear()
        prefs.edit().putStringSet(KEY_BLOCKED, emptySet()).apply()
    }

    fun clearLiked() {
        liked.clear()
        prefs.edit().putStringSet(KEY_LIKED, emptySet()).apply()
    }

    private inline fun putBool(key: String, value: Boolean, assign: () -> Unit) {
        assign()
        prefs.edit().putBoolean(key, value).apply()
    }

    companion object {
        private const val KEY_AUTO_NEXT = "auto_next"
        private const val KEY_INCLUDE_NORMAL = "include_normal"
        private const val KEY_MUTED = "muted"
        private const val KEY_GLASS = "glass_controls"
        private const val KEY_BACK = "show_back"
        private const val KEY_SHUFFLE = "shuffle"
        private const val KEY_HOLD_SPEED = "hold_to_speed"
        private const val KEY_MAX_H = "max_horizontal_seconds"
        private const val KEY_LIKED = "liked"
        private const val KEY_BLOCKED = "blocked"

        @Volatile
        private var instance: ShortsPrefs? = null

        fun get(context: Context): ShortsPrefs = instance ?: synchronized(this) {
            instance ?: ShortsPrefs(
                context.applicationContext.getSharedPreferences("shorts_prefs", Context.MODE_PRIVATE),
            ).also { instance = it }
        }
    }
}
