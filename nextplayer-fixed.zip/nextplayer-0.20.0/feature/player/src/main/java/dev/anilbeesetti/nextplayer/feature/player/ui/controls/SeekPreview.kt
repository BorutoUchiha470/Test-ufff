package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.feature.player.extensions.formatted
import kotlin.math.roundToInt
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** True while the seek-bar preview picture is on screen (the centre seek pop-up hides then). */
val LocalSeekPreviewVisible = staticCompositionLocalOf<MutableState<Boolean>?> { null }

private const val THUMBNAIL_HEIGHT = 144
private const val BUCKET_MS = 2_000L
private const val EXACT_BUCKET_MS = 500L
private const val MAX_CACHED_FRAMES = 40
private const val STRIP_SLOTS = 128
private const val STRIP_HEIGHT = 120

/** Pre-made small pictures per video (kept for the last couple of videos so they are ready next time). */
private object StripCache {
    private val videos = LinkedHashMap<String, java.util.concurrent.ConcurrentHashMap<Int, ImageBitmap>>()

    @Synchronized
    fun forVideo(key: String): java.util.concurrent.ConcurrentHashMap<Int, ImageBitmap> {
        videos[key]?.let { return it }
        val created = java.util.concurrent.ConcurrentHashMap<Int, ImageBitmap>()
        videos[key] = created
        while (videos.size > 2) videos.remove(videos.keys.first())
        return created
    }
}

/** Reads small preview pictures from the video file. Only open while the user drags the seek bar. */
private class ThumbnailSource(
    private val context: Context,
    private val uri: Uri,
    private val thumbnailHeight: Int,
) {
    private val mutex = Mutex()
    private var retriever: MediaMetadataRetriever? = null
    private var released = false
    private var width = 320
    private var height = thumbnailHeight

    /** [exact] = the real frame at that time (slower); otherwise the nearest key frame (fast). */
    suspend fun frameAt(positionMs: Long, exact: Boolean): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (released) return@withLock null
            runCatching {
                val source = retriever ?: open().also { retriever = it }
                val timeUs = positionMs * 1_000L
                val option = if (exact) {
                    MediaMetadataRetriever.OPTION_CLOSEST
                } else {
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    source.getScaledFrameAtTime(timeUs, option, width, height)
                } else {
                    source.getFrameAtTime(timeUs, option)
                }
            }.getOrNull()
        }
    }

    private fun open(): MediaMetadataRetriever {
        val source = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> source.setDataSource(uri.toString(), HashMap<String, String>())
                else -> source.setDataSource(context, uri)
            }
            val videoWidth = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH,
            )?.toIntOrNull()
            val videoHeight = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT,
            )?.toIntOrNull()
            val rotation = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION,
            )?.toIntOrNull() ?: 0
            if (videoWidth != null && videoHeight != null && videoWidth > 0 && videoHeight > 0) {
                val shownWidth = if (rotation == 90 || rotation == 270) videoHeight else videoWidth
                val shownHeight = if (rotation == 90 || rotation == 270) videoWidth else videoHeight
                height = thumbnailHeight
                width = (thumbnailHeight * shownWidth.toFloat() / shownHeight).roundToInt()
                    .coerceAtLeast(1)
            }
        } catch (e: Throwable) {
            runCatching { source.release() }
            throw e
        }
        return source
    }

    fun release() {
        // Wait for a running read to finish before closing, then free the decoder.
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                released = true
                runCatching { retriever?.release() }
                retriever = null
            }
        }
    }
}

/**
 * Keeps the preview engine alive for as long as the seek bar is on screen, so the video file is
 * opened once (in the background) instead of at the start of every drag.
 */
@Stable
internal class SeekPreviewController(
    context: Context,
    uri: Uri,
    val scale: Float,
    private val thumbnailHeight: Int,
) {
    private val source = ThumbnailSource(context.applicationContext, uri, thumbnailHeight)
    // A second reader fills the strip in the background so dragging never waits for it.
    private val stripSource = ThumbnailSource(context.applicationContext, uri, STRIP_HEIGHT)
    private val strip = StripCache.forVideo(uri.toString())
    private var knownDurationMs = 0L
    private val cache = HashMap<Long, ImageBitmap>()
    private val exactCache = HashMap<Long, ImageBitmap>()
    private val failed = HashSet<Long>()
    private val failedExact = HashSet<Long>()

    var thumbnail by mutableStateOf<ImageBitmap?>(null)
        private set
    var aspect by mutableFloatStateOf(16f / 9f)
        private set

    suspend fun prewarm() {
        // Open the file and fetch the first picture now so the first drag is instant.
        source.frameAt(0L, exact = false)
    }

    fun release() {
        source.release()
        stripSource.release()
    }

    /** Makes a coarse set of pictures first (whole video), then finer and finer ones. */
    suspend fun buildStrip(durationMs: Long) {
        knownDurationMs = durationMs
        for (level in intArrayOf(8, 16, 32, 64, 128)) {
            val step = STRIP_SLOTS / level
            for (i in 0 until level) {
                val slot = i * step
                if (strip.containsKey(slot)) continue
                val position = slot.toLong() * durationMs / STRIP_SLOTS
                val frame = stripSource.frameAt(position, exact = false)
                if (frame != null) {
                    aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                    strip[slot] = frame.asImageBitmap()
                }
                delay(30)
            }
        }
    }

    private fun nearestStripPicture(positionMs: Long): ImageBitmap? {
        val total = knownDurationMs
        if (total <= 0L || strip.isEmpty()) return null
        val slot = (positionMs * STRIP_SLOTS / total).toInt().coerceIn(0, STRIP_SLOTS - 1)
        for (distance in 0..STRIP_SLOTS) {
            strip[slot - distance]?.let { return it }
            strip[slot + distance]?.let { return it }
        }
        return null
    }

    /** Runs while the finger is on the seek bar; always loads the newest position. */
    suspend fun run(latestPositionMs: () -> Long) {
        var lastPosition = -1L
        while (true) {
            val position = latestPositionMs()
            val resting = position == lastPosition
            lastPosition = position
            val exactKey = position / EXACT_BUCKET_MS
            val bucket = position / BUCKET_MS
            val exactCached = exactCache[exactKey]
            val fastCached = cache[bucket]
            // Show something right away: the exact picture, a fast one, or the nearest pre-made one.
            val instant = exactCached ?: fastCached ?: nearestStripPicture(position)
            if (instant != null) thumbnail = instant

            if (exactCached == null && resting && exactKey !in failedExact) {
                val frame = source.frameAt(exactKey * EXACT_BUCKET_MS, exact = true)
                if (frame != null) {
                    if (exactCache.size >= MAX_CACHED_FRAMES) exactCache.clear()
                    aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                    val image = frame.asImageBitmap()
                    exactCache[exactKey] = image
                    if (latestPositionMs() / EXACT_BUCKET_MS == exactKey) thumbnail = image
                } else {
                    failedExact.add(exactKey)
                }
            } else if (exactCached == null && fastCached == null && bucket !in failed) {
                val frame = source.frameAt(bucket * BUCKET_MS, exact = false)
                if (frame != null) {
                    if (cache.size >= MAX_CACHED_FRAMES) cache.clear()
                    aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                    val image = frame.asImageBitmap()
                    cache[bucket] = image
                    if (latestPositionMs() / BUCKET_MS == bucket) thumbnail = image
                } else {
                    failed.add(bucket)
                }
            }
            delay(60)
        }
    }
}

@Composable
internal fun rememberSeekPreview(uri: Uri?, durationMs: Long): SeekPreviewController? {
    if (uri == null) return null
    val context = LocalContext.current
    val scale = rememberExtraFeatures().seekPreviewScale.coerceIn(0.5f, 2.2f)
    val thumbnailHeight = (THUMBNAIL_HEIGHT * scale).roundToInt().coerceIn(96, 320)
    val controller = remember(uri, thumbnailHeight) {
        SeekPreviewController(context, uri, scale, thumbnailHeight)
    }
    DisposableEffect(controller) { onDispose { controller.release() } }
    LaunchedEffect(controller) { controller.prewarm() }
    // Prepare the preview pictures while the controls are open (cancelled when they close).
    val hasDuration = durationMs > 0L
    LaunchedEffect(controller, hasDuration) {
        if (hasDuration) controller.buildStrip(durationMs)
    }
    return controller
}

/** A small picture of the scene (and its time) floating above the seek bar while dragging. */
@Composable
internal fun SeekPreviewPopup(
    controller: SeekPreviewController,
    positionMs: Long,
    durationMs: Long,
    barWidthPx: Int,
) {
    val density = LocalDensity.current
    val scale = controller.scale
    val aspect = controller.aspect
    val thumbnail = controller.thumbnail
    val latestPositionMs by rememberUpdatedState(positionMs)
    LaunchedEffect(controller) { controller.run { latestPositionMs } }

    // The picture box follows the video's own shape (wide, square or tall) inside a size limit.
    val maxWidth = (160 * scale).dp
    val maxHeight = (100 * scale).dp
    val limitAspect = maxWidth / maxHeight
    val popupWidth = if (aspect >= limitAspect) maxWidth else maxHeight * aspect
    val pictureHeight = if (aspect >= limitAspect) maxWidth / aspect else maxHeight
    val popupWidthPx = with(density) { popupWidth.roundToPx() }
    val popupHeightPx = with(density) { (pictureHeight + 28.dp).roundToPx() }
    val gapPx = with(density) { 12.dp.roundToPx() }
    val fraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
    } else {
        0f
    }
    val centerX = (fraction * barWidthPx).roundToInt()
    val x = (centerX - popupWidthPx / 2).coerceIn(0, (barWidthPx - popupWidthPx).coerceAtLeast(0))

    Popup(
        alignment = Alignment.TopStart,
        offset = IntOffset(x, -(popupHeightPx + gapPx)),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(width = popupWidth, height = pictureHeight)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                if (thumbnail == null) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.dp,
                        color = Color.White.copy(alpha = 0.8f),
                    )
                }
                thumbnail?.let { picture ->
                    Image(
                        bitmap = picture,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Text(
                text = positionMs.milliseconds.formatted(),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
