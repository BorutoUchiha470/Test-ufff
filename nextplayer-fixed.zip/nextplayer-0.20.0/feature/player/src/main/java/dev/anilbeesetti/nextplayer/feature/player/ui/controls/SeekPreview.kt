package dev.anilbeesetti.nextplayer.feature.player.ui.controls

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Popup
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.feature.player.extensions.formatted
import kotlin.math.roundToInt
import kotlin.time.Duration.Companion.milliseconds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/** True while the seek-bar preview picture is on screen (the centre seek pop-up hides then). */
val LocalSeekPreviewVisible = staticCompositionLocalOf<MutableState<Boolean>?> { null }

private const val THUMBNAIL_HEIGHT = 144
private const val BUCKET_MS = 2_000L
private const val EXACT_BUCKET_MS = 500L
private const val MAX_CACHED_FRAMES = 40

/** Reads small preview pictures from the video file. Only open while the user drags the seek bar. */
private class ThumbnailSource(
    private val context: Context,
    private val uri: Uri,
    private val thumbnailHeight: Int,
) {
    private val mutex = Mutex()
    private var retriever: MediaMetadataRetriever? = null
    private var released = false
    private var width = 320
    private var height = thumbnailHeight

    /** [exact] = the real frame at that time (slower); otherwise the nearest key frame (fast). */
    suspend fun frameAt(positionMs: Long, exact: Boolean): android.graphics.Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (released) return@withLock null
            runCatching {
                val source = retriever ?: open().also { retriever = it }
                val timeUs = positionMs * 1_000L
                val option = if (exact) {
                    MediaMetadataRetriever.OPTION_CLOSEST
                } else {
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    source.getScaledFrameAtTime(timeUs, option, width, height)
                } else {
                    source.getFrameAtTime(timeUs, option)
                }
            }.getOrNull()
        }
    }

    private fun open(): MediaMetadataRetriever {
        val source = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> source.setDataSource(uri.toString(), HashMap<String, String>())
                else -> source.setDataSource(context, uri)
            }
            val videoWidth = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH,
            )?.toIntOrNull()
            val videoHeight = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT,
            )?.toIntOrNull()
            val rotation = source.extractMetadata(
                MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION,
            )?.toIntOrNull() ?: 0
            if (videoWidth != null && videoHeight != null && videoWidth > 0 && videoHeight > 0) {
                val shownWidth = if (rotation == 90 || rotation == 270) videoHeight else videoWidth
                val shownHeight = if (rotation == 90 || rotation == 270) videoWidth else videoHeight
                height = thumbnailHeight
                width = (thumbnailHeight * shownWidth.toFloat() / shownHeight).roundToInt()
                    .coerceAtLeast(1)
            }
        } catch (e: Throwable) {
            runCatching { source.release() }
            throw e
        }
        return source
    }

    fun release() {
        // Wait for a running read to finish before closing, then free the decoder.
        CoroutineScope(Dispatchers.IO).launch {
            mutex.withLock {
                released = true
                runCatching { retriever?.release() }
                retriever = null
            }
        }
    }
}

/** A small picture of the scene (and its time) floating above the seek bar while dragging. */
@Composable
internal fun SeekPreviewPopup(
    uri: Uri,
    positionMs: Long,
    durationMs: Long,
    barWidthPx: Int,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val scale = rememberExtraFeatures().seekPreviewScale.coerceIn(0.5f, 2.2f)
    val thumbnailHeight = (THUMBNAIL_HEIGHT * scale).roundToInt().coerceIn(96, 320)
    val source = remember(uri, thumbnailHeight) { ThumbnailSource(context.applicationContext, uri, thumbnailHeight) }
    DisposableEffect(source) { onDispose { source.release() } }

    var thumbnail by remember { mutableStateOf<ImageBitmap?>(null) }
    var aspect by remember(uri) { mutableFloatStateOf(16f / 9f) }
    val cache = remember(uri, thumbnailHeight) { HashMap<Long, ImageBitmap>() }
    val exactCache = remember(uri, thumbnailHeight) { HashMap<Long, ImageBitmap>() }
    val failed = remember(uri, thumbnailHeight) { HashSet<Long>() }
    val failedExact = remember(uri, thumbnailHeight) { HashSet<Long>() }
    val latestPositionMs by rememberUpdatedState(positionMs)
    // One long-running loop that always loads the newest position. While the finger is moving it
    // shows quick nearby pictures; once the finger rests it swaps in the exact frame for that time.
    LaunchedEffect(source) {
        var lastPosition = -1L
        while (true) {
            val position = latestPositionMs
            val resting = position == lastPosition
            lastPosition = position
            val exactKey = position / EXACT_BUCKET_MS
            val exactCached = exactCache[exactKey]
            if (exactCached != null) {
                thumbnail = exactCached
            } else {
                val bucket = position / BUCKET_MS
                if (resting && exactKey !in failedExact) {
                    val frame = source.frameAt(exactKey * EXACT_BUCKET_MS, exact = true)
                    if (frame != null) {
                        if (exactCache.size >= MAX_CACHED_FRAMES) exactCache.clear()
                        aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                        val image = frame.asImageBitmap()
                        exactCache[exactKey] = image
                        thumbnail = image
                    } else {
                        failedExact.add(exactKey)
                    }
                } else {
                    val cached = cache[bucket]
                    if (cached != null) {
                        thumbnail = cached
                    } else if (bucket !in failed) {
                        val frame = source.frameAt(bucket * BUCKET_MS, exact = false)
                        if (frame != null) {
                            if (cache.size >= MAX_CACHED_FRAMES) cache.clear()
                            aspect = frame.width.toFloat() / frame.height.coerceAtLeast(1)
                            val image = frame.asImageBitmap()
                            cache[bucket] = image
                            thumbnail = image
                        } else {
                            failed.add(bucket)
                        }
                    }
                }
            }
            delay(120)
        }
    }

    // The picture box follows the video's own shape (wide, square or tall) inside a size limit.
    val maxWidth = (160 * scale).dp
    val maxHeight = (100 * scale).dp
    val limitAspect = maxWidth / maxHeight
    val popupWidth = if (aspect >= limitAspect) maxWidth else maxHeight * aspect
    val pictureHeight = if (aspect >= limitAspect) maxWidth / aspect else maxHeight
    val popupWidthPx = with(density) { popupWidth.roundToPx() }
    val popupHeightPx = with(density) { (pictureHeight + 28.dp).roundToPx() }
    val gapPx = with(density) { 12.dp.roundToPx() }
    val fraction = if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs).coerceIn(0f, 1f)
    } else {
        0f
    }
    val centerX = (fraction * barWidthPx).roundToInt()
    val x = (centerX - popupWidthPx / 2).coerceIn(0, (barWidthPx - popupWidthPx).coerceAtLeast(0))

    Popup(
        alignment = Alignment.TopStart,
        offset = IntOffset(x, -(popupHeightPx + gapPx)),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(width = popupWidth, height = pictureHeight)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.Black)
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center,
            ) {
                thumbnail?.let { picture ->
                    Image(
                        bitmap = picture,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            Text(
                text = positionMs.milliseconds.formatted(),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
