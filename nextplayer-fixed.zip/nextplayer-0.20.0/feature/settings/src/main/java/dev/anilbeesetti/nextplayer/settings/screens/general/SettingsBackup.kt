package dev.anilbeesetti.nextplayer.settings.screens.general

import android.content.Context
import android.util.Xml
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import org.xmlpull.v1.XmlPullParser

/**
 * Saves the app's settings into one XML file and puts them back again.
 * The vault PIN is never included.
 */
object SettingsBackup {
    private const val ROOT = "settings-backup"
    private val DATASTORE_FILES = listOf("app_preferences.json", "player_preferences.json")
    private val PREFS_FILES = listOf(
        "extra_features",
        "shorts_prefs",
        "app_look",
        "glass_style",
        "capture_button",
        "profile",
    )

    private class Entry(val key: String, val type: String, val value: String, val items: List<String>)

    fun export(context: Context, output: OutputStream) {
        val xml = Xml.newSerializer()
        xml.setOutput(output, "UTF-8")
        xml.startDocument("UTF-8", true)
        xml.startTag(null, ROOT)
        xml.attribute(null, "version", "1")

        DATASTORE_FILES.forEach { name ->
            val file = File(context.filesDir, "datastore/$name")
            if (file.exists()) {
                xml.startTag(null, "datastore")
                xml.attribute(null, "name", name)
                xml.text(file.readText())
                xml.endTag(null, "datastore")
            }
        }

        PREFS_FILES.forEach { name ->
            val prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE)
            xml.startTag(null, "prefs")
            xml.attribute(null, "name", name)
            for ((key, value) in prefs.all) {
                xml.startTag(null, "entry")
                xml.attribute(null, "key", key)
                when (value) {
                    is Boolean -> { xml.attribute(null, "type", "boolean"); xml.attribute(null, "value", value.toString()) }
                    is Int -> { xml.attribute(null, "type", "int"); xml.attribute(null, "value", value.toString()) }
                    is Long -> { xml.attribute(null, "type", "long"); xml.attribute(null, "value", value.toString()) }
                    is Float -> { xml.attribute(null, "type", "float"); xml.attribute(null, "value", value.toString()) }
                    is String -> { xml.attribute(null, "type", "string"); xml.attribute(null, "value", value) }
                    is Set<*> -> {
                        xml.attribute(null, "type", "stringset")
                        value.forEach {
                            xml.startTag(null, "item")
                            xml.text(it.toString())
                            xml.endTag(null, "item")
                        }
                    }
                    else -> xml.attribute(null, "type", "skip")
                }
                xml.endTag(null, "entry")
            }
            xml.endTag(null, "prefs")
        }

        xml.endTag(null, ROOT)
        xml.endDocument()
        xml.flush()
    }

    /** Returns true when the file was a valid backup and has been applied. */
    fun import(context: Context, input: InputStream): Boolean {
        val parser = Xml.newPullParser()
        parser.setInput(input, "UTF-8")

        val datastores = mutableMapOf<String, String>()
        val prefs = mutableMapOf<String, MutableList<Entry>>()
        var rootFound = false
        var currentPrefs: MutableList<Entry>? = null
        var key = ""
        var type = ""
        var value = ""
        var items = mutableListOf<String>()

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG) {
                when (parser.name) {
                    ROOT -> rootFound = true
                    "datastore" -> {
                        val name = parser.getAttributeValue(null, "name").orEmpty()
                        val text = parser.nextText()
                        if (name in DATASTORE_FILES) datastores[name] = text
                    }
                    "prefs" -> {
                        val name = parser.getAttributeValue(null, "name").orEmpty()
                        currentPrefs = if (name in PREFS_FILES) prefs.getOrPut(name) { mutableListOf() } else null
                    }
                    "entry" -> {
                        key = parser.getAttributeValue(null, "key").orEmpty()
                        type = parser.getAttributeValue(null, "type").orEmpty()
                        value = parser.getAttributeValue(null, "value").orEmpty()
                        items = mutableListOf()
                    }
                    "item" -> items.add(parser.nextText())
                }
            } else if (event == XmlPullParser.END_TAG && parser.name == "entry") {
                currentPrefs?.add(Entry(key, type, value, items))
            }
            event = parser.next()
        }

        if (!rootFound || (datastores.isEmpty() && prefs.isEmpty())) return false
        // Refuse anything that is clearly not our settings data.
        if (datastores.values.any { !it.trim().startsWith("{") }) return false

        datastores.forEach { (name, text) ->
            val target = File(context.filesDir, "datastore/$name")
            target.parentFile?.mkdirs()
            val temp = File(target.parentFile, "$name.restore")
            temp.writeText(text)
            if (!temp.renameTo(target)) {
                target.writeText(text)
                temp.delete()
            }
        }

        prefs.forEach { (name, entries) ->
            val editor = context.getSharedPreferences(name, Context.MODE_PRIVATE).edit().clear()
            entries.forEach { e ->
                runCatching {
                    when (e.type) {
                        "boolean" -> editor.putBoolean(e.key, e.value.toBoolean())
                        "int" -> editor.putInt(e.key, e.value.toInt())
                        "long" -> editor.putLong(e.key, e.value.toLong())
                        "float" -> editor.putFloat(e.key, e.value.toFloat())
                        "string" -> editor.putString(e.key, e.value)
                        "stringset" -> editor.putStringSet(e.key, e.items.toSet())
                    }
                }
            }
            editor.commit()
        }
        return true
    }
}
