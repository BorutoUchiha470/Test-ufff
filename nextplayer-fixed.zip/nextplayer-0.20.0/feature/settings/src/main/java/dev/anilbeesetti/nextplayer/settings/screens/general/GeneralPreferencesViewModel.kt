package dev.anilbeesetti.nextplayer.settings.screens.general

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Process
import android.widget.Toast
import androidx.lifecycle.viewModelScope
import coil3.ImageLoader
import dev.anilbeesetti.nextplayer.core.data.repository.PreferencesRepository
import dev.anilbeesetti.nextplayer.core.media.extensions.clearAllCache
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.base.MviViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.koin.core.annotation.InjectedParam
import org.koin.core.annotation.KoinViewModel

@KoinViewModel
class GeneralPreferencesViewModel(
    private val preferencesRepository: PreferencesRepository,
    private val imageLoader: ImageLoader,
    private val context: Context,
    @InjectedParam internal var output: Output,
) : MviViewModel<GeneralPreferencesUiState, GeneralPreferencesUiEvent>() {

    data class Output(val navigateUp: () -> Unit)

    private val stateInternal = MutableStateFlow(value = GeneralPreferencesUiState())
    override val state: StateFlow<GeneralPreferencesUiState> = stateInternal.asStateFlow()

    override fun onAction(action: GeneralPreferencesUiEvent) {
        when (action) {
            is GeneralPreferencesUiEvent.NavigateUp -> output.navigateUp()
            is GeneralPreferencesUiEvent.ShowDialog -> showDialog(action.value)
            is GeneralPreferencesUiEvent.ClearThumbnailCache -> clearThumbnailCache()
            is GeneralPreferencesUiEvent.ResetSettings -> resetSettings()
            is GeneralPreferencesUiEvent.ExportSettings -> exportSettings(action.uri)
            is GeneralPreferencesUiEvent.ImportSettings -> importSettings(action.uri)
        }
    }

    private fun showDialog(value: GeneralPreferencesDialog?) {
        stateInternal.update { it.copy(showDialog = value) }
    }

    private fun clearThumbnailCache() {
        viewModelScope.launch { imageLoader.clearAllCache() }
    }

    private fun exportSettings(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri, "wt")!!.use { SettingsBackup.export(context, it) }
            }.isSuccess
            toast(if (ok) R.string.backup_exported else R.string.backup_failed)
        }
    }

    private fun importSettings(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ok = runCatching {
                context.contentResolver.openInputStream(uri)!!.use { SettingsBackup.import(context, it) }
            }.getOrDefault(false)
            if (!ok) {
                toast(R.string.backup_failed)
                return@launch
            }
            toast(R.string.backup_restored)
            // Restart so every screen reads the restored settings.
            delay(900)
            val intent = context.packageManager.getLaunchIntentForPackage(context.packageName)
                ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            withContext(Dispatchers.Main) { if (intent != null) context.startActivity(intent) }
            delay(300)
            Process.killProcess(Process.myPid())
        }
    }

    private suspend fun toast(message: Int) {
        withContext(Dispatchers.Main) { Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
    }

    private fun resetSettings() {
        viewModelScope.launch { preferencesRepository.resetPreferences() }
    }
}

data class GeneralPreferencesUiState(val showDialog: GeneralPreferencesDialog? = null)

sealed interface GeneralPreferencesDialog {
    data object ClearThumbnailCacheDialog : GeneralPreferencesDialog
    data object ResetSettingsDialog : GeneralPreferencesDialog
}

sealed interface GeneralPreferencesUiEvent {
    data object NavigateUp : GeneralPreferencesUiEvent

    data class ShowDialog(val value: GeneralPreferencesDialog?) : GeneralPreferencesUiEvent
    data object ClearThumbnailCache : GeneralPreferencesUiEvent
    data object ResetSettings : GeneralPreferencesUiEvent
    data class ExportSettings(val uri: Uri) : GeneralPreferencesUiEvent
    data class ImportSettings(val uri: Uri) : GeneralPreferencesUiEvent
}
