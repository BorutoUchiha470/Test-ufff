package dev.anilbeesetti.nextplayer.feature.more.screens.shorts

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable
import org.koin.compose.viewmodel.koinViewModel

@Serializable
object ShortsRoute : NavKey

/** The feed again, but only the shorts the person has liked (opened from the You tab). */
@Serializable
object LikedShortsRoute : NavKey

fun EntryProviderScope<NavKey>.shortsEntry(onPlayVideo: (String) -> Unit, onBack: () -> Unit) {
    entry<ShortsRoute> {
        ShortsScreen(
            viewModel = koinViewModel<ShortsViewModel>(),
            onOpenInPlayer = onPlayVideo,
            onBack = onBack,
        )
    }
}

fun EntryProviderScope<NavKey>.likedShortsEntry(onPlayVideo: (String) -> Unit, onBack: () -> Unit) {
    entry<LikedShortsRoute> {
        ShortsScreen(
            viewModel = koinViewModel<ShortsViewModel>(),
            onOpenInPlayer = onPlayVideo,
            onBack = onBack,
            likedOnly = true,
        )
    }
}

fun NavBackStack<NavKey>.navigateToLikedShorts() {
    add(element = LikedShortsRoute)
}
