package dev.anilbeesetti.nextplayer.feature.more.screens.more

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import dev.anilbeesetti.nextplayer.core.ui.theme.decodeScaledBitmap
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** The name and profile photo shown on the You tab. Stored on the phone only. */
class ProfilePrefs private constructor(private val context: Context) {
    private val prefs = context.getSharedPreferences("profile", Context.MODE_PRIVATE)

    var name by mutableStateOf(prefs.getString("name", "").orEmpty())
        private set
    var avatarVersion by mutableIntStateOf(prefs.getInt("avatar_version", 0))
        private set

    val avatarFile: File get() = File(context.filesDir, "profile_avatar.jpg")

    fun updateName(value: String) {
        name = value.trim()
        prefs.edit().putString("name", name).apply()
    }

    /** Picture from the gallery or the file manager. Call off the main thread. */
    fun setAvatar(uri: Uri): Boolean {
        val ok = runCatching {
            val bitmap = decodeScaledBitmap(context, uri, maxSide = 512) ?: return false
            saveBitmap(bitmap)
        }.getOrDefault(false)
        if (ok) bumpVersion()
        return ok
    }

    /** Picture from an http(s) link. Call off the main thread. */
    fun setAvatarFromUrl(link: String): Boolean {
        val url = link.trim()
        if (!url.startsWith("http://", true) && !url.startsWith("https://", true)) return false
        val ok = runCatching {
            val connection = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", "Mozilla/5.0")
            }
            val bytes = try {
                connection.inputStream.use { it.readLimited(MAX_DOWNLOAD_BYTES) }
            } finally {
                connection.disconnect()
            }
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 512) sample *= 2
            val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                ?: return false
            saveBitmap(bitmap)
        }.getOrDefault(false)
        if (ok) bumpVersion()
        return ok
    }

    fun removeAvatar() {
        avatarFile.delete()
        bumpVersion()
    }

    private fun saveBitmap(bitmap: android.graphics.Bitmap): Boolean {
        avatarFile.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        return true
    }

    private fun bumpVersion() {
        avatarVersion += 1
        prefs.edit().putInt("avatar_version", avatarVersion).apply()
    }

    private fun InputStream.readLimited(limit: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val read = read(buffer)
            if (read < 0) break
            out.write(buffer, 0, read)
            if (out.size() > limit) error("Image is too large")
        }
        return out.toByteArray()
    }

    companion object {
        private const val MAX_DOWNLOAD_BYTES = 12 * 1024 * 1024

        @Volatile
        private var instance: ProfilePrefs? = null

        fun get(context: Context): ProfilePrefs = instance ?: synchronized(this) {
            instance ?: ProfilePrefs(context.applicationContext).also { instance = it }
        }
    }
}
