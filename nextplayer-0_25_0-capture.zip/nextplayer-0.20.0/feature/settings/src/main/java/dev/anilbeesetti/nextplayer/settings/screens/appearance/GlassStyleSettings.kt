package dev.anilbeesetti.nextplayer.settings.screens.appearance

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import dev.anilbeesetti.nextplayer.core.ui.R
import dev.anilbeesetti.nextplayer.core.ui.glass.GlassSettings
import dev.anilbeesetti.nextplayer.core.ui.glass.GlassTintPresets
import dev.anilbeesetti.nextplayer.core.ui.glass.glassSurface
import dev.anilbeesetti.nextplayer.core.ui.glass.rememberGlassSettings

/** Lets the user change how the glass player controls look, with a live preview. */
@Composable
fun GlassStyleSettings(modifier: Modifier = Modifier) {
    val glass = rememberGlassSettings()

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF3A1C71), Color(0xFFD76D77), Color(0xFFFFAF7B)),
                    ),
                ),
            contentAlignment = Alignment.Center,
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                repeat(3) { PreviewBubble(glass = glass) }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text = stringResource(R.string.glass_controls))
            Switch(
                checked = glass.enabled,
                onCheckedChange = { glass.updateEnabled(it) },
            )
        }

        Text(text = stringResource(R.string.glass_transparency))
        Slider(
            value = glass.opacity,
            onValueChange = { glass.updateOpacity(it) },
            valueRange = 0.05f..0.8f,
        )

        Text(text = stringResource(R.string.glass_edge_shine))
        Slider(
            value = glass.edgeShine,
            onValueChange = { glass.updateEdgeShine(it) },
            valueRange = 0f..1f,
        )

        Text(text = stringResource(R.string.glass_color))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassTintPresets.forEach { preset ->
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(preset))
                        .border(
                            width = if (glass.tint == preset) 3.dp else 1.dp,
                            color = if (glass.tint == preset) Color.White else Color.Gray,
                            shape = CircleShape,
                        )
                        .clickable { glass.updateTint(preset) },
                )
            }
        }

        TextButton(
            onClick = { glass.reset() },
            modifier = Modifier.padding(bottom = 16.dp),
        ) {
            Text(text = stringResource(R.string.reset))
        }
    }
}

@Composable
private fun PreviewBubble(glass: GlassSettings) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .then(
                if (glass.enabled) {
                    Modifier.glassSurface(settings = glass, shape = CircleShape)
                } else {
                    Modifier
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.3f))
                },
            ),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_capture),
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp),
        )
    }
}
