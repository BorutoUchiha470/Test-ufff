package dev.anilbeesetti.nextplayer.core.ui.glass

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

private const val PREFS_NAME = "glass_style"
private const val KEY_ENABLED = "enabled"
private const val KEY_OPACITY = "opacity"
private const val KEY_EDGE = "edge"
private const val KEY_TINT = "tint"

private const val DEFAULT_OPACITY = 0.28f
private const val DEFAULT_EDGE = 0.55f
private val DEFAULT_TINT = 0xFF9DB7E0.toInt()

/** Colors the user can pick for the glass. */
val GlassTintPresets: List<Int> = listOf(
    0xFFFFFFFF.toInt(),
    0xFF9DB7E0.toInt(),
    0xFFFFB3D1.toInt(),
    0xFFC3A6FF.toInt(),
    0xFFA8F0D8.toInt(),
    0xFF2B2B2B.toInt(),
)

/** User-adjustable "liquid glass" look. Values are saved and shared by the player and the settings. */
@Stable
class GlassSettings(private val prefs: SharedPreferences) {
    var enabled by mutableStateOf(prefs.getBoolean(KEY_ENABLED, true))
        private set
    var opacity by mutableFloatStateOf(prefs.getFloat(KEY_OPACITY, DEFAULT_OPACITY))
        private set
    var edgeShine by mutableFloatStateOf(prefs.getFloat(KEY_EDGE, DEFAULT_EDGE))
        private set
    var tint by mutableIntStateOf(prefs.getInt(KEY_TINT, DEFAULT_TINT))
        private set

    fun updateEnabled(value: Boolean) {
        enabled = value
        prefs.edit().putBoolean(KEY_ENABLED, value).apply()
    }

    fun updateOpacity(value: Float) {
        opacity = value
        prefs.edit().putFloat(KEY_OPACITY, value).apply()
    }

    fun updateEdgeShine(value: Float) {
        edgeShine = value
        prefs.edit().putFloat(KEY_EDGE, value).apply()
    }

    fun updateTint(value: Int) {
        tint = value
        prefs.edit().putInt(KEY_TINT, value).apply()
    }

    fun reset() {
        updateEnabled(true)
        updateOpacity(DEFAULT_OPACITY)
        updateEdgeShine(DEFAULT_EDGE)
        updateTint(DEFAULT_TINT)
    }
}

@Composable
fun rememberGlassSettings(): GlassSettings {
    val context = LocalContext.current
    return remember {
        GlassSettings(
            context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
        )
    }
}

/** Provided by the player screen so every control can use the same glass look. */
val LocalGlassSettings = staticCompositionLocalOf<GlassSettings?> { null }

/** Frosted, shiny glass: a soft tinted gradient with a bright rim, like a glass bubble. */
fun Modifier.glassSurface(settings: GlassSettings, shape: Shape): Modifier {
    val tint = Color(settings.tint)
    val fill = Brush.verticalGradient(
        colors = listOf(
            tint.copy(alpha = (settings.opacity * 1.35f).coerceIn(0f, 1f)),
            tint.copy(alpha = (settings.opacity * 0.65f).coerceIn(0f, 1f)),
        ),
    )
    val rim = Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = settings.edgeShine),
            Color.White.copy(alpha = settings.edgeShine * 0.12f),
            Color.White.copy(alpha = settings.edgeShine * 0.7f),
        ),
    )
    return this
        .clip(shape)
        .background(color = Color.Black.copy(alpha = 0.18f), shape = shape)
        .background(brush = fill, shape = shape)
        .border(width = 1.dp, brush = rim, shape = shape)
}
