package dev.anilbeesetti.nextplayer.feature.player

import android.graphics.Rect
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.PlayerSurface
import androidx.media3.ui.compose.SURFACE_TYPE_SURFACE_VIEW
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import androidx.media3.ui.compose.modifiers.resizeWithContentScale
import androidx.media3.ui.compose.state.rememberPresentationState
import dev.anilbeesetti.nextplayer.core.ui.extras.rememberExtraFeatures
import dev.anilbeesetti.nextplayer.feature.player.extensions.toContentScale
import dev.anilbeesetti.nextplayer.feature.player.state.PictureInPictureState
import dev.anilbeesetti.nextplayer.feature.player.state.VideoZoomAndContentScaleState
import dev.anilbeesetti.nextplayer.feature.player.ui.AmbientGlow
import dev.anilbeesetti.nextplayer.feature.player.ui.ShutterView
import dev.anilbeesetti.nextplayer.feature.player.ui.SubtitleConfiguration
import dev.anilbeesetti.nextplayer.feature.player.ui.SubtitleView
import dev.anilbeesetti.nextplayer.feature.player.utils.applyVideoEnhancement
import kotlinx.coroutines.delay

@OptIn(UnstableApi::class)
@Composable
fun PlayerContentFrame(
    modifier: Modifier = Modifier,
    player: Player,
    pictureInPictureState: PictureInPictureState,
    videoZoomAndContentScaleState: VideoZoomAndContentScaleState,
    subtitleConfiguration: SubtitleConfiguration,
    videoVisible: Boolean = true,
    displayAspectRatio: Float? = null,
    // A TextureView (instead of a SurfaceView) lets liquid glass see, blur and bend the video.
    useTextureView: Boolean = false,
) {
    val presentationState = rememberPresentationState(player = player)

    // Video enhancer: brightness, contrast and colour, applied to the video picture.
    val extras = rememberExtraFeatures()
    val rootView = LocalView.current
    val enhancerOn = useTextureView && extras.enhancerEnabled
    LaunchedEffect(
        enhancerOn,
        extras.brightness,
        extras.contrast,
        extras.saturation,
        videoVisible,
        useTextureView,
    ) {
        delay(150)
        applyVideoEnhancement(rootView = rootView, extras = if (enhancerOn) extras else null)
    }

    Box(modifier.fillMaxSize()) {
        if (extras.ambientGlow && videoVisible &&
            !pictureInPictureState.isInPictureInPictureMode
        ) {
            AmbientGlow(
                strength = extras.ambientStrength,
                modifier = Modifier.matchParentSize(),
            )
        }
        if (videoVisible) {
            PlayerSurface(
                player = player,
                surfaceType = if (useTextureView) SURFACE_TYPE_TEXTURE_VIEW else SURFACE_TYPE_SURFACE_VIEW,
                modifier = Modifier
                    .resizeWithContentScale(
                        contentScale = videoZoomAndContentScaleState.videoContentScale
                            .toContentScale(),
                        sourceSizeDp = presentationState.videoSizeDp?.let { size ->
                            size.copy(
                                width = with(LocalDensity.current) {
                                    (
                                        displayAspectRatio?.let {
                                            size.height * it
                                        } ?: size.width
                                        ).toDp().value
                                },
                                height = with(LocalDensity.current) { size.height.toDp().value },
                            )
                        },
                    )
                    .onGloballyPositioned {
                        val bounds = it.boundsInWindow()
                        val rect = Rect(
                            bounds.left.toInt(),
                            bounds.top.toInt(),
                            bounds.right.toInt(),
                            bounds.bottom.toInt(),
                        )
                        pictureInPictureState.setVideoViewRect(rect)
                    }
                    .graphicsLayer {
                        scaleX = videoZoomAndContentScaleState.zoom
                        scaleY = videoZoomAndContentScaleState.zoom
                        translationX = videoZoomAndContentScaleState.offset.x
                        translationY = videoZoomAndContentScaleState.offset.y
                    },
            )
        }

        SubtitleView(
            player = player,
            isInPictureInPictureMode = pictureInPictureState.isInPictureInPictureMode,
            configuration = subtitleConfiguration,
        )

        if (videoVisible && presentationState.coverSurface) {
            ShutterView()
        }
    }
}
