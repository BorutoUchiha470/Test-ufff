package dev.anilbeesetti.nextplayer.feature.player.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.Player
import dev.anilbeesetti.nextplayer.core.ui.extras.ExtraFeaturesStore
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.coroutines.resume
import kotlin.math.roundToInt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

private const val MICROS_PER_MILLI = 1_000L
private const val JPEG_QUALITY = 95
// Same folder Samsung Video Player uses, so Samsung Gallery shows the captures as its own album.
private const val CAPTURE_DIR = "Videocaptures"

/** A saved capture: a small picture for the on-screen preview and where it was saved. */
class CapturedFrame(val thumbnail: Bitmap, val uri: Uri)

private const val THUMBNAIL_WIDTH = 480

/**
 * Saves the frame that is on screen right now as a JPEG in DCIM/Videocaptures.
 * First it copies the picture straight from the video surface (fast, works for any video and
 * needs no extra decoder). If that is not possible it reads the frame from the file instead.
 * Returns the saved capture (with a small preview picture), or null when saving failed.
 */
suspend fun saveCurrentFrame(context: Context, view: View?, player: Player?): CapturedFrame? {
    // Media3 players must be read on the main thread, so do it first.
    val videoUri = player?.currentMediaItem?.localConfiguration?.uri
    val positionMs = player?.currentPosition ?: 0L
    val bitmap = runCatching { copyFromTexture(view, player) }.getOrNull()
        ?: runCatching { copyFromSurface(view, player) }.getOrNull()
        ?: runCatching { retrieveFrame(context, player) }.getOrNull()
        ?: return null

    val sameDateAsVideo = ExtraFeaturesStore.get(context).captureWithVideoDate
    return withContext(Dispatchers.IO) {
        // Like Samsung Video Player: the picture gets the date of the video (one second later,
        // plus a hair for the scene), so the Gallery shows it right next to the video.
        val takenAt = if (sameDateAsVideo && videoUri != null) {
            videoDateMillis(context, videoUri)?.let { it + 1_000L + positionMs / 1_000L }
        } else {
            null
        }
        val originalPath = videoUri?.let { runCatching { filePathOf(context, it) }.getOrNull() ?: it.path }
        val savedUri = runCatching { saveBitmap(context, bitmap, takenAt, originalPath) }.getOrNull()
            ?: return@withContext null
        val thumbnail = runCatching {
            val height = (bitmap.height * THUMBNAIL_WIDTH.toFloat() / bitmap.width).roundToInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(bitmap, THUMBNAIL_WIDTH, height, true)
        }.getOrDefault(bitmap)
        CapturedFrame(thumbnail, savedUri)
    }
}

/** The date the Gallery shows for this video: date taken, else last changed, else date added. */
private fun videoDateMillis(context: Context, uri: Uri): Long? {
    runCatching {
        val columns = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            arrayOf(
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_ADDED,
            )
        } else {
            arrayOf(
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_MODIFIED,
                MediaStore.MediaColumns.DATE_ADDED,
            )
        }
        context.contentResolver.query(uri, columns, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val taken = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) cursor.getLong(0) else 0L
                val modified = cursor.getLong(1) * 1_000L
                val added = cursor.getLong(2) * 1_000L
                listOf(taken, modified, added).firstOrNull { it > 0L }?.let { return it }
            }
        }
    }
    if (uri.scheme == "file") {
        val modified = File(uri.path.orEmpty()).lastModified()
        if (modified > 0L) return modified
    }
    return null
}

private fun writeExifDate(context: Context, uri: Uri, takenAt: Long) {
    val formatted = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(Date(takenAt))
    context.contentResolver.openFileDescriptor(uri, "rw")?.use { descriptor ->
        @Suppress("DEPRECATION")
        val exif = android.media.ExifInterface(descriptor.fileDescriptor)
        exif.setAttribute(android.media.ExifInterface.TAG_DATETIME_ORIGINAL, formatted)
        exif.setAttribute(android.media.ExifInterface.TAG_DATETIME, formatted)
        exif.setAttribute(android.media.ExifInterface.TAG_DATETIME_DIGITIZED, formatted)
        // Samsung also writes the time zone offset, so Galleries do not shift the time.
        val offsetMinutes = TimeZone.getDefault().getOffset(takenAt) / 60_000
        val sign = if (offsetMinutes < 0) "-" else "+"
        val offset = "%s%02d:%02d".format(Locale.US, sign, kotlin.math.abs(offsetMinutes) / 60, kotlin.math.abs(offsetMinutes) % 60)
        runCatching { exif.setAttribute("OffsetTimeOriginal", offset) }
        runCatching { exif.setAttribute("OffsetTime", offset) }
        exif.saveAttributes()
    }
}

private fun View.findSurfaceView(): SurfaceView? {
    if (this is SurfaceView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findSurfaceView()?.let { return it }
        }
    }
    return null
}

private fun View.findTextureView(): TextureView? {
    if (this is TextureView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findTextureView()?.let { return it }
        }
    }
    return null
}

/** Picture copy when the video is shown on a TextureView (needed for real liquid glass). */
private fun copyFromTexture(view: View?, player: Player?): Bitmap? {
    val textureView = view?.rootView?.findTextureView() ?: return null
    if (!textureView.isAvailable) return null

    var width = textureView.width
    var height = textureView.height
    val videoSize = player?.videoSize
    if (videoSize != null && videoSize.width > 0 && videoSize.height > 0) {
        val ratio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
        width = (videoSize.width * ratio).roundToInt()
        height = videoSize.height
    }
    if (width <= 0 || height <= 0) return null
    return textureView.getBitmap(width, height)
}

private suspend fun copyFromSurface(view: View?, player: Player?): Bitmap? {
    val surfaceView = view?.rootView?.findSurfaceView() ?: return null
    if (!surfaceView.holder.surface.isValid) return null

    var width = surfaceView.width
    var height = surfaceView.height
    val videoSize = player?.videoSize
    if (videoSize != null && videoSize.width > 0 && videoSize.height > 0) {
        val ratio = if (videoSize.pixelWidthHeightRatio > 0f) videoSize.pixelWidthHeightRatio else 1f
        width = (videoSize.width * ratio).roundToInt()
        height = videoSize.height
    }
    if (width <= 0 || height <= 0) return null

    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    return suspendCancellableCoroutine { continuation ->
        PixelCopy.request(
            surfaceView,
            bitmap,
            { result ->
                if (continuation.isActive) {
                    continuation.resume(if (result == PixelCopy.SUCCESS) bitmap else null)
                }
            },
            Handler(Looper.getMainLooper()),
        )
    }
}

private suspend fun retrieveFrame(context: Context, player: Player?): Bitmap? {
    // Media3 players must be read on the main thread, so do it before switching to IO.
    val uri = player?.currentMediaItem?.localConfiguration?.uri ?: return null
    val positionUs = player.currentPosition * MICROS_PER_MILLI

    return withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            when (uri.scheme) {
                "http", "https" -> retriever.setDataSource(uri.toString(), HashMap<String, String>())
                else -> retriever.setDataSource(context, uri)
            }
            listOf(
                MediaMetadataRetriever.OPTION_CLOSEST,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                MediaMetadataRetriever.OPTION_PREVIOUS_SYNC,
            ).firstNotNullOfOrNull { option ->
                runCatching { retriever.getFrameAtTime(positionUs, option) }.getOrNull()
            }
        } catch (e: Throwable) {
            null
        } finally {
            runCatching { retriever.release() }
        }
    }
}

private fun filePathOf(context: Context, uri: Uri): String? =
    context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }

private fun saveBitmap(context: Context, bitmap: Bitmap, takenAt: Long?, originalPath: String?): Uri? {
    val fileName = "NextPlayer_${System.currentTimeMillis()}.jpg"
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/$CAPTURE_DIR")
            put(MediaStore.Images.Media.IS_PENDING, 1)
            if (takenAt != null) put(MediaStore.Images.Media.DATE_TAKEN, takenAt)
        }
        val resolver = context.contentResolver
        val target = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return null
        val written = resolver.openOutputStream(target)?.use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        } ?: false
        // Same order as Samsung Video Player: EXIF date first, then the file's own modified time,
        // then a rescan. Android resets the modified time when a file is closed, so setting it
        // only in the MediaStore is not enough and the Gallery would still file it under today.
        if (written && takenAt != null) runCatching { writeExifDate(context, target, takenAt) }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(target, values, null, null)
        if (written && takenAt != null) {
            val path = runCatching { filePathOf(context, target) }.getOrNull()
            if (path != null) runCatching { File(path).setLastModified(takenAt) }
            runCatching {
                val dates = ContentValues().apply {
                    put(MediaStore.Images.Media.DATE_TAKEN, takenAt)
                    put(MediaStore.Images.Media.DATE_MODIFIED, takenAt / 1_000L)
                }
                resolver.update(target, dates, null, null)
            }
            if (path != null) {
                MediaScannerConnection.scanFile(context, arrayOf(path), arrayOf("image/jpeg")) { _, _ ->
                    // The scan can read the date back from the file, so make sure it stays.
                    runCatching { File(path).setLastModified(takenAt) }
                }
            }
            // Samsung's Gallery links a capture to its video with this column. It only exists on
            // Samsung devices, so ignore the error everywhere else.
            runCatching {
                val link = ContentValues().apply { put("captured_original_path", originalPath) }
                resolver.update(target, link, null, null)
            }
        }
        if (written) target else null
    } else {
        // Android 8 and 9: save in the app's own picture folder (no storage permission needed).
        val folder = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: return null
        val file = File(folder, fileName)
        val ok = FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
        }
        if (ok && takenAt != null) file.setLastModified(takenAt)
        if (ok) Uri.fromFile(file) else null
    }
}
