package dev.anilbeesetti.nextplayer.feature.player.ui

import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import com.kyant.backdrop.Backdrop
import kotlin.coroutines.resume
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine

private const val SNAPSHOT_WIDTH = 480
private const val SNAPSHOT_INTERVAL_MS = 500L

internal class CopiedFrame(
    val bitmap: Bitmap,
    val left: Float,
    val top: Float,
    val width: Float,
    val height: Float,
)

internal fun View.findSurfaceView(): SurfaceView? {
    if (this is SurfaceView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findSurfaceView()?.let { return it }
        }
    }
    return null
}

/** Copies the video that is on screen into a small bitmap. Cheap, because the bitmap is tiny. */
internal suspend fun copyVideoFrame(root: View, targetWidth: Int): CopiedFrame? {
    val surfaceView = root.rootView.findSurfaceView() ?: return null
    if (!surfaceView.holder.surface.isValid || surfaceView.width <= 0 || surfaceView.height <= 0) {
        return null
    }
    val width = targetWidth.coerceAtLeast(2)
    val height = (width * surfaceView.height / surfaceView.width.toFloat()).roundToInt().coerceAtLeast(2)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val copied = suspendCancellableCoroutine<Boolean> { continuation ->
        PixelCopy.request(
            surfaceView,
            bitmap,
            { result ->
                if (continuation.isActive) continuation.resume(result == PixelCopy.SUCCESS)
            },
            Handler(Looper.getMainLooper()),
        )
    }
    if (!copied) return null
    val location = IntArray(2)
    surfaceView.getLocationInWindow(location)
    return CopiedFrame(
        bitmap = bitmap,
        left = location[0].toFloat(),
        top = location[1].toFloat(),
        width = surfaceView.width.toFloat(),
        height = surfaceView.height.toFloat(),
    )
}

/**
 * What the glass controls look through while the video stays on the fast surface: a small
 * picture of the video that is renewed twice a second while the controls are showing.
 */
@Stable
class VideoSnapshotBackdrop : Backdrop {
    private var image by mutableStateOf<ImageBitmap?>(null)
    private var area by mutableStateOf(Rect.Zero)

    override val isCoordinatesDependent: Boolean = true

    internal fun update(frame: CopiedFrame) {
        image = frame.bitmap.asImageBitmap()
        area = Rect(
            left = frame.left,
            top = frame.top,
            right = frame.left + frame.width,
            bottom = frame.top + frame.height,
        )
    }

    internal fun clear() {
        image = null
    }

    override fun DrawScope.drawBackdrop(
        density: Density,
        coordinates: LayoutCoordinates?,
        layerBlock: (GraphicsLayerScope.() -> Unit)?,
    ) {
        drawRect(color = Color.Black)
        val picture = image ?: return
        val origin = coordinates?.positionInWindow() ?: Offset.Zero
        translate(left = area.left - origin.x, top = area.top - origin.y) {
            drawImage(
                image = picture,
                dstSize = IntSize(area.width.roundToInt(), area.height.roundToInt()),
            )
        }
    }
}

@Composable
fun rememberVideoSnapshotBackdrop(active: Boolean): VideoSnapshotBackdrop {
    val backdrop = remember { VideoSnapshotBackdrop() }
    val rootView = LocalView.current
    LaunchedEffect(active) {
        if (!active) {
            backdrop.clear()
            return@LaunchedEffect
        }
        while (isActive) {
            runCatching { copyVideoFrame(rootView, SNAPSHOT_WIDTH) }
                .getOrNull()
                ?.let { backdrop.update(it) }
            delay(SNAPSHOT_INTERVAL_MS)
        }
    }
    return backdrop
}
