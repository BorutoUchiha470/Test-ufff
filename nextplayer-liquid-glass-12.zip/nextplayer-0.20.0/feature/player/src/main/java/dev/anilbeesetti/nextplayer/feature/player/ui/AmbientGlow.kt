package dev.anilbeesetti.nextplayer.feature.player.ui

import android.graphics.Bitmap
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private const val SAMPLE_WIDTH = 32
private const val SAMPLE_HEIGHT = 18
private const val SAMPLE_INTERVAL_MS = 1_500L
private const val FADE_MS = 450
private const val EDGE_THICKNESS = 3

private data class AmbientColors(
    val left: Color = Color.Transparent,
    val right: Color = Color.Transparent,
    val top: Color = Color.Transparent,
    val bottom: Color = Color.Transparent,
)

/**
 * A soft glow behind the video that matches the colours at the edges of the picture. It shows
 * in the black bars around the video. It looks at a tiny copy of the picture every 1.5 seconds,
 * so the video can stay on the fast surface.
 */
@Composable
fun AmbientGlow(strength: Float, modifier: Modifier = Modifier) {
    val rootView = LocalView.current
    var target by remember { mutableStateOf(AmbientColors()) }

    LaunchedEffect(Unit) {
        while (isActive) {
            val bitmap = runCatching { copyVideoFrame(rootView, SAMPLE_WIDTH) }.getOrNull()?.bitmap
                ?: textureViewFrame(rootView)
            if (bitmap != null) target = sampleEdges(bitmap)
            delay(SAMPLE_INTERVAL_MS)
        }
    }

    val left by animateColorAsState(target.left, tween(durationMillis = FADE_MS), label = "ambient_left")
    val right by animateColorAsState(target.right, tween(durationMillis = FADE_MS), label = "ambient_right")
    val top by animateColorAsState(target.top, tween(durationMillis = FADE_MS), label = "ambient_top")
    val bottom by animateColorAsState(target.bottom, tween(durationMillis = FADE_MS), label = "ambient_bottom")

    Box(
        modifier = modifier.drawBehind {
            val alpha = strength.coerceIn(0f, 1f)
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(left.copy(alpha = alpha), Color.Transparent),
                    startX = 0f,
                    endX = size.width * 0.55f,
                ),
            )
            drawRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, right.copy(alpha = alpha)),
                    startX = size.width * 0.45f,
                    endX = size.width,
                ),
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(top.copy(alpha = alpha), Color.Transparent),
                    startY = 0f,
                    endY = size.height * 0.5f,
                ),
            )
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, bottom.copy(alpha = alpha)),
                    startY = size.height * 0.5f,
                    endY = size.height,
                ),
            )
        },
    )
}

private fun sampleEdges(bitmap: Bitmap): AmbientColors {
    val width = bitmap.width
    val height = bitmap.height
    val pixels = IntArray(width * height)
    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

    fun average(xRange: IntRange, yRange: IntRange): Color {
        var red = 0L
        var green = 0L
        var blue = 0L
        var count = 0
        for (y in yRange) {
            for (x in xRange) {
                val pixel = pixels[y * width + x]
                red += (pixel shr 16) and 0xFF
                green += (pixel shr 8) and 0xFF
                blue += pixel and 0xFF
                count++
            }
        }
        if (count == 0) return Color.Transparent
        return Color(
            red = (red / count).toInt(),
            green = (green / count).toInt(),
            blue = (blue / count).toInt(),
        )
    }

    val edge = EDGE_THICKNESS.coerceAtMost(minOf(width, height))
    val allX = 0 until width
    val allY = 0 until height
    return AmbientColors(
        left = average(0 until edge, allY),
        right = average(width - edge until width, allY),
        top = average(allX, 0 until edge),
        bottom = average(allX, height - edge until height),
    )
}

/** Fallback for when the video is on a TextureView (video enhancer on). */
private fun textureViewFrame(root: View): Bitmap? {
    val textureView = root.rootView.findTextureView() ?: return null
    if (!textureView.isAvailable) return null
    return runCatching { textureView.getBitmap(SAMPLE_WIDTH, SAMPLE_HEIGHT) }.getOrNull()
}

private fun View.findTextureView(): TextureView? {
    if (this is TextureView) return this
    if (this is ViewGroup) {
        for (index in 0 until childCount) {
            getChildAt(index).findTextureView()?.let { return it }
        }
    }
    return null
}
